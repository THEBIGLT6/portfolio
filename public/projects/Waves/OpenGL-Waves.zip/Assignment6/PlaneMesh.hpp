
#include <stdio.h>
#include <string>
#include <vector>
#include <iostream>
#include <fstream>
#include <algorithm>
#include <sstream>

#include <stdlib.h>
#include <string.h>

class PlaneMesh {
	
	std::vector<float> verts;
	std::vector<float> normals;
	std::vector<int> indices;
	float min;
	float max;
	glm::vec4 modelColor;
	int numVerts;
	int numIndices;
	GLuint VAO;
	GLuint vertsVBO;
	GLuint normalsVBO;
	GLuint indicesVBO;

	GLuint timeVar;
	GLuint displaceText;
	GLuint waterText;
	GLuint mMat;
	GLuint vMat;
	GLuint pMat;
	GLuint lightPosG;
	GLuint inTess;
	GLuint outTess;
	GLuint shaderProgram;
	GLuint displacement;
	GLuint water;

	void loadBMP2(const char* imagepath, unsigned char** data, unsigned int* width, unsigned int* height) {

		// printf("Reading image %s\n", imagepath);

		// Data read from the header of the BMP file
		unsigned char header[54];
		unsigned int dataPos;
		unsigned int imageSize;
		// Actual RGB data

		// Open the file
		FILE* file;
		errno_t err = fopen_s(&file, imagepath, "rb");
		if (err != 0) {
			printf("%s could not be opened. Are you in the right directory?\n", imagepath);
			getchar();
			return;
		}

		// Read the header, i.e. the 54 first bytes

		// If less than 54 bytes are read, problem
		if (fread(header, 1, 54, file) != 54) {
			printf("Not a correct BMP fileA\n");
			fclose(file);
			return;
		}
		// A BMP files always begins with "BM"
		if (header[0] != 'B' || header[1] != 'M') {
			printf("Not a correct BMP fileB\n");
			fclose(file);
			return;
		}
		// Make sure this is a 24bpp file
		if (*(int*)&(header[0x1E]) != 0) {
			printf("Not a correct BMP fileC\n");
			fclose(file);
			return;
		}
		if (*(int*)&(header[0x1C]) != 24) {
			printf("Not a correct BMP fileD\n");
			fclose(file);
			return;
		}

		// Read the information about the image
		dataPos = *(int*)&(header[0x0A]);
		imageSize = *(int*)&(header[0x22]);
		*width = *(int*)&(header[0x12]);
		*height = *(int*)&(header[0x16]);

		// Some BMP files are misformatted, guess missing information
		if (imageSize == 0)    imageSize = (*width) * (*height) * 3; // 3 : one byte for each Red, Green and Blue component
		if (dataPos == 0)      dataPos = 54; // The BMP header is done that way

		// Create a buffer
		*data = new unsigned char[imageSize];

		// Read the actual data from the file into the buffer
		fread(*data, 1, imageSize, file);

		fprintf(stderr, "Done reading!\n");

		// Everything is in memory now, the file can be closed.
		fclose(file);

	}


	std::string readShaderFromFile(const std::string& filePath) {
		std::ifstream shaderFile(filePath);
		if (!shaderFile.is_open()) {
			std::cerr << "Unable to read file: " << filePath << std::endl;
			return "";
		}

		std::stringstream shaderStream;
		shaderStream << shaderFile.rdbuf();
		shaderFile.close();

		return shaderStream.str();
	}


	void planeMeshQuads(float min, float max, float stepsize) {

		// The following coordinate system works as if (min, 0, min) is the origin
		// And then builds up the mesh from that origin down (in z)
		// and then to the right (in x).
		// So, one "row" of the mesh's vertices have a fixed x and increasing z

		//manually create a first column of vertices
		float x = min;
		float y = 0;
		for (float z = min; z <= max; z += stepsize) {
			verts.push_back(x);
			verts.push_back(y);
			verts.push_back(z);
			normals.push_back(0);
			normals.push_back(1);
			normals.push_back(0);
		}

		for (float x = min+stepsize; x <= max; x += stepsize) {
			for (float z = min; z <= max; z += stepsize) {
				verts.push_back(x);
				verts.push_back(y);
				verts.push_back(z);
				normals.push_back(0);
				normals.push_back(1);
				normals.push_back(0);
			}
		}

		int nCols = (max-min)/stepsize + 1;
		int i = 0, j = 0;
		for (float x = min; x < max; x += stepsize) {
			j = 0;
			for (float z = min; z < max; z += stepsize) {
				indices.push_back(i*nCols + j);
				indices.push_back(i*nCols + j + 1);
				indices.push_back((i+1)*nCols + j + 1);
				indices.push_back((i+1)*nCols + j);
				++j;
			}
			++i;
		}
	}

public:

	PlaneMesh(float min, float max, float stepsize) {
		this->min = min;
		this->max = max;
		modelColor = glm::vec4(0, 1.0f, 1.0f, 1.0f);

		planeMeshQuads(min, max, stepsize);
		numVerts = verts.size()/3;
		numIndices = indices.size();

		unsigned char* data;
		unsigned char* data2;
		GLuint width, height, width2, height2;
		
		//load textures
		loadBMP2("Assets/displacement-map1.bmp", &data, &width, &height);
		loadBMP2("Assets/water.bmp", &data2, &width2, &height2);

		// Create the shaders
		GLuint vertShader = glCreateShader(GL_VERTEX_SHADER);
		GLuint fragShader = glCreateShader(GL_FRAGMENT_SHADER);
		GLuint tcs = glCreateShader(GL_TESS_CONTROL_SHADER);
		GLuint tes = glCreateShader(GL_TESS_EVALUATION_SHADER);
		GLuint geoShader = glCreateShader(GL_GEOMETRY_SHADER);
	

        // Read all shaders from code
		std::string vertexShaderCode = readShaderFromFile("WaterShader.vertexshader");
		std::string fragmentShaderCode = readShaderFromFile("WaterShader.fragmentshader");
		std::string tcsShaderCode = readShaderFromFile("WaterShader.tcs");
		std::string tesShaderCode = readShaderFromFile("WaterShader.tes");
		std::string geoShaderCode = readShaderFromFile("WaterShader.geoshader");

		// compile shaders
		char const* VertexSourcePointer = vertexShaderCode.c_str();
		glShaderSource(vertShader, 1, &VertexSourcePointer, NULL);
		glCompileShader(vertShader);

		GLint compileStatus;
		glGetShaderiv(vertShader, GL_COMPILE_STATUS, &compileStatus);
		if (compileStatus == GL_FALSE) {
			// Get the length of the error message
			GLint logLength;
			glGetShaderiv(vertShader, GL_INFO_LOG_LENGTH, &logLength);

			// Retrieve the error message
			char* log = new char[logLength];
			glGetShaderInfoLog(vertShader, logLength, NULL, log);

			// Print out the error message
			std::cerr << "vertex compilation error:" << std::endl << log << std::endl;
		}

		char const* tcsSourcePointer = tcsShaderCode.c_str();
		glShaderSource(tcs, 1, &tcsSourcePointer, NULL);
		glCompileShader(tcs);

		
		glGetShaderiv(tcs, GL_COMPILE_STATUS, &compileStatus);
		if (compileStatus == GL_FALSE) {
			// Get the length of the error message
			GLint logLength;
			glGetShaderiv(tcs, GL_INFO_LOG_LENGTH, &logLength);

			// Retrieve the error message
			char* log = new char[logLength];
			glGetShaderInfoLog(tcs, logLength, NULL, log);

			// Print out the error message
			std::cerr << "tcs compilation error:" << std::endl << log << std::endl;
		}

		char const* tesSourcePointer = tesShaderCode.c_str();
		glShaderSource(tes, 1, &tesSourcePointer, NULL);
		glCompileShader(tes);

		glGetShaderiv(tes, GL_COMPILE_STATUS, &compileStatus);
		if (compileStatus == GL_FALSE) {
			// Get the length of the error message
			GLint logLength;
			glGetShaderiv(tes, GL_INFO_LOG_LENGTH, &logLength);

			// Retrieve the error message
			char* log = new char[logLength];
			glGetShaderInfoLog(tes, logLength, NULL, log);

			// Print out the error message
			std::cerr << "tes compilation error:" << std::endl << log << std::endl;
		}

		char const* GeoSourcePointer = geoShaderCode.c_str();
		glShaderSource(geoShader, 1, &GeoSourcePointer, NULL);
		glCompileShader(geoShader);

		glGetShaderiv(geoShader, GL_COMPILE_STATUS, &compileStatus);
		if (compileStatus == GL_FALSE) {
			// Get the length of the error message
			GLint logLength;
			glGetShaderiv(geoShader, GL_INFO_LOG_LENGTH, &logLength);

			// Retrieve the error message
			char* log = new char[logLength];
			glGetShaderInfoLog(geoShader, logLength, NULL, log);

			// Print out the error message
			std::cerr << "geoShader compilation error:" << std::endl << log << std::endl;
		}

		char const* FragmentSourcePointer = fragmentShaderCode.c_str();
		glShaderSource(fragShader, 1, &FragmentSourcePointer, NULL);
		glCompileShader(fragShader);

		glGetShaderiv(geoShader, GL_COMPILE_STATUS, &compileStatus);
		if (compileStatus == GL_FALSE) {
			// Get the length of the error message
			GLint logLength;
			glGetShaderiv(geoShader, GL_INFO_LOG_LENGTH, &logLength);

			// Retrieve the error message
			char* log = new char[logLength];
			glGetShaderInfoLog(geoShader, logLength, NULL, log);

			// Print out the error message
			std::cerr << "frag compilation error:" << std::endl << log << std::endl;
		}


		//link program 
		shaderProgram = glCreateProgram();
		glAttachShader(shaderProgram, vertShader);
		glAttachShader(shaderProgram, tcs);
		glAttachShader(shaderProgram, tes);
		glAttachShader(shaderProgram, geoShader);
		glAttachShader(shaderProgram, fragShader);
		glLinkProgram(shaderProgram);

		//detach and delete shaders 
		glDetachShader(shaderProgram, vertShader);
		glDetachShader(shaderProgram, tcs);
		glDetachShader(shaderProgram, tes);
		glDetachShader(shaderProgram, geoShader);
		glDetachShader(shaderProgram, fragShader);
		glDeleteShader(vertShader);
		glDeleteShader(tcs);
		glDeleteShader(tes);
		glDeleteShader(geoShader);
		glDeleteShader(fragShader);


		//bind textures
		glGenTextures(1, &displaceText);
		glBindTexture(GL_TEXTURE_2D, displaceText);
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_BGR, GL_UNSIGNED_BYTE, data);
		glGenerateMipmap(GL_TEXTURE_2D);
		glBindTexture(GL_TEXTURE_2D, 0);

		glGenTextures(1, &waterText);
		glBindTexture(GL_TEXTURE_2D, waterText);
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width2, height2, 0, GL_BGR, GL_UNSIGNED_BYTE, data2);
		glGenerateMipmap(GL_TEXTURE_2D);
		glBindTexture(GL_TEXTURE_2D, 0);

		//get uniform locatons
		timeVar = glGetUniformLocation(shaderProgram, "time");
		mMat = glGetUniformLocation(shaderProgram, "M");
		vMat = glGetUniformLocation(shaderProgram, "V");
		pMat = glGetUniformLocation(shaderProgram, "P");
		lightPosG = glGetUniformLocation(shaderProgram, "lightPosition");
		inTess = glGetUniformLocation(shaderProgram, "innerTess");
		outTess = glGetUniformLocation(shaderProgram, "outerTess");
		displacement = glGetUniformLocation(shaderProgram, "disptext");
	    water = glGetUniformLocation(shaderProgram, "waterTexture");
		

		//create VAO
		glGenVertexArrays(1, &VAO);
		glBindVertexArray(VAO);

		//bind verts
		glGenBuffers(1, &vertsVBO);
		glBindBuffer(GL_ARRAY_BUFFER, vertsVBO);
		glBufferData(GL_ARRAY_BUFFER, verts.size() * sizeof(float), verts.data(), GL_STATIC_DRAW);
		glEnableVertexAttribArray(0);
		glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, (void*)0);

		//bind normals
		glGenBuffers(1, &normalsVBO);
		glBindBuffer(GL_ARRAY_BUFFER, normalsVBO);
		glBufferData(GL_ARRAY_BUFFER, normals.size() * sizeof(float), normals.data(), GL_STATIC_DRAW);
		glEnableVertexAttribArray(1);
		glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 0, (void*)0);

		//bind indicies
		glGenBuffers(1, &indicesVBO);
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, indicesVBO);
		glBufferData(GL_ELEMENT_ARRAY_BUFFER, indices.size() * sizeof(float), indices.data(), GL_STATIC_DRAW);

		//for safety
		glBindVertexArray(0);
		
	}

	void draw(glm::vec3 lightPos, glm::mat4 V, glm::mat4 P) {
		
		//make needed vars
		float time = glfwGetTime() ;
		glm::mat4 M = glm::mat4(1.0f);
		float tess = 16;
		glEnable(GL_TEXTURE_2D);

		glPatchParameteri(GL_PATCH_VERTICES, 4);

		//activate and enable textures
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, waterText);
		//glUniform1i(glGetUniformLocation(shaderProgram, "texture1"), 0);
		

		glActiveTexture(GL_TEXTURE1);
		glBindTexture(GL_TEXTURE_2D, displaceText);
		//glUniform1i(glGetUniformLocation(shaderProgram, "texture1"), 0);	

		//addshader and set uniforms
		glUseProgram(shaderProgram);
		glUniformMatrix4fv(vMat, 1, GL_FALSE, &V[0][0]);
		glUniformMatrix4fv(pMat, 1, GL_FALSE, &P[0][0]);
		glUniformMatrix4fv(mMat, 1, GL_FALSE, &M[0][0]);
		glUniform1f(inTess, tess);
		glUniform1f(outTess, tess);
		glUniform1f(timeVar, time);
		glUniform3fv(lightPosG, 1, glm::value_ptr(lightPos));
		glUniform1i(displacement, 1);
		glUniform1i(water, 0);


		//draw elements
		glBindVertexArray(VAO);
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, indicesVBO);
		glDrawElements(GL_PATCHES, numIndices, GL_UNSIGNED_INT, (void*)0);
		glBindVertexArray(0);
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);

		glUseProgram(0);
		glBindTexture(GL_TEXTURE_2D, 0);
		glBindTexture(GL_TEXTURE_2D, 0);

		glDisable(GL_TEXTURE_2D);


	}


};
