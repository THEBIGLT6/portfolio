// Include standard headers
#include <stdio.h>
#include <stdlib.h>
#include <cmath>

#include <GL/glew.h>

// Include GLFW
#include <GLFW/glfw3.h>
GLFWwindow* window;

// Include GLM
#include <glm/glm.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <glm/gtx/string_cast.hpp>
#include <glm/gtc/matrix_transform.hpp>
using namespace glm;

#include <iostream>
#include <vector>

#include "a4.hpp"
#include "PlaneMesh.hpp"


//Camera variables
double r = std::sqrt(75);
double theta = atan(5 / 5);
double phi = acos(5 / r);
double lastX = 0.0f;
double lastY = 0.0f;
glm::vec3 cameraPos = glm::vec3(r * sin(phi) * cos(theta), r * cos(phi), r * sin(theta) * sin(phi));
glm::vec3 cameraPoint = glm::vec3(0.0f, 0.0f, 0.0f);
glm::vec3 cameraUp = glm::vec3(0.0f, 1.0f, 0.0f);

//This function handles key presses
void keyCallBack(GLFWwindow* window, int key, int scancode, int action, int mods) {

	//If up is pressed move towards centre 
	if (key == GLFW_KEY_UP && GLFW_PRESS) {

		//stop at 0
		if (r - 0.1 > 0) {
			r = r - 0.1;
		}

		cameraPos = glm::vec3(r * sin(phi) * cos(theta), r * cos(phi), r * sin(theta) * sin(phi));
	}

	//If down is pressed move away from centre
	if (key == GLFW_KEY_DOWN && GLFW_PRESS) {

		r = r + 0.1;

		cameraPos = glm::vec3(r * sin(phi) * cos(theta), r * cos(phi), r * sin(theta) * sin(phi));

	}
}//end keyCall

bool drag = false;

// This is the function used to know when then mouse button is clicked
void mouseCallback(GLFWwindow* window, int button, int action, int mods) {


	//recognize if button is pressed 
	if (button == GLFW_MOUSE_BUTTON_LEFT && action == GLFW_PRESS) {
		double xpos, ypos;

		//grab the position first so it moves relative to its current position
		//call the getPoint function
		glfwGetCursorPos(window, &xpos, &ypos);
		lastX = xpos;
		lastY = ypos;
		drag = true;
	}


	//end dragging
	else if (action == GLFW_RELEASE) {
		drag = false;
	}


}//end mouseCallback


//this is the function that analzyes the drag of the object and updates the coordinates
void getPoint(GLFWwindow* window, double xpos, double ypos) {


	// this will be run if the object is being dragged
	if (drag) {

		//calculate difference of movement
		double differenceX = xpos - lastX;
		double differenceY = ypos - lastY;

		//calculate angles relative to difference
		theta = theta + differenceX * 0.01;
		phi = phi + differenceY * 0.01;

		//if phi ends up being more than 180,  - 180
		if (phi > 180) { phi = phi - 180; }


		//make the last position equal to the current;
		lastX = xpos;
		lastY = ypos;

		//update camera position 
		cameraPos = glm::vec3(r * sin(phi) * cos(theta), r * cos(phi), r * sin(theta) * sin(phi));

	}

}//end getPoint


//////////////////////////////////////////////////////////////////////////////
// Main
//////////////////////////////////////////////////////////////////////////////

int main( int argc, char* argv[])
{

	///////////////////////////////////////////////////////
	float screenW = 1500;
	float screenH = 1000;
	float stepsize = 0.5f;

	float xmin = -5;
	float xmax = 5;

	if (argc > 1 ) {
		screenW = atoi(argv[1]);
	}
	if (argc > 2) {
		screenH = atoi(argv[2]);
	}
	if (argc > 3) {
		stepsize = atof(argv[3]);
	}
	if (argc > 4) {
		xmin = atof(argv[4]);
	}
	if (argc > 5) {
		xmax = atof(argv[5]);
	}


	///////////////////////////////////////////////////////

	// Initialise GLFW
	if( !glfwInit() )
	{
		fprintf( stderr, "Failed to initialize GLFW\n" );
		getchar();
		return -1;
	}

	glfwWindowHint(GLFW_SAMPLES, 4);
	// glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	// glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	// glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE); // To make MacOS happy; should not be needed
	// glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

	// Open a window and create its OpenGL context
	window = glfwCreateWindow( screenW, screenH, "Assignment 6", NULL, NULL);
	if( window == NULL ){
		fprintf( stderr, "Failed to open GLFW window. If you have an Intel GPU, they are not 3.3 compatible. Try the 2.1 version of the tutorials.\n" );
		getchar();
		glfwTerminate();
		return -1;
	}
	glfwMakeContextCurrent(window);

	// Initialize GLEW
	glewExperimental = true; // Needed for core profile
	if (glewInit() != GLEW_OK) {
		fprintf(stderr, "Failed to initialize GLEW\n");
		getchar();
		glfwTerminate();
		return -1;
	}


	PlaneMesh plane(xmin, xmax, stepsize);
	
	TexturedMesh boat("Assets/boat.ply", "Assets/boat.bmp");
	TexturedMesh head("Assets/head.ply", "Assets/head.bmp");
	TexturedMesh eyes("Assets/eyes.ply", "Assets/eyes.bmp");


	// Ensure we can capture the escape key being pressed below
	glfwSetInputMode(window, GLFW_STICKY_KEYS, GL_TRUE);

	// Dark blue background
	glClearColor(0.2f, 0.2f, 0.3f, 0.0f);
	glColor4f(1.0f, 1.0f, 1.0f, 1.0f);

	glDisable(GL_CULL_FACE);

	glm::mat4 projection = glm::perspective(glm::radians(45.0f), screenW/screenH, 0.001f, 1000.0f);
	 
	glm::mat4 view;

	glm::vec3 lightpos(5.0f, 30.0f, 5.0f);
	glm::vec4 color1(1.0f, 1.0f, 1.0f, 1.0f);

	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LESS);


	do{
		// Clear the screen
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		glfwPollEvents();

		// Create Projection matrix
		glMatrixMode(GL_PROJECTION);
		glPushMatrix();
		projection = glm::perspective(glm::radians(45.0f), screenW / screenH, 0.001f, 1000.0f);
		glLoadMatrixf(glm::value_ptr(projection));

		//grab key presses by setting callback function
		glfwSetKeyCallback(window, keyCallBack);
		glfwSetMouseButtonCallback(window, mouseCallback);
		glfwSetCursorPosCallback(window, getPoint);

		//update view matrix
		glMatrixMode(GL_MODELVIEW);
		glPushMatrix();
		view = glm::lookAt(cameraPos, cameraPoint, cameraUp);
		glLoadMatrixf(glm::value_ptr(view));

		//make Mat matrix
		glm::mat4 M = glm::mat4(1.0f);

		//calculate MVP matrix
		glm::mat4 MVP = projection * view * M;
		
		plane.draw(lightpos, view, projection);
		boat.draw(MVP);
		eyes.draw(MVP);
		head.draw(MVP);

		// Swap buffers
		glfwSwapBuffers(window);
		glfwPollEvents();

	} // Check if the ESC key was pressed or the window was closed
	while( glfwGetKey(window, GLFW_KEY_ESCAPE ) != GLFW_PRESS &&
		   glfwWindowShouldClose(window) == 0 );

	// Close OpenGL window and terminate GLFW
	glfwTerminate();
	return 0;
}

