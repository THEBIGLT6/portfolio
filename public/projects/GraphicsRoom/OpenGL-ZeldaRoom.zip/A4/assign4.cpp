// Include all headers
#include <stdio.h>
#include <stdlib.h>
#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <glm/gtx/string_cast.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <vector>
#include <iostream>
#include <sstream>
#include <fstream>

#define _CRT_SECURE_NO_WARNINGS

GLFWwindow* window;
using namespace glm;


//initalize camera positions (make instance variables) 
glm::vec3 cameraPos = glm::vec3(0.5f, 0.4f, 0.5f);
glm::vec3 cameraPoint = glm::vec3(0.5f, 0.4f, 0.5f) + glm::vec3(0.0f, 0.0f, -1.0f);
glm::vec3 cameraUp = glm::vec3(0.0f, 1.0f, 0.0f);



// Included function loadARGB_BMP to read a BMP file 
void loadARGB_BMP(const char* imagepath, unsigned char** data, unsigned int* width, unsigned int* height) {

	printf("Reading image %s\n", imagepath);

	// Data read from the header of the BMP file
	unsigned char header[54];
	unsigned int dataPos;
	unsigned int imageSize;
	// Actual RGBA data

	// Open the file
	FILE* file;
	errno_t err = fopen_s(&file, imagepath, "rb");
	if (err != 0) {
		printf("%s could not be opened. Are you in the right directory?\n", imagepath);
		getchar();
		return;
	}

	// Read the header, i.e. the 54 first bytes

	// If less than 54 bytes are read, problem
	if (fread(header, 1, 54, file) != 54) {
		printf("Not a correct BMP file1\n");
		fclose(file);
		return;
	}

	// Read the information about the image
	dataPos = *(int*)&(header[0x0A]);
	imageSize = *(int*)&(header[0x22]);
	*width = *(int*)&(header[0x12]);
	*height = *(int*)&(header[0x16]);
	// A BMP files always begins with "BM"
	if (header[0] != 'B' || header[1] != 'M') {
		printf("Not a correct BMP file2\n");
		fclose(file);
		return;
	}
	// Make sure this is a 32bpp file
	if (*(int*)&(header[0x1E]) != 3) {
		printf("Not a correct BMP file3\n");
		fclose(file);
		return;
	}
	
	// Some BMP files are misformatted, guess missing information
	if (imageSize == 0)    imageSize = (*width) * (*height) * 4; // 4 : one byte for each Red, Green, Blue, Alpha component
	if (dataPos == 0)      dataPos = 54; // The BMP header is done that way

	// Create a buffer
	*data = new unsigned char[imageSize];

	if (dataPos != 54) {
		fread(header, 1, dataPos - 54, file);
	}

	// Read the actual data from the file into the buffer
	fread(*data, 1, imageSize, file);

	// Everything is in memory now, the file can be closed.
	fclose(file);
}

//Create class for vertexdata
class VertexData {

	glm::vec3 position;
	glm::vec3 normalVec;
	glm::vec3 colour;
	glm::vec2 textureCoord;

	public:
		
		//class constructor for position only
		VertexData(glm::vec3 pos, glm::vec3 norm, glm::vec3 col, glm::vec2 text) {

			position = pos;
			normalVec = norm;
			colour = col;
			textureCoord = text;


		}//end constructor

		//return positions var
		glm::vec3 getPos() {
			return position;
		}

		//return coordinates var
		glm::vec2 getCoord() {
			return textureCoord;
		}


}; //end vertexData



//Create class for tridata
class TriData {

	int vert1;
	int vert2;
	int vert3;

	public:

		
		//constructor for this class
		TriData(int index1, int index2, int index3) {

			vert1 = index1;
			vert2 = index2;
			vert3 = index3;

		}//end constructor

		//return for each vert

		int getVert1() {
			return vert1;
		}

		int getVert2() {
			return vert2;
		}

		int getVert3() {
			return vert3;
		}


}; //end TriData


//create Function that reads the PLY File
void readPLYFile(const char * imagepath, std::vector<VertexData>& vertices, std::vector<TriData>& faces) {

	std::string text;
	int numVert;
	int numTri;
	bool hasNormal = false;
	bool hasColour = false;
	bool hasText = false;

	//open file
	std::ifstream MyFile(imagepath);

	//skip lines
	std::getline(MyFile, text);
	std::getline(MyFile, text);
	std::getline(MyFile, text);
	std::getline(MyFile, text);

	//find the amount of vertex lines
	std::istringstream iss(text);
	std::vector<std::string> tokens;

	std::string token;
	while (std::getline(iss, token, ' ')) { 
		tokens.push_back(token);
	}

	numVert = std::stoi(tokens.back());


	//check to see what properties this file has
	while (std::getline(MyFile, text))  {
		
		//break if the property section is over
		if (text.find("element face") != std::string::npos) {
			break;
		}

		//check if there is normal var
		if (text.find("nx") != std::string::npos) {
			hasNormal = true;
		}

		//check if there is colour var
		if (text.find("red") != std::string::npos) {
			hasColour = true;
		}

		//check if there is texture coordinates
		if (text.find("float u") != std::string::npos) {
			hasText = true;
		}

	}

	//get number of tri vert data
	tokens.clear();
	std::istringstream iss2(text);

	while (std::getline(iss2, token, ' ')) {
		tokens.push_back(token);
	}

	numTri = std::stoi(tokens.back());

	std::getline(MyFile, text);
	std::getline(MyFile, text);
    
	//run loop to iterate over each vertex line
	for (int i = 0; i < numVert; i++) {

		std::getline(MyFile, text);
		int j = 0;
		glm::vec3 col = glm::vec3(-69.0f, -69.0f, -69.0f);
		glm::vec3 nor = glm::vec3(-69.0f, -69.0f, -69.0f);
		glm::vec2 txt = glm::vec3(-69.0f, -69.0f, -69.0f);

		//break up string
		std::istringstream iss3(text);
		std::vector<std::string> strParse;

		strParse.clear();

		std::string tok;
		while (std::getline(iss3, tok, ' ')) {
			strParse.push_back(tok);
		}


		//place all of the information gathered into the according vector if it is in the file
		glm:vec3 pos = glm::vec3(std::stof(strParse.at(j)), std::stof(strParse.at(j+1)), std::stof(strParse.at(j+2)));
		j = j + 3;

		if (hasColour) {
			col = glm::vec3(std::stof(strParse.at(j)), std::stof(strParse.at(j+1)), std::stof(strParse.at(j+2)));
			j = j + 3;
		}
		
		if (hasNormal) {
			nor = glm::vec3(std::stof(strParse.at(j)), std::stof(strParse.at(j+1)), std::stof(strParse.at(j+2)));
			j = j + 3;
		}

		if (hasText) {
		    txt = glm::vec2(std::stof(strParse.at(j)), std::stof(strParse.at(j+1)));
		}
		

		vertices.push_back(VertexData(pos, col, nor, txt));

	}//end for
	

	//run loop to iterate over each face line
	for (int i = 0; i < numTri; i++){

		std::getline(MyFile, text);

		//break up string
		std::istringstream iss3(text);
		std::vector<std::string> strParse;

		strParse.clear();

		std::string tok;
		while (std::getline(iss3, tok, ' ')) {
			strParse.push_back(tok);
		}

		faces.push_back(TriData(std::stoi(strParse.at(1)), std::stoi(strParse.at(2)), std::stoi(strParse.at(3))));

		
	}//end for

	//close file
	MyFile.close();


}//end readPLYFile

//Create class for textured mesh
class TexturedMesh {

	GLuint vertexPos;
	GLuint textCoord;
	GLuint VertIndicies;
	GLuint bitMapImg;
	GLuint VAO;
	GLuint shader;
	GLuint matrixID;
	int numIndicies;

	public:

		//constructor for this class
		TexturedMesh(const char * plyPath, const char * bitPath) {

			//declare variables
			std::vector<VertexData> vertVec;
			std::vector<TriData> triVect;
			unsigned char* data;
			GLuint width, height;
			std::vector<float> verts;
			std::vector<float> coords;
			std::vector<int> faces;


			//read from files
			readPLYFile(plyPath, vertVec, triVect);
			loadARGB_BMP(bitPath, &data, &width , &height);

			for (int i = 0; i < vertVec.size(); i++) {

				verts.push_back(vertVec.at(i).getPos().x);
				verts.push_back(vertVec.at(i).getPos().y);
				verts.push_back(vertVec.at(i).getPos().z);

				coords.push_back(vertVec.at(i).getCoord().x);
				coords.push_back(vertVec.at(i).getCoord().y);

			}

			for (int i = 0; i < triVect.size(); i++) {

				faces.push_back(triVect.at(i).getVert1());
				faces.push_back(triVect.at(i).getVert2());
				faces.push_back(triVect.at(i).getVert3());

			}

			numIndicies = faces.size();


			// Create the shaders
			GLuint VertexShaderID = glCreateShader(GL_VERTEX_SHADER);
			GLuint FragmentShaderID = glCreateShader(GL_FRAGMENT_SHADER);
			std::string VertexShaderCode = "\
    			#version 330 core\n\
				// Input vertex data, different for all executions of this shader.\n\
				layout(location = 0) in vec3 vertexPosition;\n\
				layout(location = 1) in vec2 uv;\n\
				// Output data ; will be interpolated for each fragment.\n\
				out vec2 uv_out;\n\
				// Values that stay constant for the whole mesh.\n\
				uniform mat4 MVP;\n\
				void main(){ \n\
					// Output position of the vertex, in clip space : MVP * position\n\
					gl_Position =  MVP * vec4(vertexPosition,1);\n\
					// The color will be interpolated to produce the color of each fragment\n\
					uv_out = uv;\n\
				}\n";

			// Read the Fragment Shader code from the file
			std::string FragmentShaderCode = "\
				#version 330 core\n\
				in vec2 uv_out; \n\
				uniform sampler2D tex;\n\
				void main() {\n\
					gl_FragColor = texture(tex, uv_out);\n\
				}\n";
			char const* VertexSourcePointer = VertexShaderCode.c_str();
			glShaderSource(VertexShaderID, 1, &VertexSourcePointer, NULL);
			glCompileShader(VertexShaderID);

			// Compile Fragment Shader
			char const* FragmentSourcePointer = FragmentShaderCode.c_str();
			glShaderSource(FragmentShaderID, 1, &FragmentSourcePointer, NULL);
			glCompileShader(FragmentShaderID);

			//add and link shaders to program then detach and delete 
			shader = glCreateProgram();
			glAttachShader(shader, VertexShaderID);
			glAttachShader(shader, FragmentShaderID);
			glLinkProgram(shader);
			glDetachShader(shader, VertexShaderID);
			glDetachShader(shader, FragmentShaderID);
			glDeleteShader(VertexShaderID);
			glDeleteShader(FragmentShaderID);

			//bind texture
			glGenTextures(1, &bitMapImg);
			glBindTexture(GL_TEXTURE_2D, bitMapImg);
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_BGRA, GL_UNSIGNED_BYTE, data);
			glGenerateMipmap(GL_TEXTURE_2D);
			glBindTexture(GL_TEXTURE_2D, 0);

			matrixID = glGetUniformLocation(shader, "MVP");

			//create VAO
			glGenVertexArrays(1, &VAO); 
			glBindVertexArray(VAO);

			//bind verticies
			glGenBuffers(1, &vertexPos); 
			glBindBuffer(GL_ARRAY_BUFFER, vertexPos);
			glBufferData(GL_ARRAY_BUFFER, verts.size() * sizeof(float), verts.data(), GL_STATIC_DRAW);
			glEnableVertexAttribArray(0);
			glVertexAttribPointer(0,3,GL_FLOAT,GL_FALSE,0,(void*)0);

			//bind coordinates
			glGenBuffers(1, &textCoord);
			glBindBuffer(GL_ARRAY_BUFFER, textCoord);
			glBufferData(GL_ARRAY_BUFFER, coords.size() * sizeof(float), coords.data(), GL_STATIC_DRAW);
			glEnableVertexAttribArray(1);
			glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 0, (void*)0);

			//bind indicies
			glGenBuffers(1, &VertIndicies);
			glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, VertIndicies);
			glBufferData(GL_ELEMENT_ARRAY_BUFFER, faces.size() * sizeof(float), faces.data(), GL_STATIC_DRAW);

			//for safety
			glBindVertexArray(0);

		}//end constructor

		// This is the function used to draw the object
		void draw(glm::mat4 MVP) {

			//activate and enable textures 
			glActiveTexture(GL_TEXTURE0);
			glEnable(GL_TEXTURE_2D);
			glBindTexture(GL_TEXTURE_2D, bitMapImg);

			matrixID = glGetUniformLocation(shader, "MVP");

			//add shader
			glUseProgram(shader);
			glUniformMatrix4fv(matrixID, 1, GL_FALSE, &MVP[0][0]);

			//draw the elements that are in the VAO
			glBindVertexArray(VAO);
			glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, VertIndicies);
			glDrawElements(GL_TRIANGLES, numIndicies, GL_UNSIGNED_INT, 0);
			glBindVertexArray(0);
			glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);

			glUseProgram(0);
			glBindTexture(GL_TEXTURE_2D, 0);

			glDisable(GL_TEXTURE_2D);

		}//end draw

}; //end TexturedMesh


//key callback function
void buttonPressed(GLFWwindow* window, int key, int scancode, int action, int mods) {

	//If up is pressed move forward
	if (key == GLFW_KEY_UP && GLFW_PRESS) {
		glm::vec3 direction = glm::normalize(cameraPoint - cameraPos);

		cameraPos = cameraPos + (direction * 0.05f);
		cameraPoint = cameraPoint + (direction * 0.05f);
	}

	//If down is pressed move backward
	if (key == GLFW_KEY_DOWN && action == GLFW_PRESS) {

		glm::vec3 direction = glm::normalize(cameraPos - cameraPoint);

		cameraPos = cameraPos + (direction * 0.05f);
		cameraPoint = cameraPoint + (direction * 0.05f);
	}

	//If left is pressed rotate counter clockwise
	if (key == GLFW_KEY_LEFT && action == GLFW_PRESS) {

		glm::vec3 axis = glm::normalize(cameraUp); 
		glm::mat4 rotation = glm::rotate(glm::mat4(1.0f), glm::radians(3.0f), axis);

		
		cameraPos = glm::vec3(rotation * glm::vec4(cameraPos - cameraPoint, 1.0f)) + cameraPoint;
		cameraPoint = glm::vec3(rotation * glm::vec4(cameraPoint - cameraPos, 1.0f)) + cameraPos;

	}

	//If right is pressed rotate clockwise
	if (key == GLFW_KEY_RIGHT && action == GLFW_PRESS) {
		
		glm::vec3 axis = glm::normalize(cameraUp);
		glm::mat4 rotation = glm::rotate(glm::mat4(1.0f), glm::radians(-3.0f), axis);


		cameraPos = glm::vec3(rotation * glm::vec4(cameraPos - cameraPoint, 1.0f)) + cameraPoint;
		cameraPoint = glm::vec3(rotation * glm::vec4(cameraPoint - cameraPos, 1.0f)) + cameraPos;

	}

}//end button pressed


/// MAIN ///

int main(int argc, char* argv[]){

	// Initialise GLFW
	if (!glfwInit())
	{
		fprintf(stderr, "Failed to initialize GLFW\n");
		getchar();
		return -1;
	}

	// Open a window and create its OpenGL context
	float screenW = 1400;
	float screenH = 1000;
	window = glfwCreateWindow(screenW, screenH, "Assignment 4", NULL, NULL);
	if (window == NULL) {
		fprintf(stderr, "Failed to open GLFW window. If you have an Intel GPU, they are not 3.3 compatible. Try the 2.1 version of the tutorials.\n");
		getchar();
		glfwTerminate();
		return -1;
	}
	glfwMakeContextCurrent(window);

	// Initialize GLEW
	glewExperimental = true; 
	if (glewInit() != GLEW_OK) {
		fprintf(stderr, "Failed to initialize GLEW\n");
		getchar();
		glfwTerminate();
		return -1;
	}

	glViewport(0, 0, screenW, screenH);

	glEnable(GL_DEPTH_TEST);

	// Immediate mode 
	glClearColor(0.2f, 0.2f, 0.3f, 0.0f);

	//initialize view matrix 
	glm::mat4 view = glm::lookAt(cameraPos, cameraPoint, cameraUp);
	// Create Projection matrix 
	glm::mat4 projection = glm::perspective(glm::radians(45.0f), screenW / screenH, 0.01f, 3.0f);
	glm::mat4 MVP;


	//create all textured mesh objects
	TexturedMesh obj1 = TexturedMesh("Bottles.ply", "bottles.bmp");
	TexturedMesh obj2 = TexturedMesh("Floor.ply", "floor.bmp");
	TexturedMesh obj3 = TexturedMesh("Patio.ply", "patio.bmp");
	TexturedMesh obj4 = TexturedMesh("Table.ply", "table.bmp");
	TexturedMesh obj5 = TexturedMesh("Walls.ply", "walls.bmp");
	TexturedMesh obj6 = TexturedMesh("WindowBG.ply", "windowbg.bmp");
	TexturedMesh obj7 = TexturedMesh("WoodObjects.ply", "woodobjects.bmp");
	TexturedMesh obj8 = TexturedMesh("MetalObjects.ply", "metalobjects.bmp");
	TexturedMesh obj9 = TexturedMesh("Curtains.ply", "curtains.bmp");
	TexturedMesh obj10 = TexturedMesh("DoorBG.ply", "DoorBG.bmp");


	// render loop
	do{

		// Clear the screen
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		glfwPollEvents();
		
		// Create Projection matrix
		glMatrixMode(GL_PROJECTION);
		glPushMatrix(); 
		glm::mat4 projection = glm::perspective(glm::radians(45.0f), screenW / screenH, 0.01f, 10.0f);
		glLoadMatrixf(glm::value_ptr(projection));

		//grab key presses by setting callback function
		glfwSetKeyCallback(window, buttonPressed);

		//update view matrix
		glMatrixMode(GL_MODELVIEW);
		glPushMatrix();
		view = glm::lookAt(cameraPos, cameraPoint, cameraUp);
		glLoadMatrixf(glm::value_ptr(view));

		//make Mat matrix
		glm::mat4 M = glm::mat4(1.0f);

		//calculate MVP matrix
		MVP = projection * view * M;

		// run the draw of each object 
		obj1.draw(MVP);
		obj2.draw(MVP);
		obj3.draw(MVP);
		obj4.draw(MVP);
		obj5.draw(MVP);
		obj6.draw(MVP);
		obj7.draw(MVP);

		//make last few objects print transparent 
		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
		obj9.draw(MVP);
		obj8.draw(MVP);
		
		obj10.draw(MVP);
		glDisable(GL_BLEND);

		// Swap buffers
		glfwSwapBuffers(window);


	} while (glfwGetKey(window, GLFW_KEY_ESCAPE) != GLFW_PRESS && glfwWindowShouldClose(window) == 0);



	// Close OpenGL window and terminate GLFW
	glfwTerminate();

	return 0;

}//end main