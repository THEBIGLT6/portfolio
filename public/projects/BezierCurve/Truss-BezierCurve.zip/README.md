####Liam Truss 
####Cs 3388 - Assignment 3
####02-16-2024

## Args
Program must be passed in 2 command line arguments\
Argument 1: The width of the screen in pixels\
Argument 2: The height of the screen in pixels\

## Description
This assignment creates a program where a user can click on the screen creating points that join together to make \
a spline tool. After running the program when the user clicks on an empty space a point is made, as more points are\
made they will be joined together with a curve. Control points manipulate the curve, there is one control point on ends\
of the curve and 2 on middle points. Mouse interaction and clicking is used using glfw callback functions, when a point\
is clicked getMouseClick handles if there is a point already at that spot and if not, add one. getCursorPoint handles dragging,\
so if there is a point at that current spot and the mouse is held down, getCursorPoint will update the position of the point\
that is being dragged.\
\
All drawing of points is done in the drawing loop, the curve is drawn by taking the cubic Bezier curve of points A-B and the 2 \
control points between them. All points and control points are stored in their respective arrays. Regular points and control points\
are then also drawn to the screen. A dotted line is made from each point to its control point using GL_LINE_STIPPLE. Pressing the 'e'\
key at any time wipes the point arrays clean making the screen empty again.

## A note on anti-aliasing
In the assignment description it says we are to use 4 times multisampling for anti-aliasing. This is done by the line glfw.window_hint(glfw.SAMPLES, 4)\
which hints to the window to use 4 times multisampling and then glEnable(GL_MULTISAMPLE) enables multisampling. However, in my program\
the control points do not print as circles when the hint line is in the program (hence why it is commented out). Wasn't sure how to fix\
or why it is happening, but to keep the visual functionality the hint line is commented out, removing it will enable 4 times multisampling.
