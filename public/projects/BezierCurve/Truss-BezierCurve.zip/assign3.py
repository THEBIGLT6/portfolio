from OpenGL.GL import *
import glfw
import argparse
from collections import namedtuple
import math


# declare variables
points = []
cntrlPoints = []
buttonPress = False
index = -1
pointHere = False
cntrlPointHere = False
ePress = False


# create a collection for points
Point = namedtuple('Point', ['x', 'y' , 'hasHandle1', 'hasHandle2'])

# this function is used as a callback for whenever the mouse is clicked
def getMouseClick(window, button, action, mods):
    global index, pointHere, cntrlPointHere

    if button == glfw.MOUSE_BUTTON_LEFT and action == glfw.PRESS:

        # grab points
        xpos, ypos = glfw.get_cursor_pos(window)
        newYpos = screen_height - ypos

        # check if point is already there
        for i in range(len(points)):

            # create a certain area around the point where it can be selected
            if xpos+5 > points[i].x and xpos-5 < points[i].x and newYpos+5 > points[i].y and newYpos-5 < points[i].y:
                pointHere = True
                index = i
                break

        # check if control point is already there
        for i in range(len(cntrlPoints)):

            # create a certain area around the point where it can be selected
            if xpos+5 > cntrlPoints[i].x and xpos-5 < cntrlPoints[i].x and newYpos+5 > cntrlPoints[i].y and newYpos-5 < cntrlPoints[i].y:
                cntrlPointHere = True
                index = i
                break


        # if there is no point create a new one
        if(not pointHere and not cntrlPointHere):

            # find if point is closer to 0 index or highest

            # case where points is empty
            if(len(points) == 0 or len(points) == 1):
                newPoint = Point(x = xpos, y = newYpos, hasHandle1=False, hasHandle2=False)
                points.append(newPoint)

                cntrl = Point(x = xpos, y = newYpos + 50, hasHandle1=False, hasHandle2=False)
                cntrlPoints.append(cntrl)

            elif(len(points) > 1):

                # calculate the distance to see which point is closer
                d1 = math.sqrt((xpos-points[0].x)**2 + (newYpos-points[0].y)**2)
                d2 = math.sqrt((xpos-points[len(points)-1].x)**2 + (newYpos-points[len(points)-1].y)**2)

                # append to beginning of list
                if(abs(d1) <= abs(d2)):
                    newPoint = Point(x = xpos, y = newYpos, hasHandle1=False, hasHandle2=False)

                    xdif = cntrlPoints[0].x - points[0].x
                    ydif = cntrlPoints[0].y - points[0].y

                    # if there is already 2 control points dont add another
                    if(not points[0].hasHandle2):
                        cntrl = Point(x = points[0].x - xdif, y = points[0].y - ydif, hasHandle1=False, hasHandle2=False)
                        cntrlPoints.insert(0, cntrl)

                    cntrl2 = Point(x = xpos, y = newYpos + 50, hasHandle1=False, hasHandle2=False)
                    points.insert(0,newPoint)
                    cntrlPoints.insert(0, cntrl2)

                # append to end of list
                elif(abs(d1) > abs(d2)):
                    newPoint = Point(x = xpos, y = newYpos, hasHandle1=False, hasHandle2=False)

                    xdif = cntrlPoints[len(cntrlPoints)-1].x - points[len(points)-1].x
                    ydif = cntrlPoints[len(cntrlPoints)-1].y - points[len(points)-1].y

                    # if there is already 2 control points dont add another
                    if(not points[len(points)-1].hasHandle2):
                        cntrl = Point(x = points[len(points)-1].x - xdif, y = points[len(points)-1].y - ydif, hasHandle1=False, hasHandle2=False)
                        cntrlPoints.append(cntrl)

                    cntrl2 = Point(x = xpos, y = newYpos + 50, hasHandle1=False, hasHandle2=False)
                    points.append(newPoint)
                    cntrlPoints.append(cntrl2)


            # adjust handles if there is more than one, all points have two handles except the first and last
            if(len(points)>1):
                for i in range(len(points)):
                    if(i == 0  or i == len(points) - 1):
                        x = points[i].x
                        y = points[i].y
                        points[i] = Point(x = x, y = y, hasHandle1=True, hasHandle2=False)

                    else:
                        x = points[i].x
                        y = points[i].y
                        points[i] = Point(x = x, y = y, hasHandle1=True, hasHandle2=True)

    # reset index and pointHere when press is released
    elif action == glfw.RELEASE:
        pointHere = False
        cntrlPointHere = False
        index = -1

# this function grabs the point of the cursor so that when a point is being dragged its location is updated
def getCurserPoint(window, xpos, ypos):
    global pointHere, index, cntrlPointHere

    # handle if a regular point is clicked
    if pointHere and index != -1:

        hndle1 = points[index].hasHandle1
        hndle2 = points[index].hasHandle2

        # get differences for control points
        if(len(cntrlPoints) < 3 or index == 0):
            xdif = cntrlPoints[index].x - points[index].x
            ydif = cntrlPoints[index].y - points[index].y

            # Update the position of the clicked point when the mouse is dragged
            xpos, ypos = glfw.get_cursor_pos(window)
            points[index] = Point(x=xpos, y=screen_height - ypos, hasHandle1=hndle1, hasHandle2=hndle2)
            cntrlPoints[index] = Point(x=xpos + xdif, y=screen_height - ypos +ydif, hasHandle1=False, hasHandle2=False)

        # get the difference if there is more than 2 control points
        else:

            xdif = cntrlPoints[(index*2)-1].x - points[index].x
            ydif = cntrlPoints[(index*2)-1].y - points[index].y

            # Update the position of the clicked point when the mouse is dragged
            xpos, ypos = glfw.get_cursor_pos(window)
            points[index] = Point(x=xpos, y=screen_height - ypos, hasHandle1=hndle1, hasHandle2=hndle2)
            cntrlPoints[(index*2)-1] = Point(x=xpos + xdif, y=screen_height - ypos +ydif, hasHandle1=False, hasHandle2=False)

            if(points[index].hasHandle2):
                cntrlPoints[index*2] = Point(x=xpos - xdif, y=screen_height - ypos -ydif, hasHandle1=False, hasHandle2=False)

    # handle if a control point is clicked
    elif cntrlPointHere and index !=-1:

        # if the index is the first or last then there is only 1 control point
        if(index == len(cntrlPoints)-1 or index == 0):
            xpos, ypos = glfw.get_cursor_pos(window)
            cntrlPoints[index] = Point(x=xpos, y=screen_height - ypos, hasHandle1=False, hasHandle2=False)

        # handle if there are 2 control points
        else:

            xpos, ypos = glfw.get_cursor_pos(window)
            cntrlPoints[index] = Point(x=xpos, y=screen_height - ypos, hasHandle1=False, hasHandle2=False)

            # get the difference
            xdif = cntrlPoints[index].x - points[(index+1) // 2].x
            ydif = cntrlPoints[index].y - points[(index+1) // 2].y


            # if it is the top cntrl being moved then move the bottom, vice versa
            if(index % 2 == 0):
                cntrlPoints[index-1] = Point(x=points[(index+1) // 2].x - xdif, y=points[(index+1) // 2].y - ydif, hasHandle1=False, hasHandle2=False)

            else:
                cntrlPoints[index+1] = Point(x=points[(index+1) // 2].x - xdif, y=points[(index+1) // 2].y - ydif, hasHandle1=False, hasHandle2=False)



# Handle arguments passed in
parser = argparse.ArgumentParser(description='Argument Parser')
parser.add_argument('width')
parser.add_argument('height')
args = parser.parse_args()
screen_width = int(args.width)
screen_height = int(args.height)


glfw.init()

# hint to create samples
#glfw.window_hint(glfw.SAMPLES, 4)

# create the window
window = glfw.create_window(screen_width, screen_height, "Assignment 3", None, None)
glfw.make_context_current(window)


# make viewport
glOrtho(0, screen_width, 0, screen_height, -1, 1)
glViewport(0, 0, screen_width, screen_height)

# Set the background colour to white
glClearColor(1.0, 1.0, 1.0, 1.0)
glPointSize(10.0)

# set callback functions
glfw.set_mouse_button_callback(window, getMouseClick)
glfw.set_cursor_pos_callback(window, getCurserPoint)

# run loop
while not glfw.window_should_close(window):
    glfw.poll_events()

    glClear(GL_COLOR_BUFFER_BIT)

    # enable multisampling
    glEnable(GL_MULTISAMPLE)


    # if e is pressed wipe everything
    if(glfw.get_key(window,glfw.KEY_E)):
        points = []
        cntrlPoints = []

    # render the spline
    glColor3f(0.0, 0.0, 0.0)
    glLineWidth(2.0)
    glEnable(GL_LINE_SMOOTH)
    glEnable(GL_BLEND)
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)

    # make 1 less lines than points
    for i in range(len(points)-1):

        # split into 200 values and calculate x y
        glBegin(GL_LINE_STRIP)
        for j in range (200):

            t = j/200
            valX = ((1-t)**3 * points[i].x) + (3*((1-t)**2)*t*cntrlPoints[i*2].x) + 3*(1-t)*(t**2)*cntrlPoints[i*2+1].x + (t**3) * points[i+1].x
            valY = ((1-t)**3 * points[i].y) + (3*((1-t)**2)*t*cntrlPoints[i*2].y) + 3*(1-t)*(t**2)*cntrlPoints[i*2+1].y + (t**3) * points[i+1].y

            glVertex2f(valX, valY)

        glEnd()


    # print points of the curve
    glColor3f(0.0, 0.0, 1.0)
    glBegin(GL_POINTS)
    for i in range(len(points)):
        glVertex2f(points[i].x, points[i].y)
    glEnd()

    # print control points
    glColor3f(0.0, 0.0, 0.0)
    glEnable(GL_POINT_SMOOTH)
    glEnable(GL_BLEND)
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
    glBegin(GL_POINTS)
    for i in range(len(cntrlPoints)):
        glVertex2f(cntrlPoints[i].x, cntrlPoints[i].y)
    glEnd()
    glDisable(GL_POINT_SMOOTH)

    # render dotted line
    glColor3f(0.0, 0.2, 0.7)
    glEnable(GL_LINE_STIPPLE)
    glLineStipple(1, 0xF)

    for i in range(len(cntrlPoints)):
        glBegin(GL_LINES)
        glVertex2f(cntrlPoints[i].x, cntrlPoints[i].y)
        glVertex2f(points[(i + 1) //2].x, points[(i + 1) //2].y)
        glEnd()

    glDisable(GL_LINE_STIPPLE)


    glfw.swap_buffers(window)

glfw.terminate()
