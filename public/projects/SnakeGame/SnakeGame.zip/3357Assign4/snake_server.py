import numpy as np
import socket
from _thread import *
import pickle
from snake import SnakeGame
import uuid
import time
import threading
import rsa


# server = "10.11.250.207"
server = "localhost"
port = 5555
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

counter = 0
rows = 20

# generate RSA keys
server_public, server_private = rsa.newkeys(1024)

try:
    s.bind((server, port))
except socket.error as e:
    str(e)

s.listen(2)
# s.settimeout(0.5)
print("Waiting for a connection, Server Started")

game = SnakeGame(rows)
game_state = ""
last_move_timestamp = time.time()
interval = 0.2
moves_queue = set()

# this method sends out the message that is passed in to all clients
def sendMsg(message, unique_id):

    message = message + "userid::" + unique_id

    # Send the message to each client n the server
    for i in range(len(clients)):

        rsaCode = rsa_keys[i]
        clients[i].send(rsa.encrypt(message.encode(), rsaCode))


def listen(conn, unique_id):
    while True:
        data = rsa.decrypt(conn.recv(500), server_private).decode()

        move = None
        if data.startswith("msg:"):

            sendMsg(data, unique_id)

        else:
            if not data:
                break
            elif data == "mv:get":
                pass
            elif data == "mv:quit":
                print("received quit")
                game.remove_player(unique_id)
                conn.send("quit".encode())
                key = rsa_keys[clients.index(conn)]
                clients.remove(conn)
                usernames.remove(unique_id)
                rsa_keys.remove(key)
                conn.close()
                if len(clients) == 0:
                    print("No players remain... ending server")
                break
            elif data == "mv:reset":
                game.reset_player(unique_id)

            elif data in ["mv:up", "mv:down", "mv:left", "mv:right"]:
                move = data[3:]
                moves_queue.add((unique_id, move))
            else:
                print("Invalid data received from client:", data)

            conn.send("gs:".encode() + game_state.encode() + ":end".encode())

    exit()


def game_thread():
    global game, moves_queue, game_state
    while True:
        last_move_timestamp = time.time()
        game.move(moves_queue)
        moves_queue = set()
        game_state = game.get_state()
        while time.time() - last_move_timestamp < interval:
            time.sleep(0.1)


rgb_colors = {
    "red": (255, 0, 0),
    "green": (0, 255, 0),
    "blue": (0, 0, 255),
    "yellow": (255, 255, 0),
    "orange": (255, 165, 0),
}
rgb_colors_list = list(rgb_colors.values())

clients = []
usernames = []
rsa_keys = []

def main():
    global counter, game

    while True:
        conn, addr = s.accept()
        print("Connected to:", addr)

        unique_id = str(uuid.uuid4())
        color = rgb_colors_list[np.random.randint(0, len(rgb_colors_list))]
        game.add_player(unique_id, color=color)
        clients.append(conn)
        usernames.append(unique_id)

        conn.send(server_public.save_pkcs1("PEM"))
        msg = rsa.PublicKey.load_pkcs1(conn.recv(500))
        rsa_keys.append(msg)

        if (len(clients) == 1):
            start_new_thread(game_thread, ())

        thread = threading.Thread(target=listen, args=(conn, unique_id))
        thread.start()


if __name__ == "__main__":
    main()
