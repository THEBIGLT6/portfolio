# Liam Truss,  251224539,  ltruss@uwo.ca
# Computer Networks 3357 Assignment 4
# December 8th, 2023
#
# This program acts as the client side for a snake game that connects
# to a server, it sends the users moves to the game and allows the user to play the game
#
# This is the extension of the client side that allows the user to send messages in a chatroom and integrates encryption

import socket
import pygame
import time
import threading
import rsa

queue = []


# generate RSA keys
client_public, client_private = rsa.newkeys(1024)

# This method displays the game state to the screen after recieving the input from the server
def drawSnake(gameState):

    # break up string and create arrays
    gameState = gameState[:-4]
    arr = []
    snakes = []
    fruits = []
    coord = []
    arr = gameState.split("|")

    snakes = arr[0].split("**")
    fruits = arr[1].split("**")

    # draw each fruit onto the screen
    for fruit in fruits:

        fruit = fruit.strip("()")
        coord = fruit.split(",")
        coord[1] = coord[1].strip()

        coord[0] = int(coord[0])
        coord[1] = int(coord[1])


        pygame.draw.rect(win, (0,255,0) , (coord[0]*25+1,coord[1]*25+1, 25-2, 25-2))

    num = 0
    # draw each snake onto the screen
    for snake in snakes:

        # break up the snakes into individual cubes
        index = 0

        # set colors of snakes

        if(num % 5 == 0):
            color = (255, 0, 0)
        elif(num % 5 == 1):
            color = (0, 0, 255)
        elif(num % 5 == 2):
            color = (255, 255, 0)
        elif(num % 5 == 3):
            color = (255, 165, 0)
        else:
            color = (255, 255, 255)

        snakeNew = snake.split("*")
        for piece in snakeNew:
            piece = piece.strip("()")
            coord = piece.split(",")
            coord[1] = coord[1].strip()

            coord[0] = int(coord[0])
            coord[1] = int(coord[1])

            # draw the piece of snake
            pygame.draw.rect(win, color, (coord[0]*25+1,coord[1]*25+1, 25-2, 25-2))

            # draw eyes if it is the first block
            if(index == 0):
                centre = 12
                radius = 3
                circleMiddle = (coord[0]*25+centre-radius,coord[1]*25+8)
                circleMiddle2 = (coord[0]*25 + 25 -radius*2, coord[1]*25+8)
                pygame.draw.circle(win, (0,0,0), circleMiddle, radius)
                pygame.draw.circle(win, (0,0,0), circleMiddle2, radius)

                index += 1
        num += 1


# this function draws the grid for the board
def drawGrid(window):
    size = 500 // 20

    x = 0
    y = 0
    for z in range(20):
        x = x + size
        y = y + size
        pygame.draw.line(win, (255,255,255), (x,0),(x,500))
        pygame.draw.line(win, (255,255,255), (0,y),(500,y))

# this function redraws the window of the game
def drawWin(window, gameState):
    window.fill((0,0,0))
    drawGrid(window)
    drawSnake(gameState)
    pygame.display.update()


# This method is used to send public messages to the group
def writeMsg(clientSock):
    while True:
        message = "msg:" + input()

        if message == 'msg:quit':
            exit()

        queue.append(message)

#this method prints the message sent by other users


# server = "10.11.250.207"
server = "localhost"
port = 5555


# connect to server
client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client_socket.connect((server, port))

server_public = rsa.PublicKey.load_pkcs1(client_socket.recv(500))
client_socket.send(client_public.save_pkcs1("PEM"))



print("Succesfully connected to server")

time.sleep(1)

print("Building snake game...")

time.sleep(1)



# draw the game window and set up clock
win = pygame.display.set_mode((500, 500))
clock = pygame.time.Clock()

writingThread = threading.Thread(target=writeMsg, args=(client_socket,))
writingThread.start()

print("Game built! ... Type to begin chatting")

# main game loop
while True:

    sendGet = True

    # if there is an event check if it is a key press and then handle that press
    if(len(queue) == 0):
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP or event.key == pygame.K_w:
                    message = "mv:up"
                    client_socket.send(rsa.encrypt(message.encode(), server_public))
                    sendGet = False
                if event.key == pygame.K_DOWN or event.key == pygame.K_s:
                    message = "mv:down"
                    client_socket.send(rsa.encrypt(message.encode(), server_public))
                    sendGet = False
                if event.key == pygame.K_LEFT or event.key == pygame.K_a:
                    message = "mv:left"
                    client_socket.send(rsa.encrypt(message.encode(), server_public))
                    sendGet = False
                if event.key == pygame.K_RIGHT or event.key == pygame.K_d:
                    message = "mv:right"
                    client_socket.send(rsa.encrypt(message.encode(), server_public))
                    sendGet = False
                if event.key == pygame.K_r:
                    message = "mv:reset"
                    client_socket.send(rsa.encrypt(message.encode(), server_public))
                    sendGet = False
                if event.key == pygame.K_q:
                    message = "mv:quit"
                    client_socket.send(rsa.encrypt(message.encode(), server_public))
                    sendGet = False
                    print("Client has quit the game ... type 'quit' to close terminal")
                    pygame.quit()
                    client_socket.close()
                    exit(1)

                # hardcoded preset messages
                if event.key == pygame.K_z:
                    message = "msg:Good game!"
                    client_socket.send(rsa.encrypt(message.encode(), server_public))
                    sendGet = False

                if event.key == pygame.K_x:
                    message = "msg:Congratulations!"
                    client_socket.send(rsa.encrypt(message.encode(), server_public))
                    sendGet = False

                if event.key == pygame.K_c:
                    message = "msg:Nice Move!"
                    client_socket.send(rsa.encrypt(message.encode(), server_public))
                    sendGet = False

        if (sendGet):
            message = "mv:get"
            client_socket.send(rsa.encrypt(message.encode(), server_public))

    else:
        for x in queue:
            message = queue.pop(0)
            client_socket.send(rsa.encrypt(message.encode(), server_public))

    # receive message
    recvd = client_socket.recv(1024)

    try:
        testRecv = recvd.decode()
        if(testRecv.startswith("gs:")):
            gameState = testRecv
            gameState = gameState[3:]
            pygame.time.delay(50)
            clock.tick(10)
            drawWin(win, gameState)

    except:

        if(recvd.startswith("gs:".encode())):
            index = recvd.find(":end".encode())
            recvd = recvd[index+4:]
        gameState = rsa.decrypt(recvd,client_private).decode()
        id = gameState.find("userid::")
        message = gameState[4:id]
        user = gameState[id+8:]

        message = "User " + user + " says:" + message
        print(message)
