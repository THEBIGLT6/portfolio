﻿This program uses Western's building maps to provide users with an opportunity to explore its interior spaces. The application enables users to easily locate rooms within buildings, discover points of interest, navigate through the maps available, and even create and save their own personalized points of interest. 


Required Libraries:
Java Swing - Version 1.1.1
Java AWT - Version 1.1.1
Java IO - Version 2.1.1
Java Net - Version 1.1.1
Java Util - Version 1.1.1
Javax ImageIO - Version 1.1.1
JSON Simple - Version 1.1.1


How to Install the Required Libraries:
Java Swing: Java Swing is included in the Java SE platform, which can be downloaded from Oracle's website: https://www.oracle.com/java/technologies/javase-downloads.html.


Java AWT: Java AWT is also included in the Java SE platform.


Java IO: Java IO is also included of the Java SE platform 


Java Net: Java Net is also included in the Java SE platform.


Java Util: Java Util is also included of the Java SE platform 


Javax ImageIO: Javax ImageIO is also included of the Java SE platform 


JSON Simple: To use JSON Simple, you will first need to download the library from the project's GitHub page: https://github.com/fangyidong/json-simple.


After ensuring that the required libraries are installed, you can continue to install WesternMaps. You can either clone the repository from https://repo.csd.uwo.ca/scm/compsci2212_w2023/group31.git or download and extract the .zip from OWL. 


After doing so, locate the westernmaps.jar file and run it to open the program.
The program can be navigated with the cursor and the keyboard. Everything in the User-Interface is already labelled and is easily identifiable.. The “Help” button on the menu bar contains information about all program features and how to use them.


How to Access Developer Mode:
First, navigate to the “Edit” button located on the menu bar. Enter in the following information to gain access to developer mode.
Username: Developer
Password: WesternMaps


To exit Developer Mode, navigate to the “Edit” button located on the menu bar. Enter in the following information to exit developer mode.
Username: Developer
Password: hunter2


Developed by Andrea Bavaro, Samuel Kahessay, Armaan Mahajan, Dylan Patrascu, and Liam Truss.