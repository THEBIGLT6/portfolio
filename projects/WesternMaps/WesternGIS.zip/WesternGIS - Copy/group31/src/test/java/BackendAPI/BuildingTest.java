/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit3TestClass.java to edit this template
 */
package BackendAPI;

import org.json.simple.JSONObject;


import java.io.File;
import java.util.Iterator;
import java.util.LinkedList;
import javax.imageio.ImageIO;
import junit.framework.TestCase;
import java.util.*;
import javax.imageio.*;
import java.awt.image.*;
import java.io.*;

/**
 * This file contains test cases for all backend features
 * 
 * @date 2023-04-03
 * @author Liam T
 */
public class BuildingTest extends TestCase {
    
    public BuildingTest(String testName) {
        super(testName);
    }
    
    @Override
    protected void setUp() throws Exception {
        super.setUp();

    }
    
    @Override
    protected void tearDown() throws Exception {
        super.tearDown();
    }

    /**
     * This test constructs the 3 buildings and then makes sure that all the building information is correct, this will ensure that
     * our metadata file can be read and then store the building names correctly along with the number of floors for each building
     */
    public void testConstructNames() {
        
        String result1 = "Middlesex College";
        String result2 = "Alumni Hall";
        String result3 = "Physics And Astronomy";
        
        int result4 = 5;
        int result5 = 3;
        int result6 = 4;
        
        //construct building objects
        Building build1 = new Building("MiddlesexCollege");
        Building build2 = new Building("AlumniHall");
        Building build3 = new Building("PhysicsAndAstronomy");
        
        //compare all equals statements
        assertEquals(result1, build1.getName());
        assertEquals(result2, build2.getName());
        assertEquals(result3, build3.getName());
        
        assertEquals(result4, build1.getNumFloors());
        assertEquals(result5, build2.getNumFloors());
        assertEquals(result6, build3.getNumFloors());
    }//end testConstruct names
    
     /**
     * 
     * This method tests to make sure that floors were properly constructed in the process of also constructing buildings
     * Floor images are tested to ensure that images were loaded in correctly
     * This also tests to make sure that getFloorArr returns an acurate array that has all floors line up accoridngly
     */
    public void testFloorPNGs() {
        
        int result = 1;
        
        //construct building objects and go to floors to test
        Building build1 = new Building("MiddlesexCollege");
        BufferedImage floorPNG1 = null;
        BufferedImage floorPNG2 = null;
        BufferedImage floorPNG3 = null;
        BufferedImage floorPNG4 = null;
        BufferedImage floorPNG5 = null;
        
        Floor[] floors = build1.getFloorArr();
        Floor floor1 = floors[0];
        Floor floor2 = floors[1];
        Floor floor3 = floors[2];
        Floor floor4 = floors[3];
        Floor floor5 = floors[4];
        
        //load PNGs from file
        try{
            floorPNG1 = ImageIO.read(new File("src/main/resources/MSC1.png"));
            floorPNG2 = ImageIO.read(new File("src/main/resources/MSC2.png"));
            floorPNG3 = ImageIO.read(new File("src/main/resources/MSC3.png"));
            floorPNG4 = ImageIO.read(new File("src/main/resources/MSC4.png"));
            floorPNG5 = ImageIO.read(new File("src/main/resources/MSC5.png"));
        } catch (Exception e){
            System.out.println("Error reading image");
        }
   
        
        //check each pixel to ensure that the images are the same
        for (int y = 0; y < floorPNG1.getHeight(); y++) {
            for (int x = 0; x < floorPNG1.getWidth(); x++) {
            
            if (floor1.getImage().getRGB(x, y) != floorPNG1.getRGB(x, y)) {result = 2;}
            if (floor2.getImage().getRGB(x, y) != floorPNG2.getRGB(x, y)) {result = 2;}
            if (floor3.getImage().getRGB(x, y) != floorPNG3.getRGB(x, y)) {result = 2;}
            if (floor4.getImage().getRGB(x, y) != floorPNG4.getRGB(x, y)) {result = 2;}
            if (floor5.getImage().getRGB(x, y) != floorPNG5.getRGB(x, y)) {result = 2;}
            }//end for x
        }//end for y
       
         
        //make sure that result is still 1 and was never set to 2
        assertEquals(1, result);
        
    

    
    }//end testFloorPNGs
    
    
    /**
     * This function makes sure that there is the same amount of layers in the buildings as there is in the metadata file
     * 
     */
    public void testLayersCount(){
        
        //construct building objects
        Building build1 = new Building("MiddlesexCollege");
        Building build2 = new Building("AlumniHall");
        Building build3 = new Building("PhysicsAndAstronomy");
        
        int numLayers = 0;
        
        //run a for loop to iterate through all of the floors to gather all of the layers
        for(int i = 0; i < build1.getFloorList().size(); i++){
            
            Floor floor = build1.getFloorList().get(i);
            
            numLayers = numLayers + floor.getLayerList().size();
            
        }//end for
        
        for(int i = 0; i < build2.getFloorList().size(); i++){
            
            Floor floor = build1.getFloorList().get(i);
            
            numLayers = numLayers + floor.getLayerList().size();
            
        }//end for
        
        for(int i = 0; i < build3.getFloorList().size(); i++){
            
            Floor floor = build1.getFloorList().get(i);
            
            numLayers = numLayers + floor.getLayerList().size();
            
        }//end for
        
        //test to make sure there is the right number of layers
        assertEquals(71, numLayers);
        
    }//end testLayers
    
    
   
    
    /**
     * This method tests to make sure that when the display layer function is run then the visibility of every POI in that layer is set to true
     * Then when the hide layer function is invoked then every POI should then return to false visibility 
     * 
     * This function also tests .getFloor   and .getLayerByName
     * 
     */
    public void testDisplayLayerHideLayer() {
        
        //construct building, floor and layer objects
        Building build1 = new Building("MiddlesexCollege");
        Floor floor = build1.getFloor(1);
        Layer layer = floor.getLayerByName("User Created");
        LinkedList<POI> pois = layer.getPOIList();
        
        assertEquals("User Created", layer.getName());
        
        int passFail = 1;
        
        //by default layer visibility should be set to false
        if(layer.getVis()){passFail = 2;}
        
        for(int i = 0; i < pois.size(); i++){
            
            if(pois.get(i).isVisible()) passFail = 2;
            
        }
        
        //set the layer to visible
        layer.displayLayer();
        
        //check that everything was set to true
        if(!layer.getVis()){passFail = 2;}
        
        for(int i = 0; i < pois.size(); i++){
            
            if(!pois.get(i).isVisible()) passFail = 2;
            
        }
        
        //set the layer to invisible
        layer.hideLayer();
        
        //check that everything was set to false
        if(layer.getVis()){passFail = 2;}
        
        for(int i = 0; i < pois.size(); i++){
            
            if(pois.get(i).isVisible()) passFail = 2;
            
        }
        
        
        //create a layer that shouldn't be able to have its vis altered
        layer = floor.getLayerByName("Accessibility");
        pois = layer.getPOIList();
        
        //set the layer to visible
        layer.displayLayer();
        
        //set the layer to invisible (should't work)
        layer.hideLayer();
        
        //check that visiblility was not changed
        if(!layer.getVis()){passFail = 2;}
        
        for(int i = 0; i < pois.size(); i++){
            
            if(!pois.get(i).isVisible()) passFail = 2;
            
        }
        
        //test the passFail was never to set to 2
        assertEquals(1,passFail);
        
        
        
    }
    
    
    /**
     * This method tests to make sure that when the hide layer Override function is run, the visibility of every POI is set to false no matter the state of isBuiltIn
     * 
     */
    public void testHideLayerOverride() {
        
        //construct building, floor and layer objects
        Building build1 = new Building("MiddlesexCollege");
        Floor floor = build1.getFloor(1);
        Layer layer = floor.getLayerByName("Accessibility");
        LinkedList<POI> pois = layer.getPOIList();
     
        int passFail = 1;
        
        //by default layer visibility should be set to false
        if(layer.getVis()){passFail = 2;}
        
        for(int i = 0; i < pois.size(); i++){
            
            if(pois.get(i).isVisible()) {passFail = 2;}
            
        }
    
    
    
        //set the layer to visible
        layer.displayLayer();
        
        //check that everything was set to true
        if(!layer.getVis()){passFail = 2;}
        
        for(int i = 0; i < pois.size(); i++){
            
            if(!pois.get(i).isVisible()) passFail = 2;
            
        }
        
        
        //set the layer to invisible (should work since it is override)
        layer.hideLayerOverride();
           
        
        //check that everything was set to false
        if(layer.getVis()){passFail = 2;}
        
        for(int i = 0; i < pois.size(); i++){
            
            if(pois.get(i).isVisible()) passFail = 2;
            
        }
        
        
        //test to make sure test passes
        assertEquals(1,passFail);
        
    }
    
    
    /**
     * This method tests to make sure that the setVisByPOI method in the layers class works correctly
     * This will also test the getPOIByName function as we will use it to find the POI
     * This method also tests the constructor of POIs, POIs would not be able to be found if not created correctly
     */
    public void testSetVisByPOI() {
    
        //construct building, floor and layer objects
        Building build1 = new Building("MiddlesexCollege");
        Floor[] floors = build1.getFloorArr();
        Floor floor = floors[0];
        Layer layer = floor.getLayerByName("Accessibility");
        Layer layer2 = floor.getLayerByName("Classroom");
        Layer layer3 = floor.getLayerByName("Washroom");
        
        //start changing the visibility of POIs
        layer.setPOIVisibility("Elevator 1", true);
        layer2.setPOIVisibility("MC17", true);
        layer3.setPOIVisibility("Mens Washroom 1", true);
        
        
        //use layer .getPOIbyName to find the correct poi
        POI found = layer.getPOIByName("Elevator 1");
        POI found2 = layer2.getPOIByName("MC17");
        POI found3 = layer3.getPOIByName("Mens Washroom 1");
        
        
        //make sure pois found are the same names they should be
        assertEquals("Elevator 1", found.getName());
        assertEquals("MC17", found2.getName());
        assertEquals("Mens Washroom 1", found3.getName());
        
        //make sure that their visibility has also changed
        assertEquals(true,found.isVisible());
        assertEquals(true,found2.isVisible());
        assertEquals(true,found3.isVisible());
     
        
    }
    
    /**
     * This method tests adding and removing POIs from the linked list of POIs in a layer
     * This method also tests that the find function in layers works
     * This method also tests that getPOIByName will return false when the POI does not exist
     */
    public void testAddRemPOI() {
        
        int passFail = 1;
        
        //construct building, floor and layer objects
        Building build1 = new Building("MiddlesexCollege");
        Floor[] floors = build1.getFloorArr();
        Floor floor = floors[0];
        Layer layer1 = floor.getLayerByName("Washroom");
        
        //grab a POI from one layer
        POI toAdd = layer1.getPOIByName("Mens Washroom 1");
        
        //add the POI to a layer that does exist and a layer that does not exist (DNE should not throw exception but return null)
        floor.addPOI("Classroom", toAdd);
        assertEquals(false,floor.addPOI("DNE", toAdd));
        
        //check that Classroom now contains the POI toAdd
        Layer classroom = floor.getLayerByName("Classroom");
        
        assertEquals(toAdd, classroom.getPOIByName("Mens Washroom 1"));
        
        //test the passFail was never to set to 2
        assertEquals(1,passFail);
        
        //now remove the POI toAdd from the layer
        floor.removePOI("Classroom", "Mens Washroom 1");
        
        classroom = floor.getLayerByName("Classroom");
        
        //null should be returned when looking for a POI that does not exist
        assertEquals(null, classroom.getPOIByName("Mens Washroom 1"));
        
    }
    
    /*
    * This method tests up most features in the program and creates the entire backend to the project
    * This is the integration test for the backend to finally assure that all backend testing is running uniformly
    * The idea behimd these tests is to test all methods so that no exceptions are thrown or null is stored
    */
    public void testIntegration() {
        
        
        //variables
        Floor currFloor;
        Layer currLayer;
        POI currPOI;
        int passFail = 1;
        
        //construct building objects
        Building build1 = new Building("MiddlesexCollege");
        Building build2 = new Building("AlumniHall");
        Building build3 = new Building("PhysicsAndAstronomy");
        
        //set middleSex to visible
        build1.setVisibility(true);
        
        Floor[] floors = build1.getFloorArr(); 
        
        //set each POI on the first floor to true
        for(int i = 0; i < floors.length; i++){
            
            //test all floor numbers are correct
            assertEquals(i,floors[i].getFloorNum() + -1);
            
            LinkedList<Layer> lays = floors[i].getLayerList();
            
            //test that all layers can be accessed and there name is reached (nothing is null)
            for(int j= 0; j < lays.size(); j++){
                
                currLayer = lays.get(j);
                
                //check to make sure that the layer isn't null 
                if(currLayer != null && currLayer.getName() != null){
                    
                  LinkedList<POI> pois = currLayer.getPOIList();
                  
                  for(int k = 0; k < pois.size(); k++){
                      
                      currPOI = pois.get(k);
                      
                      //make sure that there is no null POI
                      if(currPOI == null || currPOI.getName() == null)passFail = 2;
                      
                  }
                    
                }
                else passFail = 2;
            }
            
        }
        
       //run tests for other buildings
       
       floors = build2.getFloorArr(); 
       
       //set each POI on the first floor to true
        for(int i = 0; i < floors.length; i++){
            
            //test all floor numbers are correct
            assertEquals(i,floors[i].getFloorNum() -1);
            
            LinkedList<Layer> lays = floors[i].getLayerList();
            
            //test that all layers can be accessed and there name is reached (nothing is null)
            for(int j= 0; j < lays.size(); j++){
                
                currLayer = lays.get(j);
                
                //check to make sure that the layer isn't null 
                if(currLayer != null && currLayer.getName() != null){
                    
                  LinkedList<POI> pois = currLayer.getPOIList();
                  
                  for(int k = 0; k < pois.size(); k++){
                      
                      currPOI = pois.get(k);
                      
                      //make sure that there is no null POI
                      if(currPOI == null || currPOI.getName() == null)passFail = 2;
                      
                  }
                    
                }
                else passFail = 2;
            }
            
        }
        
        //run tests for other buildings
       
       floors = build3.getFloorArr(); 
       
       //set each POI on the first floor to true
        for(int i = 0; i < floors.length; i++){
            
            //test all floor numbers are correct
            assertEquals(i,floors[i].getFloorNum() -1);
            
            LinkedList<Layer> lays = floors[i].getLayerList();
            
            //test that all layers can be accessed and there name is reached (nothing is null)
            for(int j= 0; j < lays.size(); j++){
                
                currLayer = lays.get(j);
                
                //check to make sure that the layer isn't null 
                if(currLayer != null && currLayer.getName() != null){
                    
                  LinkedList<POI> pois = currLayer.getPOIList();
                  
                  for(int k = 0; k < pois.size(); k++){
                      
                      currPOI = pois.get(k);
                      
                      //make sure that there is no null POI
                      if(currPOI == null || currPOI.getName() == null)passFail = 2;
                      
                  }
                    
                }
                else passFail = 2;
            }
            
        }
        
        //make sure passFail was never set to 2
        assertEquals(1,passFail);
        
    }
        
}
