package BackendAPI;

/**
 * POIInfo is a class that represents a Point of Interest (POI) along with
 * its associated building and floor. It provides methods for accessing the
 * POI, building, and floor information. This class is useful when working
 * with maps, indoor navigation, or location-based services.
 *
 * @author Samuel Kahessay
 * @version 1.0
 */
public class POIInfo {
    private POI poi;
    private Building building;
    private Floor floor;

    /**
     * Constructs a POIInfo object with the specified POI, building, and floor.
     *
     * @param poi      The POI (Point of Interest) associated with this object.
     * @param building The building in which the POI is located.
     * @param floor    The floor within the building on which the POI is located.
     */
    public POIInfo(POI poi, Building building, Floor floor) {
        this.poi = poi;
        this.building = building;
        this.floor = floor;
    }

    /**
     * Retrieves the POI (Point of Interest) associated with this object.
     *
     * @return The POI associated with this object.
     */
    public POI getPOI() {
        return poi;
    }

    /**
     * Retrieves the building in which the POI is located.
     *
     * @return The building associated with this object.
     */
    public Building getBuilding() {
        return building;
    }

    /**
     * Retrieves the floor within the building on which the POI is located.
     *
     * @return The floor associated with this object.
     */
    public Floor getFloor() {
        return floor;
    }

    /**
     * Returns a string representation of the POIInfo object, which is
     * the name of the associated POI.
     *
     * @return A string representing the name of the POI.
     */
    @Override
    public String toString() {
        return poi.getName();
    }
}
