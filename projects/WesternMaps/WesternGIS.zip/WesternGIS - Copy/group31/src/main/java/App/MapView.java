package App;

import javax.swing.*;
import java.util.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import BackendAPI.*;
/**
 * MapView class for displaying and managing a map with pins representing Points of Interest (POIs).
 * @author Armaan Mahajan, Andrea Diano-Bavaro, Samuel Kahessay
 * @version 1.0
 */
public class MapView extends JPanel {
    private BufferedImage mapImage;
    private final ArrayList<Point> pins;
    private LinkedList<Layer> layers;
    private static final int PIN_RADIUS = 4;
    private int draggingPinIndex = -1;
    private boolean dragging = false;
    private Building currBuilding;
    private int currFloor;
    private POIPanel panel;


    /**
     * Constructor for MapView class.
     *
     * @param poiPanel POIPanel object for managing POIs.
     */
    public MapView(Building building, int floor, POIPanel panel) {
        this.currBuilding = building;
        this.panel = panel;
        this.currFloor = floor;
        pins = new ArrayList<>();
        layers = currBuilding.getFloor(currFloor+1).getLayerList();
        
        loadMapImage();
        setPreferredSize(new Dimension(mapImage.getWidth(), mapImage.getHeight()));
        initializeListeners();

        Floor[] floorArray = currBuilding.getFloorArr();
        if (floorArray != null && floorArray.length > 0) {
            this.currFloor = floorArray[0].getFloorNum();
        } else {
            System.err.println("Error: Could not initialize the current floor.");
            return;
        }
    }
    

    /**
     * Initializes mouse event listeners.
     */
    private void initializeListeners() {
        MouseAdapter adapter = new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                handleMouseClicked(e);
            }

            @Override
            public void mousePressed(MouseEvent e) {
                draggingPinIndex = findPinIndex(e.getPoint());
                dragging = draggingPinIndex != -1;
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                dragging = false;
                draggingPinIndex = -1;
            }

            @Override
            public void mouseDragged(MouseEvent e) {
                if (dragging) {
                    updatePinPosition(draggingPinIndex, e.getPoint());
                }
            }
        };

        addMouseListener(adapter);
        addMouseMotionListener(adapter);
    }
    
    /**
     * This method handles what happens when a mouse is clicked
     * 
     * @param e: parameter for handle mouse clicked
     */
    private void handleMouseClicked(MouseEvent e) {
        if (SwingUtilities.isLeftMouseButton(e)) {
            removeAllPins();
            if (!dragging) {
                Point point = e.getPoint();

                // Check if the clicked point is on an existing pin
                int pinIndex = findPinIndex(point);
                if (pinIndex != -1) {
                    if (e.getClickCount() == 1) {
                        POI poi = this.panel.getUserCreatedPOI(pinIndex);
                        String poiInfoString = "Name: " + poi.getName() +
                                "\nRoom Number: " + poi.getRoomNum() +
                                "\nDescription: " + poi.getDescription() +
                                "\nBuilding: " + currBuilding.getName() +
                                "\nFloor: " + currFloor;
                        // Single click: Show pop-up with information about the POI
                        JOptionPane.showMessageDialog(this, poiInfoString);
                    }
                } else {
                    // Check if the clicked point is on a built-in POI
                    POI builtInPOI = getPointOnBuiltInPOI(point);
                    if (builtInPOI != null) {
                        String poiInfoString = "Name: " + builtInPOI.getName() +
                                "\nRoom Number: " + builtInPOI.getRoomNum() +
                                "\nDescription: " + builtInPOI.getDescription() +
                                "\nBuilding: " + currBuilding.getName() +
                                "\nFloor: " + currFloor;
                        JOptionPane.showMessageDialog(this, poiInfoString);
                    } else {
                        // Add a new pin and show the pop-up for adding a new POI
                        addPin(point);
                        showAddNewPOIDialog((int) point.getX(), (int) point.getY());
                    }
                }
            }
        } else if (SwingUtilities.isRightMouseButton(e) && !pins.isEmpty()) {
            int lastIndex = pins.size() - 1;
            this.panel.removeUserCreatedPOI(lastIndex);
            pins.remove(lastIndex);
            repaint();
        }
    }

    /**
     * Loads a map image from the specified path.
     */
    private void loadMapImage() {
        try {
            mapImage = ImageIO.read(new File("src/main/resources/MSC1.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Sets a new map image from the specified file.
     *
     * @param mapFile: The file containing the new map image.
     */
    public void setMapImage(File mapFile) {
        try {
            mapImage = ImageIO.read(mapFile);
            setPreferredSize(new Dimension(mapImage.getWidth(), mapImage.getHeight()));
            revalidate();
            repaint();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    /**
     * This method paints the built in POIs to the screen
     * 
     * @param g: the abstract class for graphics
     */
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(mapImage, 0, 0, this);
        Building build = this.getBuilding();
        int currFloor = this.getCurrFloor()-1;
        Floor[] floor = build.getFloorArr();
        System.out.println("\nDisplaying Floor: " + currFloor);
        Iterator<Layer> lays = floor[currFloor].getLayerIter();
        
        
        BufferedImage pic = this.getBuilding().getFloor(this.getCurrFloor()).getLayerByName("User Created").getPOIByName("null").getPng();
        if(!floor[currFloor].getLayerByName("User Created").getVis()){
            for (Point pin : pins) {
                 g.drawImage(pic, pin.x - PIN_RADIUS, pin.y - PIN_RADIUS, 25, 25, Color.yellow, null);
            
            }
        }
        
        
        
        
        while(lays.hasNext()){
            Layer currLay = lays.next();
            Iterator<POI> iter = currLay.getPoiIter();
                  
            while(iter.hasNext()){
                
                POI currPOI = iter.next();
                if(currPOI.getLongitude() != -1 && currPOI.isVisible()){
                    g.drawImage(currPOI.getPng(), currPOI.getLongitude(), currPOI.getLatitude(), 25, 25, Color.yellow, null);
                }
            }
        }
    }

    /**
     * Adds a pin at the specified point.
     *
     * @param point The point (x, y) where the pin should be added.
     */
    private void addPin(Point point) {
        pins.add(point);
        repaint();
    }

    /**
     * Removes all pins from the map.
     */
    public void removeAllPins() {
        pins.clear();
        repaint();
    }
    
    /**
     * This method returns if a pin is located at the point in the parameter
     * @param point: the point at which is clicked
     * @return an integer corresponding to the outcome if pin is found
     */
    private int findPinIndex(Point point) {
        for (int i = 0; i < pins.size(); i++) {
            Point pin = pins.get(i);
            if (point.distance(pin) <= PIN_RADIUS) {
                return i;
            }
        }
        return -1;
    }

    /**
     * Updates the position of the pin at the specified index.
     *
     * @param index The index of the pin to be updated.
     * @param point The new point (x, y) for the pin.
     */
    private void updatePinPosition(int index, Point point) {
        if (index >= 0 && index < pins.size()) {
            pins.set(index, point);
            repaint();
        }
    }

    /**
     * Removes the pin at the specified index.
     *
     * @param index The index of the pin to be removed.
     */
    public void removePin(int index) {
        if (index >= 0 && index < pins.size()) {
            pins.remove(index);
            repaint();
        }
    }

    /**
     * Displays the AddNewPOIDialog for adding a new user-created POI.
     * @param x: the x value for the poi clicked on
     * @param y: the y value for the poi clicked on
     */
    private void showAddNewPOIDialog(int x, int y) {
        SwingUtilities.invokeLater(() -> {
            Window parentWindow = SwingUtilities.getWindowAncestor(this);
            AddNewPOIDialog dialog = new AddNewPOIDialog(parentWindow);

            JButton addButton = dialog.getAddButton();
            JTextField nameField = dialog.getNameField();

            // Initially disable the "Add" button if the name field is empty
            addButton.setEnabled(!nameField.getText().isEmpty());

            nameField.getDocument().addDocumentListener(new DocumentListener() {

                private void updateAddButton() {
                    addButton.setEnabled(!nameField.getText().isEmpty());
                }
                @Override
                public void insertUpdate(DocumentEvent e) {
                    updateAddButton();
                }

                @Override
                public void removeUpdate(DocumentEvent e) {
                    updateAddButton();
                }

                @Override
                public void changedUpdate(DocumentEvent e) {
                    updateAddButton();
                }
            });

            addButton.addActionListener(e -> {
                // Get User Created layer for the current building and floor
                Floor[] floorArr = currBuilding.getFloorArr();
                Floor floor = floorArr[currFloor-1];
                Layer userCreated = floor.getLayerByName("User Created");
                
                POI toAdd = new POI();


                String name = dialog.getNameFieldText();
                String description = dialog.getDescriptionText();
                if(!description.isEmpty()) {
                    toAdd.setDescription(description);                        
                }
                else {
                    toAdd.setDescription("");
                }
                String roomNum = dialog.getRoomNumText();
                if(!roomNum.isEmpty()) {
                    toAdd.setRoomNum(roomNum);
                }
                else {
                    toAdd.setRoomNum("");
                }
                if (!name.isEmpty()) {
                    //this.panel.addUserCreatedPOI(name);
                    POI newPOI = new POI();
                    newPOI.setName(name);
                    newPOI.setDescription(description);
                    newPOI.setRoomNum(roomNum);
                    newPOI.setUserCreated();
                    newPOI.setLatitude(y);
                    newPOI.setLongitude(x);
                    this.panel.addUserCreatedPOI(newPOI);
                    userCreated.addPOI(newPOI);
                    currBuilding.saveBuilding();

                    this.panel.refreshPanel();

                    System.out.println("\n\n\n\n\n METADATA SAVED!");
                }
                dialog.dispose();
            });

            dialog.getCancelButton().addActionListener(e -> {
                int lastIndex = pins.size() - 1;
                if (lastIndex >= 0) {
                    pins.remove(lastIndex);
                    this.panel.removeUserCreatedPOI(lastIndex);
                    repaint();
                }
                dialog.dispose();
            });

            dialog.setVisible(true);
        });
    }

    /**
     * Updates the map image based on the selected building and floor.
     *
     * @param building The selected building.
     * @param floor The selected floor.
     */
    public void updateMapImage(String building, String floor) {
        if (building != null && floor != null) {
            String floorNumber = floor.replaceAll("[^\\d]", "");
            String buildingPrefix;

            switch (building) {
                case "Middlesex College":
                    buildingPrefix = "MSC";
                    break;
                case "Alumni Hall":
                    buildingPrefix = "AH";
                    break;
                case "Physics and Astronomy Building":
                    buildingPrefix = "PA";
                    break;
                default:
                    buildingPrefix = "MSC";
            }

            String imageFilePath = "src/main/resources/" + buildingPrefix + floorNumber + ".png";
            setMapImage(new File(imageFilePath));
            repaint();
            
        }
    }
    
    
 
    
    /**
    * Returns the current building object
    * 
    * @return currentBuilding - the current build the program is displaying
    */
    public Building getBuilding(){
        return currBuilding;
    }
    
    /**
    * Sets the building object to the given param
    * 
    * @param build - sets the building object of this class to build
    */
    public void setBuilding(Building build){
        this.currBuilding = build;
    }
    
    /**
    * Sets the current floor number to this object
    * 
    * @param floor - sets the floor number to the param floor
    */
    public void setCurrFloor(int floor){
        this.currFloor = floor;
    }
    
    /**
    * Returns the current floor number
    * 
    * @return currFloor - the current floor number of this object
    */
    public int getCurrFloor(){
        return currFloor;
    }
    /**
     * This method gets the built in poi on the point given
     * @param point the point at which the POI is built n
     * @return the POI at that point if there is one
     */
    private POI getPointOnBuiltInPOI(Point point) {
        Building build = this.getBuilding();
        int currFloor = this.getCurrFloor() - 1;
        Floor[] floor = build.getFloorArr();
        Iterator<Layer> lays = floor[currFloor].getLayerIter();

        while (lays.hasNext()) {
            Layer currLay = lays.next();
            Iterator<POI> iter = currLay.getPoiIter();

            while (iter.hasNext()) {
                POI currPOI = iter.next();
                if (currPOI.getLongitude() != -1) {
                    Rectangle bounds = new Rectangle(currPOI.getLongitude(), currPOI.getLatitude(), 25, 25);
                    if (bounds.contains(point)) {
                        return currPOI;
                    }
                }
            }
        }
        return null;
    }
}

