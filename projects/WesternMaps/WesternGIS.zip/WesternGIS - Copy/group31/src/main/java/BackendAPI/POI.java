package BackendAPI;

// packages to deal with JSON files
import org.json.simple.JSONObject;

// package to deal with images
import javax.imageio.*;
import java.awt.image.*;
import java.io.*;
import java.util.HashMap;
/**
 * POI Object containing information about a POI
 * @author Liam Truss, 
 * @author Armaan Mahajan
 * @version 1.0
 */
public class POI {
    private boolean isFavourite;
    private String name;
    private String roomNum;
    private String iconPngFile;
    private String type;
    private boolean isVisible;
    private boolean isBuiltIn;
    private int latitude;
    private int longitude;
    private String iconFileName;
    private String description;

    private BufferedImage iconPng;

    /**
     * empty constructor to create empty POI
     */
    public POI() {
    }

    /**
     * creates the POI object using the JSON metadata file
     *
     * @param poi: the json object to build a poi
     */
    public POI(JSONObject poi) {
        name = (String) poi.get("name");
        
        iconFileName = (String) poi.get("iconFileName");
        iconPngFile =  "src/main/resources/Icons/" + iconFileName;

        try{
            iconPng = ImageIO.read(new File(iconPngFile));
            System.out.println("Image " + iconPngFile + " Loaded Succesfully!");
        }catch(Exception e){
            System.out.println("Error finding image: " + iconPngFile);
        }
        
        isBuiltIn = (boolean) poi.get("isBuiltIn");
        roomNum = (String) poi.get("roomNum");
        type = (String) poi.get("type");
        isFavourite = (boolean) poi.get("isFavourite");
        isVisible = (boolean) poi.get("visibility");
        latitude = (int)(long) poi.get("latitude");
        longitude = (int)(long) poi.get("longitude");
        description = (String) poi.get("description");
    }
    
    /**
     * builds the JSON object for the POI
     *
     * @return a Json object that can be added to a JSON file
     */
    public JSONObject buildPoiJSON() {
        HashMap<String,Object> poiMap = new HashMap<String,Object>();
        
        poiMap.put("isBuiltIn", this.isBuiltIn);
        poiMap.put("roomNum", this.roomNum);
        poiMap.put("type", this.type);
        poiMap.put("isFavourite", this.isFavourite);
        poiMap.put("visibility", this.isVisible);
        poiMap.put("latitude", this.latitude);
        poiMap.put("longitude", this.longitude);
        poiMap.put("name", this.name);
        poiMap.put("iconFileName", this.iconFileName); 
        poiMap.put("description", this.description);
        JSONObject poi = new JSONObject(poiMap);

        return poi;
    }
    
    /**
     * description setter
     *
     * @param description: the string description for a poi
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * Name setter
     *
     * @param name: the name to be set
     */
    public void setName(String name) {
        this.name = name;
    }
    
    /**
     * Sets default values for a user created POI
     */
    public void setUserCreated() {
        this.isBuiltIn = false;
        this.type = "User Created";
        this.isFavourite = false;
        this.isVisible = true;
        this.iconFileName = "userCreated.png";
        iconPngFile =  "src/main/resources/Icons/" + iconFileName;
        try{
            iconPng = ImageIO.read(new File(iconPngFile));
            System.out.println("Image " + iconPngFile + " Loaded Succesfully!");
        }catch(Exception e){
            System.out.println("Error finding image: " + iconPngFile);
        }
    }


    /**
     * Type setter
     *
     * @param type: the type to be set
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * Room Num Setter
     *
     * @param roomNum: the room num to be set to
     */
    public void setRoomNum(String roomNum) {
        this.roomNum = roomNum; 
    }

    /**
     * Latitude setter
     *
     * @param latitude: the latitude to be set to
     */
    public void setLatitude(int latitude) {
        this.latitude = latitude;
    }
    
    /**
     * Longitude setter
     *
     * @param longitude: the longitude to be set to
     */
    public void setLongitude(int longitude) {
        this.longitude = longitude;
    }

    /**
     * Favourite setter
     *
     * @param isFavourite: the value to set is favourite to
     */
    public void setFavourite(boolean isFavourite) {
        this.isFavourite = isFavourite;
    }

    /**
     * Visibility setter
     *
     * @param visibility: the visibility to be set to this object
     */
    public void setVisibility(boolean visibility) {
        this.isVisible = visibility;
    }

    /**
     * Name getter
     *
     * @return the name of this object
     */
    public String getName() {
        return name;
    }

    /**
     * Type getter
     *
     * @return the type of this object
     */
    public String getType() {
        return type;
    }

    /**
     * Room Num getter
     *
     * @return the roomNum of this object
     */
    public String getRoomNum() {
        return roomNum;
    }

    /**
     * Latitude getter
     *
     * @return the latitude of this object
     */
    public int getLatitude() {
        return latitude;
    }

    /**
     * Longitude getter
     *
     * @return the longitude of this object
     */
    public int getLongitude() {
        return longitude;
    }

    /**
     * isFavourite getter
     *
     * @return the isfavourite status of this object
     */
    public boolean isFavourite() {
        return isFavourite;
    }
    
    /**
     * isVisible getter
     *
     * @return the is visible variable of this object
     */
    public boolean isVisible(){
        return isVisible;
    }
    
    /**
     * IconPNGFile getter
     *
     * @return the string for the icon png file of this object
     */
    public String getIconPNGFile(){
        return iconPngFile;
    }
    
    /**
     * Description getter
     *
     * @return the description of this object
     */
    public String getDescription(){
        return description;
    }
    
    /**
     * Png getter
     *
     * @return the image of this object
     */
    public BufferedImage getPng(){
        return iconPng;
    }

}


