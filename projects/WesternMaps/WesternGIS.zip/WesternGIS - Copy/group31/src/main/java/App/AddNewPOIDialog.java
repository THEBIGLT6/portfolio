package App;
import javax.swing.*;
import java.awt.*;
import javax.swing.JTextField;

/**
 * AddNewPOIDialog class extends JDialog and provides a modal dialog for adding new points of interest (POIs).
 * @version 1.0
 * @author Sam
 */
public class AddNewPOIDialog extends JDialog {
    private final JTextField nameField;
    private final JButton addButton;
    private final JButton cancelButton;
    private final JTextArea descriptionArea;
    private final JTextField roomNumberField;

    /**
     * Constructor for AddNewPOIDialog.
     *
     * @param parentWindow The parent window of this dialog.
     */
    public AddNewPOIDialog(Window parentWindow) {

        // Set dialog title, modality, and parent window
        super(parentWindow, "Add New POI", ModalityType.APPLICATION_MODAL);

        // Set the layout and create panels for the form and buttons
        setLayout(new BorderLayout());
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new GridLayout(3, 2));
        formPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Initialize form fields
        nameField = new JTextField();
        roomNumberField = new JTextField();
        descriptionArea = new JTextArea();
        
        // Add form fields and labels to the form panel
        formPanel.add(new JLabel("Name:"));
        formPanel.add(nameField);
        formPanel.add(new JLabel("Room Number (optional):"));
        formPanel.add(roomNumberField);
        formPanel.add(new JLabel("Description (optional):"));
        formPanel.add(new JScrollPane(descriptionArea));

        // Initialize buttons and add them to the button panel
        JPanel buttonPanel = new JPanel();
        addButton = new JButton("Add");
        cancelButton = new JButton("Cancel");
        buttonPanel.add(addButton);
        buttonPanel.add(cancelButton);

        // Add form panel and button panel to the dialog
        add(formPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        // Set dialog size and position
        pack();
        setLocationRelativeTo(parentWindow);
    }

    /**
     * Getter for the addButton.
     *
     * @return The Add button.
     */
    public JButton getAddButton() {
        return addButton;
    }

    /**
     * Getter for the cancelButton.
     *
     * @return The Cancel button.
     */
    public JButton getCancelButton() {
        return cancelButton;
    }

    /**
     * Getter for the nameField text.
     *
     * @return The text in the name field.
     */
    public String getNameFieldText() {
        return nameField.getText();
    }

    /**
     * getter
     *
     * @return the text field associated with this name field
     */
    public JTextField getNameField() {
        return nameField;
    }
    /**
     * description text getter
     *
     * @return the text field for description
     */
    public String getDescriptionText() {
        return descriptionArea.getText();
    }
    /**
     * Room Number getter
     *
     * @return the field for room number
     */
    public String getRoomNumText() {
        return roomNumberField.getText();
    }
}
