package BackendAPI;

import java.util.ArrayList;
import java.util.List;

/**
 * BuildingController class to manage and provide buildings and their names.
 * @author Samuel Kahessay
 * @version 1.0
 */
public class BuildingsController {
    private static List<Building> buildings;

    // Constructor for the controller
    public BuildingsController() {
        buildings = new ArrayList<>();
        // Add buildings to the buildings list
        // e.g., buildings.add(new Building("Building1"));
        buildings.add(new Building("Middlesex College"));
        buildings.add(new Building("Alumni Hall"));
        buildings.add(new Building("Physics and Astronomy Building"));
    }

    /**
     * Returns the Building instance with the given name.
     *
     * @param name The name of the building to search for.
     * @return The Building instance with the given name or null if not found.
     */
    public static Building getBuildingByName(String name) {
        if (buildings != null) {
            for (Building building : buildings) {
                if (building.getName().equals(name)) {
                    return building;
                }
            }
        }
        return null;
    }
}
