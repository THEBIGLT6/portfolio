package App;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * WeatherWidget is a JPanel for displaying weather information. It fetches and displays the current
 * weather data for a specified city using the OpenWeatherMap API.
 * @author Samuel Kahessay
 * @version 1.0
 */
public class WeatherWidget extends JPanel {

    // Constants for the OpenWeatherMap API
    private static final String API_KEY = "f969c86231fefb84a3e51c325ad00863";
    private static final String CITY = "London";
    private static final String COUNTRY = "CA";
    private static final int UPDATE_INTERVAL = 60 * 60 * 1000; // 1 hour in milliseconds

    private final JLabel weatherInfoLabel;
    private final JLabel weatherIconLabel;

    /**
     * Constructor for the WeatherWidget.
     */
    public WeatherWidget() {
        // Set the layout manager for the JPanel
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBackground(new Color(135, 206, 235));

        // Initialize and configure UI components
        // Declare UI components
        JLabel titleLabel = new JLabel("Current Weather");
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        weatherIconLabel = new JLabel();
        weatherIconLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        weatherInfoLabel = new JLabel("Fetching weather...");
        weatherInfoLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Add UI components to the JPanel
        add(titleLabel);
        add(Box.createRigidArea(new Dimension(0, 10))); // Add spacing between titleLabel and weatherInfoLabel
        add(weatherIconLabel);
        add(weatherInfoLabel);


        // Initialize and start the update timer
        Timer updateTimer = new Timer(UPDATE_INTERVAL, e -> updateWeather());
        updateTimer.setInitialDelay(0);
        updateTimer.start();
    }

    /**
     * Updates the displayed weather information by fetching new data from the OpenWeatherMap API
     * and parsing the results.
     */
    private void updateWeather() {
        SwingUtilities.invokeLater(() -> {
            try {
                // Fetch the weather data
                String weatherData = fetchWeatherData(CITY, COUNTRY, API_KEY);

                // Parse the weather data and format it
                String weatherInfo = parseWeatherData(weatherData);

                // Update the weather information label
                weatherInfoLabel.setText(weatherInfo);
            } catch (IOException e) {
                weatherInfoLabel.setText("Failed to fetch weather data.");
                e.printStackTrace();
            }
        });
    }

    /**
     * Method to fetch weather data using the OpenWeatherMap API.
     *
     * @param city    The city for which the weather data is requested.
     * @param country The country code for the requested city.
     * @param apiKey  The API key for OpenWeatherMap.
     * @return A String containing the raw weather data in JSON format.
     * @throws IOException If there is an issue with fetching the data.
     */
    private String fetchWeatherData(String city, String country, String apiKey) throws IOException {
        // Format the API request URL
        String urlString = String.format("http://api.openweathermap.org/data/2.5/weather?q=%s,%s&appid=%s&units=metric", city, country, apiKey);
        URL url = new URL(urlString);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("GET");

        // Read the API response
        BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
        StringBuilder response = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            response.append(line);
        }
        reader.close();

        return response.toString();
    }

    /**
     * Method to parse the fetched weather data and format it for display.
     *
     * @param weatherData A String containing the raw weather data in JSON format.
     * @return A formatted String containing the temperature and weather description.
     */
    private String parseWeatherData(String weatherData) {
        try {
            JSONParser parser = new JSONParser();
            JSONObject json = (JSONObject) parser.parse(weatherData);
            JSONArray weatherArray = (JSONArray) json.get("weather");
            JSONObject weather = (JSONObject) weatherArray.get(0);
            String description = (String) weather.get("description");
            String icon = (String) weather.get("icon");
            JSONObject main = (JSONObject) json.get("main");
            double temp = (Double) main.get("temp");

            setWeatherIcon(icon);

            return String.format("%.1f°C, %s", temp, description);
        } catch (org.json.simple.parser.ParseException e) {
            e.printStackTrace();
            return "Error parsing weather data";
        }
    }

    /**
     *  Method to set the weather icon on the JLabel.
     *
     * @param iconCode The icon code from the OpenWeatherMap API.
     */
    private void setWeatherIcon(String iconCode) {
        try {
            String urlString = String.format("http://openweathermap.org/img/wn/%s.png", iconCode);
            URL url = new URL(urlString);
            ImageIcon icon = new ImageIcon(ImageIO.read(url));
            weatherIconLabel.setIcon(icon);
        } catch (IOException e) {
            e.printStackTrace();
            weatherIconLabel.setIcon(null);
            weatherIconLabel.setText("Failed to load icon.");
        }
    }
}
