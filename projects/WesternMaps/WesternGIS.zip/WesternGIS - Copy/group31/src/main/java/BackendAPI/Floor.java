package BackendAPI;
import java.util.*;
import javax.imageio.*;
import java.awt.image.*;
import java.io.*;

//packages for reading from JSON
import org.json.simple.JSONObject;


/**
 * Represents a floor of a building. This floor will contain the image
 * of the floor plan and will contain all layers for each floor.
 * @author Liam Truss
 * @author Armaan Mahajan
 * @version 1.0
 */

public class Floor{
    
    //instance variables
    private LinkedList<Layer> layers;
    private final int FLOOR_NUM;
    private final int HEIGHT = 775;
    private final int WIDTH = 1200;
    private BufferedImage floorPNG;
    private String floorPNGFile;
    
    /**
     * 
     * The construtor for this class initializes all instance variables
     *
     * @param floor: JSONObject storing all metadata for a floor object 
     */
    public Floor(JSONObject floor){

        this.layers = constructLayers(floor);
        this.FLOOR_NUM = (int)(long) floor.get("floorNum");
        this.floorPNGFile = (String) floor.get("floorPNGFile");

        //import image from file
        try{
            floorPNG = ImageIO.read(new File("src/main/resources/" + floorPNGFile));
            System.out.println("Image " + floorPNGFile + " Loaded Succesfully!");
        }catch(Exception e){
            System.out.println("Error finding image: " + floorPNGFile);
        }
    }
    
    /**
     * This method constructs a linked list storing all of the layers for the 
     * given Floor. 
     *
     * @param floor: the JSONObject storing the metadata for the floor 
     * @return a linkedlist storing all layer objects storing their metadata
     */
    private LinkedList<Layer> constructLayers(JSONObject floor) {
        //build layers LinkedList
        JSONObject layerJSON = (JSONObject) floor.get("Layers");
        LinkedList<Layer> layers = new LinkedList<Layer>();
        for(Object key : layerJSON.keySet()) {
            Layer layer = new Layer((JSONObject) layerJSON.get(key));
            layers.add(layer);
        }
        return layers;
    }
    
    /**
     * This method builds a HashMap for the layer linkedlist. This is a helper
     * for buildFloorJSON.
     *
     * @return a HashMap representation of the Layer linkedlist
     */
    public HashMap<String,Object> getLayerListAsHashMap() {
        HashMap<String,Object> layerListAsMap = new HashMap<String,Object>();
        Iterator<Layer> layerIter = this.getLayerIter();
        while(layerIter.hasNext()) {
            Layer currLayer = layerIter.next();
            layerListAsMap.put(currLayer.getName(), currLayer.buildLayerJSON());
        }
        return layerListAsMap;
    }
    
    /**
     * This method builds a JSONObject that represents this floor and all of 
     * its metadata
     *
     * @return a JSONObject representation of this Floor object
     */
    public JSONObject buildFloorJSON() {
        HashMap<String,Object> floorHash = new HashMap<String,Object>();
        floorHash.put("floorNum", this.FLOOR_NUM);
        floorHash.put("floorPNGFile", this.floorPNGFile);
        floorHash.put("Layers", getLayerListAsHashMap());

        JSONObject floorJSON = new JSONObject(floorHash);
        return floorJSON;
    }

    /**
     * Iterator for Layer Linked List
     *
     * @return Iterator for this floors Layer LinkedList
     */
    public Iterator<Layer> getLayerIter() {
        return layers.iterator();
    }
    
    /**
     *
     * This method returns image associated with this floor
     * @return a BufferedImage object for the png file of this Floor 
     */
    public BufferedImage getImage(){
        return floorPNG;
    }//end getFloorNum
    
    /**
     * 
     * This method returns the floor number
     *
     * @return integer for this Floors number within the building 
     */
    public int getFloorNum(){
        return FLOOR_NUM;
    }//end getFloorNum
    
    /**
     * 
     * This method returns the height of the image
     *
     * @return integer for the height of the PNG image for this Floor 
     */
    public int getHeight(){
        return HEIGHT;
    }//end getHeight
    
    /**
     * 
     * This method returns the width of the image
     *
     * @return integer for the width of the PNG image for this Floor 
     */
    public int getWidth(){
        return WIDTH;
    }//end getWidth
    
    /**
     * 
     * this method returns the linked list of Layers
     *
     * @return LinkedList storing all Layer objects for this Floor 
     */
    public LinkedList<Layer> getLayerList(){
      
      return layers;
      
    }//end  getPOIList 
    
    /**
     * 
     * This method adds a layer to the floor plan
     *
     * @param toAdd: the Layer object to add to the linked list of Layers 
     */
    public void addLayer(Layer toAdd){
        layers.addLast(toAdd);
    }//end addLayer
    
    
    /**
     * 
     * This method removes a layer from the floor plan, if it can be removed
     * returns the removed layer if it was removed or null if it was not
     *
     * @param toRem: the name of the Layer to be removed 
     */
    public Layer remLayer(String toRem){
        
      Layer toRet = null;
        
      //search for Layer in list
      for(int i = 0; i <layers.size(); i++){
          
          if(layers.get(i).getName().equals(toRem)){
              toRet = layers.get(i);
          }//end if
      }//end for
      
      //return layer and remove if it is not null and removable
      if(toRet!= null){
          if(toRet.isBuiltIn()){
              layers.remove(toRet);
              return toRet;
          }
          else return null;
      }//end if
      
      else return null;
        
    }//end remLayer
    
    
    /**
     * 
     * This method sets the visibility of a layer, returns false if change did not occur
     *
     * @param lay: the layer to change the visibility for 
     * @param vis: the boolean value for visibility
     * @return whether the operation was succesful or not
     */
    public Boolean setVis(Layer lay, Boolean vis){
        
        Boolean occur = true;
        
        if(vis){lay.displayLayer();}
        else{occur = lay.hideLayer();}
        
        return occur;
        
    }//end setVis

    /**
     * This method fetches a layer based on it's name. 
     *
     * @param layerName: the name of the layer to be fetched 
     * @return the layer that is fetched
     */
    public Layer getLayerByName(String layerName) {
        for (Layer layer : layers) {
            if (layer.getName().equals(layerName)) {
                return layer;
            }
        }
        return null;
    }

    /**
     * This method adds a POI to the specified layer
     *
     * @param layerName: The name of the layer the POI needs to be added to 
     * @param poi: the poi to be added to the layer 
     * @return boolean representing whether the operation was succesful
     */
    public boolean addPOI(String layerName, POI poi) {
        Layer layer = getLayerByName(layerName);
        if (layer != null) {
            layer.addPOI(poi);
            return true;
        }
        return false;
    }

    /**
     * This method removes a POI based on it's name.
     *
     * @param layerName: the name of the layer storing the POI 
     * @param poiName: the name of the POI to be removed 
     * @return boolean representing whether the operation was succesful
     */
    public boolean removePOI(String layerName, String poiName) {
        Layer layer = getLayerByName(layerName);
        if (layer != null) {
            return layer.removePOI(poiName);
        }
        return false;
    }

    /**
     * Changes layer visibility
     *
     * @param layerName: the name of the layer that visibility will be changed for 
     * @param visible: the boolean value of the visibility 
     */
    public boolean setLayerVisibility(String layerName, boolean visible) {
        Layer layer = getLayerByName(layerName);
        if (layer != null); {
            return setVis(layer, visible);
        }
    }

    /**
     * Returns the name of the Floor
     *
     * @return the name of the Floor 
     */
    public Object getName() {
        return FLOOR_NUM;
    }

}//end class floor
