package BackendAPI;
import java.util.*;

// packages for dealing with JSON files
import org.json.simple.JSONObject;

/**
 * This represents each layer on a given floor of a building, Each layer will stor multiple POIs
 * @author Liam Truss
 * @author Armaan Mahajan
 * @version 1.0
 */
public class Layer{

    //instance variables
    private String name;
    private String type;
    private LinkedList<POI> pois;
    private Boolean visibility;
    private Boolean isBuiltIn;

    /**
     * This method acts as the constructor of the class and initializes a new layer
     * @param layerName: The name of this layer object
     */
    public Layer(JSONObject layerName){
        name = (String) layerName.get("name");
        type = (String) layerName.get("type");
        isBuiltIn = (Boolean) layerName.get("isBuiltIn");
        visibility = (Boolean) layerName.get("visibility");

        pois = constructPOIs(layerName);
    }//end constructor


    /**
     * Constructs POI arraylist from JSONObject
     *
     * @param layer: the json object that is to be constructed
     * @return a linked list of constructed pois
     */
    private LinkedList<POI> constructPOIs(JSONObject layer) {
        LinkedList<POI> poiList = new LinkedList<POI>();
        JSONObject pois = (JSONObject) layer.get("POIs");
        for(Object key : pois.keySet()) {
            //iterates through and makes POIs
            POI poi = new POI((JSONObject) pois.get((String) key));
            poiList.add(poi);
        }
        return poiList;
    }
    
    
    /**
     * Builds the layer JSON based on the stores POIs
     *
     * @return a json layer corresponding o this layer object
     */
    public JSONObject buildLayerJSON() {
        HashMap<String,Object> layerMap = new HashMap<String,Object>();
        layerMap.put("name", this.name);
        layerMap.put("isBuiltIn", this.isBuiltIn);
        layerMap.put("visibility", this.visibility);
        layerMap.put("POIs", getPoiListAsMap());
        
        JSONObject layerJSON = new JSONObject(layerMap);
        return layerJSON;
    }

    /**
     * Generates HashMap storing all POIs from linkedlist 
     * acts as a helper method to build the layer JSON object
     *
     * @return a hashmap that maps each string to the object
     */
    public HashMap<String,Object> getPoiListAsMap() {
        HashMap<String,Object> poiListAsMap = new HashMap<String,Object>();
        Iterator<POI> poiIter = this.getPoiIter();
        while(poiIter.hasNext()) {
            POI currPoi = poiIter.next();
            poiListAsMap.put(currPoi.getName(), currPoi.buildPoiJSON());
        }
        return poiListAsMap;
    }

    /**
     * get Iterator for POI arraylist
     *
     * @return a iterator to iterate through the poi list
     */
    public Iterator<POI> getPoiIter() {
        return pois.iterator();
    }

    /**
     * This method returns the name of the layer
     * @return the name of this layer
     */
    public String getName(){
        return name;

    }

    /**
     * 
     * This method allows the user to set the name of the layer
     *
     * @param newName: the name that is going to be set to name 
     */
    public void setName(String newName){

        name = newName; 

    }


    /**
     * 
     * This method returns the type of the layer
     *
     * @return the type of layer this is
     */
    public String getType(){

        return this.type;

    }//end getType

    /**
     * 
     *
     * This method returns the visibility of the layer
     * @return this visibility of this object
     */
    public Boolean getVis(){

        return this.visibility;

    }


    /**
     * 
     * This method sets the visibilty of the layer
     *
     * @param vis: the vis this object is to be set to
     */
    public void setVis(Boolean vis){

        this.visibility = vis;

    }

    /**
     * 
     * This method returns true if the layer can be removed
     *
     * @return a boolean value if the layer is built in
     */
    public Boolean isBuiltIn(){

        return isBuiltIn;

    }

    /**
     * 
     * this method returns the linked list of POIs
     *
     * @return a linked list of all pois
     */
    public LinkedList<POI> getPOIList(){

        return pois;

    }

    /**
     * 
     * This method adds the POI in the parameter to the linked list
     *
     * @param toAdd: the poi to be added to the linked list
     */
    public void addPOI(POI toAdd){
        System.out.println("POI: " + toAdd.getName() + "added succesfully"); 
        pois.addLast(toAdd);

    }


    /**
     * 
     * This method removes the POI passed in as a parameter, returning the POI aswell
     * If the POI des not exist in the list then return null
     *
     * @param toRem: the poi to be removed from the linked list
     */
    public void remPOI(String toRem){

        //search for POI in list
        for(int i = 0; i < pois.size(); i++){
            // Check if the poi is the correct poi to remove and remove it
            if(pois.get(i).getName().equals(toRem)){
                pois.remove(i);
            }
        }
    }
    
    /**
     * Removes the parameter POI from the POI ArrayList
     *
     * @param toRem: the poi to be removed from the linked list
     */
    public void remPOI(POI toRem) {
        if(toRem != null) {
            pois.remove(toRem);
        }
    }

    /**
     * 
     *
     * this method returns the POI if it belongs to the layer, null otherwise
     * @param toFind: the poi that is going to be searched for
     * @return the poi that was suppose to be found
     */
    public POI find(POI toFind){

        POI toRet = null;

        //search for POI in list
        for(int i = 0; i < pois.size(); i++){

            if(pois.get(i).equals(toRet)){
                toRet = pois.get(i);
            }

        }//end for

        return toRet;
    }//end find

   /**
    * This function hides a layer
    * @return a boolean if the layer was succesfully hidden
    */
    public Boolean hideLayer(){

        //if the layer can be set to false then hide it
        if(!this.isBuiltIn){
            
            this.visibility = false;

            for(int i = 0; i < pois.size(); i++){

                pois.get(i).setVisibility(false);

            }//end for

            return true;

        }//end if

        else{return false;}

    }//end hideLayer

    /**
     * This displays a layer and sets all POIs vis to true
     */
    public void displayLayer(){

        this.visibility = true;

        for(int i = 0; i < pois.size(); i++){
            pois.get(i).setVisibility(true);

        }//end for

    }

    /**
     * 
     * This method hides the layer even if the layer is built in
     */
    public void hideLayerOverride(){

        this.visibility = false;

        for(int i = 0; i < pois.size(); i++){
            pois.get(i).setVisibility(false);

        }//end for

    }//end hideLayerOverride

    /**
     * Returns the necessary POI based on the pased POI name
     *
     * @param poiName: the poi that is going to be searched for in the layer
     * @return the poi if it is found
     */
    public POI getPOIByName(String poiName) {
        for (POI poi : pois) {
            if (poi.getName().equals(poiName)) {
                return poi;
            }
        }
        return null;
    }

    /**
     * Remove the POI based on the POI name
     *
     * @param poiName: the poi that is to be removed
     * @return  a boolean value meaning if the poi was succesfully removed
     */
    public boolean removePOI(String poiName) {
        POI poi = getPOIByName(poiName);
        if (poi != null) {
            pois.remove(poi);
            return true;
        }
        return false;
    }


    /**
     * Set poi visibility to boolean value visible
     *
     * @param poiName:the poi thats visibility is to be changed
     * @param visible: the visibility to set the poi to
     * @return boolean value whether the visibility was changed correctly
     */
    public boolean setPOIVisibility(String poiName, boolean visible) {
        POI poi = getPOIByName(poiName);
        if (poi != null) {
            poi.setVisibility(visible);
            return true;
        }
        return false;
    }
}//end class Layer

