package App;

import BackendAPI.*;
import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;

import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.Dictionary;

import java.util.LinkedList;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;



/**
 * MapMenu class for displaying map menu options in the application.
 * @author Sam
 * @author Andrea 
 * @author Liam
 * @author Armaan
 * @version 1.0
 */
public class MapMenu extends JPanel{
    private POIPanel panel;
    private MapView view;
    private JScrollPane scrollPane;
    private final JComboBox<String> buildingDropdown;
    private final JComboBox<String> floorDropdown;
    private final JComboBox<String> layerDropdown;
    private final MapMenuController controller;
    private final JSONReader jsonReader;
    private Building middlesex = new Building("MiddlesexCollege");
    private Building alumni = new Building("AlumniHall");
    private Building physics = new Building("PhysicsAndAstronomy");
    private Building currentBuilding = middlesex;
    private int currentFloor;
    private JCheckBox washroomCheckbox;
    private JCheckBox stairwellCheckbox;
    private JCheckBox classroomCheckbox;
    private JCheckBox accessibilityCheckbox;
    private JCheckBox restaurantCheckbox;
    private JCheckBox otherCheckbox;
    private JCheckBox userCreatedCheckbox;
    private JCheckBox csLabCheckbox;
    private JCheckBox csCollabCheckbox;
    private JCheckBox exitsCheckbox;
    private Dictionary<String, JCheckBox> dict;
     

    /**
     * Constructor for MapMenu class.
     *
     * @throws IOException    if there is an error reading the JSON file.
     * @throws ParseException if there is an error parsing the JSON file.
     */
    public MapMenu() throws IOException, ParseException {
        this.controller = new MapMenuController();
        this.jsonReader = new JSONReader("src/main/resources/testJSON.json");
        this.panel = new POIPanel(middlesex, 1);
        this.view = new MapView(middlesex,1,this.panel);
        panel.setMapView(this.view);
        this.scrollPane = new JScrollPane(this.view);
        // Set the layout of the MapMenu JPanel
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

        // Initialize and configure titleLabel
        // Declare UI components
        JLabel titleLabel = new JLabel("Map Menu");
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Initialize the JComboBoxes (dropdowns) for buildings, floors, and layers
        buildingDropdown = new JComboBox<>(new String[]{"Middlesex College", "Alumni Hall", "Physics and Astronomy Building"});
        floorDropdown = new JComboBox<>();
        layerDropdown = new JComboBox<>();
        // Add the LayerCheckboxItem as an ItemListener to the layerDropdown
        layerDropdown.addItemListener(new LayerCheckboxItem());

        // Initialize the checkboxes for layers and user created POIs
        washroomCheckbox = new JCheckBox("Washroom");
        stairwellCheckbox = new JCheckBox("Stairwell");
        classroomCheckbox = new JCheckBox("Classroom");
        accessibilityCheckbox = new JCheckBox("Accessibility");
        restaurantCheckbox = new JCheckBox("Restaurants");
        otherCheckbox = new JCheckBox("Other");
        userCreatedCheckbox = new JCheckBox("User Created");
        csLabCheckbox = new JCheckBox("Computer Science Lab");
        csCollabCheckbox = new JCheckBox("Computer Science Collaborative Space");
        exitsCheckbox = new JCheckBox("Exits");

        //fill dictionary with keys and checkboxes
        dict = new Hashtable<String, JCheckBox>();
        dict.put("Washrooms", washroomCheckbox);
        dict.put("Restaurants", restaurantCheckbox);
        dict.put("Stairwell", stairwellCheckbox);
        dict.put("Accessibility", accessibilityCheckbox);
        dict.put("Classroom", classroomCheckbox);
        dict.put("Other", otherCheckbox);
        dict.put("User Created", userCreatedCheckbox);
        dict.put("Computer Science Lab",  csLabCheckbox);
        dict.put("Computer Science Collaborative Space", csCollabCheckbox);
        dict.put("Exits", exitsCheckbox);


        // Add ActionListener to each dropdown
        buildingDropdown.addActionListener(new BuildingDropdownAction());
        floorDropdown.addActionListener(new FloorDropdownAction());

        // Add UI components to the panel
        add(titleLabel);
        add(Box.createRigidArea(new Dimension(0, 10)));
        add(new JLabel("Buildings"));
        add(buildingDropdown);
        add(Box.createRigidArea(new Dimension(0, 10)));
        add(new JLabel("Floors"));
        add(floorDropdown);
        add(Box.createRigidArea(new Dimension(0, 10)));
        add(new JLabel("Layers"));

        // Add ItemListener to each checkbox
        washroomCheckbox.addItemListener(new LayerCheckboxItem());
        stairwellCheckbox.addItemListener(new LayerCheckboxItem());
        classroomCheckbox.addItemListener(new LayerCheckboxItem());
        accessibilityCheckbox.addItemListener(new LayerCheckboxItem());
        restaurantCheckbox.addItemListener(new LayerCheckboxItem());
        otherCheckbox.addItemListener(new LayerCheckboxItem());
        userCreatedCheckbox.addItemListener(new LayerCheckboxItem());
        csLabCheckbox.addItemListener(new LayerCheckboxItem());
        csCollabCheckbox.addItemListener(new LayerCheckboxItem());
        exitsCheckbox.addItemListener(new LayerCheckboxItem());

        // Add UI components to the panel
        JPanel layerPanel = new JPanel(new GridLayout(0, 1));
        layerPanel.add(washroomCheckbox);
        layerPanel.add(stairwellCheckbox);
        layerPanel.add(classroomCheckbox);
        layerPanel.add(accessibilityCheckbox);
        layerPanel.add(restaurantCheckbox);
        layerPanel.add(otherCheckbox);
        layerPanel.add(userCreatedCheckbox);
        layerPanel.add(csLabCheckbox);
        layerPanel.add(csCollabCheckbox);
        layerPanel.add(exitsCheckbox);
        add(layerPanel);


        // Set the initial selection of the buildingDropdown
        buildingDropdown.setSelectedIndex(0);

        // Set the initial selection of the buildingDropdown
        buildingDropdown.setSelectedIndex(0);
         
    }

    /**
     * Sets the selected building name and floor based on the params
     *
     * @param buildingName 
     * @param floorName 
     */
    public void setSelectedBuildingAndFloor(String buildingName, String floorName) {
        buildingDropdown.setSelectedItem(buildingName);
        floorDropdown.setSelectedItem(floorName);
    }

    /**
     * ActionListener class for the building dropdown.
     */
    private class BuildingDropdownAction implements ActionListener {
        /**
         * Handles action event passed by param e
         *
         * @param e 
         */
        @Override
        public void actionPerformed(ActionEvent e) {
            // Remove all pins from mapView
            view.removeAllPins();
            cleanLayers();

            // Get the selected building from the buildingDropdown
            String selectedBuilding = (String) buildingDropdown.getSelectedItem();

            // Update the floorDropdown based on the selected building
            if (selectedBuilding != null) {
                JSONObject buildingObj = jsonReader.getBuilding(selectedBuilding);

                if (buildingObj != null) {
                    JSONObject floorsObj = (JSONObject) buildingObj.get("Floors");
                    populateComboBox(floorDropdown, floorsObj.keySet().toArray());
                    String[] floors = controller.getFloorsForBuilding(selectedBuilding);
                    floorDropdown.setModel(new DefaultComboBoxModel<>(floors));
                    // Set the initial selection of the floorDropdown
                    floorDropdown.setSelectedIndex(0);
                } else {
                    floorDropdown.setModel(new DefaultComboBoxModel<>());
                }
            }
            // Update mapView with the selected building and floor
            view.updateMapImage(selectedBuilding, floorDropdown.getItemAt(0));
            currentFloor = 1;
            switch (selectedBuilding) {
                case "Middlesex College":
                    currentBuilding = middlesex;
                    break;
                case "Alumni Hall":
                    currentBuilding = alumni;
                    break;
                case "Physics and Astronomy Building":
                    currentBuilding = physics;
                    break;
                default:
                    break;
            }
            panel.setCurrBuilding(currentBuilding);
            panel.setCurrFloor(currentFloor);
            panel.refreshPanel();

            view.setBuilding(currentBuilding);
            view.setCurrFloor(currentFloor);
            updateLayerCheckboxes(currentFloor);

        }
    }
    
    
    /**
     * This method updates the layer checkboxes in the map menu with the corresponding layers on that floor
     * 
     * 
     * @param currentFloor - the current floor of the building
     */
    private void updateLayerCheckboxes(int currentFloor) {
        
        washroomCheckbox.setVisible(false);
        stairwellCheckbox.setVisible(false);
        classroomCheckbox.setVisible(false);
        accessibilityCheckbox.setVisible(false);
        restaurantCheckbox.setVisible(false);
        otherCheckbox.setVisible(false);
        userCreatedCheckbox.setVisible(false);
        csLabCheckbox.setVisible(false);
        csCollabCheckbox.setVisible(false);
        exitsCheckbox.setVisible(false);
        
        Floor[] flrs = this.currentBuilding.getFloorArr();
        Floor flr = flrs[currentFloor-1];
        
        LinkedList<Layer> lays  = flr.getLayerList();
        
        for(int i = 0; i < lays.size(); i++){
            
            Layer curr = lays.get(i);
            JCheckBox bx = dict.get(curr.getName());
            bx.setVisible(true);
        }
    }


    /**
     * Helper method to populate a JComboBox with items.
     *
     * @param comboBox The JComboBox to populate.
     * @param items    An array of items to add to the comboBox.
     */
    private void populateComboBox(JComboBox<String> comboBox, Object[] items) {
        comboBox.removeAllItems();
        for (Object item : items) {
            comboBox.addItem((String) item);
        }
    }

    /**
     * ActionListener class for the floor dropdown.
     */
    private class FloorDropdownAction implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            // Remove all pins from mapView
            view.removeAllPins();
            view.repaint();
            cleanLayers();
            // Get the selected building and floor from the respective dropdowns
            String selectedBuildingName = (String) buildingDropdown.getSelectedItem();
            String selectedFloorNum = (String) floorDropdown.getSelectedItem();
            if(selectedFloorNum == null) {
                selectedFloorNum = "1";
            }
            if(selectedBuildingName == null) {
                selectedBuildingName = "Middlesex College";
            }

            setPanel(selectedBuildingName, Integer.parseInt(selectedFloorNum.replaceAll("\\D+", "")));
            panel.refreshPanel();
            // Does this even do anything?
            // Update the layerDropdown based on the selected floor
            if (selectedBuildingName != null && selectedFloorNum != null) {
                Building selectedBuilding = BuildingsController.getBuildingByName(selectedBuildingName);
                Floor selectedFloor = null;

                // Set Building and Floor for POIPanel and refresh
                //System.out.println("\nNow displaying building: " + selectedBuilding.getName() + " on floor " + selectedFloorNum);

                if (selectedBuilding != null) {
                    selectedFloor = selectedBuilding.getFloor(selectedFloorNum);
                }

                if (selectedFloor != null) {
                    LinkedList<Layer> layers = selectedFloor.getLayerList();
                    String[] layerNames = layers.stream().map(Layer::getName).toArray(String[]::new);
                    System.out.println(layerNames[0]);
                    layerDropdown.setModel(new DefaultComboBoxModel<>(layerNames));
                }
            }

            // Update mapView with the selected building and floor
            view.updateMapImage(selectedBuildingName, selectedFloorNum);

            // Hack plz fix
            if (selectedFloorNum != null) {
                currentFloor = Integer.parseInt(selectedFloorNum.replaceAll("\\D+", ""));


                // Use of deprecated method
                //panel.displayBuiltInPOIs(currentBuilding, panel.getModel(),currentFloor);
            }

            view.setCurrFloor(currentFloor);
            updateLayerCheckboxes(currentFloor);
        }
    }

    /**
     * ActionListener class for the layer dropdown.
     */
    private class LayerCheckboxItem implements ItemListener {
        @Override
        public void itemStateChanged(ItemEvent e) {

            Building build1 = currentBuilding;
            Floor[] flrs = build1.getFloorArr();
            Floor flr = flrs[currentFloor-1];
            Layer lay;

            if(exitsCheckbox.isSelected()){
                lay = flr.getLayerByName("Exits");
                lay.displayLayer();
                view.repaint();
            } else{
                if(flr.getLayerByName("Exits") != null){
                    lay = flr.getLayerByName("Exits");
                    lay.hideLayerOverride();
                    view.repaint();
                }
            }

            if(userCreatedCheckbox.isSelected()){
                lay = flr.getLayerByName("User Created");
                lay.displayLayer();
                view.repaint();
            } else{
                if(flr.getLayerByName("User Created") != null){
                    lay = flr.getLayerByName("User Created");
                    lay.hideLayerOverride();
                    view.repaint();
                }
            }

            if(classroomCheckbox.isSelected()){
                lay = flr.getLayerByName("Classroom");
                lay.displayLayer();
                view.repaint();
            } else{
                if(flr.getLayerByName("Classroom") != null){
                    lay = flr.getLayerByName("Classroom");
                    lay.hideLayerOverride();
                    view.repaint();
                }
            }

            if(stairwellCheckbox.isSelected()){
                lay = flr.getLayerByName("Stairwell");
                lay.displayLayer();
                view.repaint();
            } else{
                if(flr.getLayerByName("Stairwell") != null){
                    lay = flr.getLayerByName("Stairwell");
                    lay.hideLayerOverride();
                    view.repaint();
                }
            }

            if(accessibilityCheckbox.isSelected()){
                lay = flr.getLayerByName("Accessibility");
                lay.displayLayer();
                view.repaint();
            } else{
                if(flr.getLayerByName("Accessibility") != null){
                    lay = flr.getLayerByName("Accessibility");
                    lay.hideLayerOverride();
                    view.repaint();
                }
            }

            if(washroomCheckbox.isSelected()){
                lay = flr.getLayerByName("Washrooms");
                lay.displayLayer();
                view.repaint();
            } else{
                if(flr.getLayerByName("Washrooms") != null){
                    lay = flr.getLayerByName("Washrooms");
                    lay.hideLayerOverride();
                    view.repaint();
                }
            }

            if(exitsCheckbox.isSelected()){
                lay = flr.getLayerByName("Exits");
                lay.displayLayer();
                view.repaint();
            } else{
                if(flr.getLayerByName("Exits") != null){
                    lay = flr.getLayerByName("Exits");
                    lay.hideLayer();
                    view.repaint();
                }
            }

            if(restaurantCheckbox.isSelected()){
                lay = flr.getLayerByName("Restaurants");
                lay.displayLayer();
                view.repaint();
            } else{
                if(flr.getLayerByName("Restaurants") != null){
                    lay = flr.getLayerByName("Restaurants");
                    lay.hideLayer();
                    view.repaint();
                }
            }

            if(otherCheckbox.isSelected()){
                lay = flr.getLayerByName("Other");
                lay.displayLayer();
                view.repaint();
            } else{
                if(flr.getLayerByName("Other") != null){
                    lay = flr.getLayerByName("Other");
                    lay.hideLayer();
                    view.repaint();
                }
            }


            if(csLabCheckbox.isSelected()){
                lay = flr.getLayerByName("Computer Science Lab");
                lay.displayLayer();
                view.repaint();
            } else{
                if(flr.getLayerByName("Computer Science Lab") != null){
                    lay = flr.getLayerByName("Computer Science Lab");
                    lay.hideLayer();
                    view.repaint();
                }
            }

            if(csCollabCheckbox.isSelected()){
                lay = flr.getLayerByName("Computer Science Collaborative Space");
                lay.displayLayer();
                view.repaint();
            } else{
                if(flr.getLayerByName("Computer Science Collaborative Space") != null){
                    lay = flr.getLayerByName("Computer Science Collaborative Space");
                    lay.hideLayer();
                    view.repaint();
                }
            }   
        }
    }

    /**
     * Sets the current building to the one selected
     * @param buildingName - the building that is selected by the drop down 
     */
    public void setBuilding(String buildingName){
        switch (buildingName) {
                case "Middlesex College":
                    currentBuilding = middlesex;
                    break;
                case "Alumni Hall":
                    currentBuilding = alumni;
                    break;
                case "Physics and Astronomy Building":
                    currentBuilding = physics;
                    break;
                default:
                    currentBuilding = middlesex;
            }
    }

    /**
     * Selects the map panel according to what building and floor have been selected
     * @param currBuilding - the building being changed to
     * @param currFloor - the floor being changed to
     */
    public void setPanel(String currBuilding, int currFloor){
        switch (currBuilding) {
                case "Middlesex College":
                    panel.setCurrBuilding(middlesex);
                    panel.setCurrFloor(currFloor);
                    break;
                case "Alumni Hall":
                    panel.setCurrBuilding(alumni);
                    panel.setCurrFloor(currFloor);
                    break;
                case "Physics and Astronomy Building":
                    panel.setCurrBuilding(physics);
                    panel.setCurrFloor(currFloor);
                    break;
                default:
                    break;
            }
    }
    /**
     * Getter for the POI panel
     * @return the POI panel object for this object
     */
    public POIPanel getPanel(){
        return panel;
    }
    /**
     * Getter for the mapview object associated with this object
     * @return the mapview object associated with the current object
     */
    public MapView getView(){
        return view;
    }
    /**
     * Getter for the scrollpane
     * @return - the javascrollpane object associated with this class
     */
    public JScrollPane getScrollPane(){
        return scrollPane;
    }
    
    /**
     * This method sets so that all layers are set to invisible before changing floors
     *
     */
    public void cleanLayers(){
        
        Building build1 = currentBuilding;
        Floor[] flrs = build1.getFloorArr();
        
        for(int j = 0;  j< flrs.length; j++){
        
            Floor flr = flrs[j];
            LinkedList<Layer> lays = flr.getLayerList();
            for(int i = 0; i< lays.size(); i++){
                
                    lays.get(i).hideLayerOverride();
                
            
            }
        }
        
        
        washroomCheckbox.setSelected(false);
        stairwellCheckbox.setSelected(false);
        classroomCheckbox.setSelected(false);
        accessibilityCheckbox.setSelected(false);
        restaurantCheckbox.setSelected(false);
        otherCheckbox.setSelected(false);
        userCreatedCheckbox.setSelected(false);
        csLabCheckbox.setSelected(false);
        csCollabCheckbox.setSelected(false);
        exitsCheckbox.setSelected(false);
        
    }//end clean layers
}
