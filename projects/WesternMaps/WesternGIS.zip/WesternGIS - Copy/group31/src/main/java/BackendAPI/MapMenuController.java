package BackendAPI;

/**
 * MapMenuController class to manage and provide building and floor data.
 * @author Samuel Kahessay
 * @version 1.0
 */
public class MapMenuController {

    /**
     * Returns an array of floor names for the specified building.
     *
     * @param building The name of the building to retrieve floor data for.
     * @return An array of floor names for the specified building, or an empty array if the building is not found.
     */
    public String[] getFloorsForBuilding(String building) {
        switch (building) {
            case "Middlesex College":
                return new String[]{"Floor 1", "Floor 2", "Floor 3", "Floor 4", "Floor 5"};
            case "Alumni Hall":
                return new String[]{"Floor 1", "Floor 2", "Floor 3"};
            case "Physics and Astronomy Building":
                return new String[]{"Floor 1", "Floor 2", "Floor 3", "Floor 4"};
            default:
                return new String[]{};
        }
    }
}
