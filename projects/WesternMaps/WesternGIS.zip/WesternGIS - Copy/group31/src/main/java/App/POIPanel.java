package App;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.Iterator;
import BackendAPI.*;
/**
 * POIPanel class for displaying and managing built-in, favorite, and user-created Points of Interest (POIs).
 * @author Armaan Mahajan, Samuel Kahessay, Andrea Diano-Bavaro
 */
public class POIPanel extends JPanel {
    private Building currentBuilding;
    private int currFloor;
    private JList<String> builtInPOIs;
    private JList<String> favouritePOIs;
    private JList<String> userCreatedPOIs;
    private ArrayList<POI> userCreatedPOIObjects;
    private DefaultListModel<String> model;
    private JButton addToFavouritesButton;
    private JButton removeFromFavouritesButton;
    private JButton editBuiltInButton;
    private JButton deleteButton;
    private JButton editButton;
    private MapView mapView;

    /**
     * 
     * Constructor for POIPanel class.
     *
     * @param building Custom Building object representing a building
     * @param floor Floor number represented as an integer
     */
    public POIPanel(Building building, int floor) {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        this.currentBuilding = building;
        this.currFloor = floor;
        userCreatedPOIObjects = new ArrayList<>();
        initializeComponents();
        addActionListeners();
        addComponents();

        // Load built-in POIs from JSON
        this.model = (DefaultListModel<String>) builtInPOIs.getModel();
        model.clear();
    }

    /**
     * Sets the MapView object associated with this POIPanel.
     *
     * @param mapView MapView object to display the map.
         */
    public void setMapView(MapView mapView) {
        this.mapView = mapView;
    }

    /**
     * Refreshes the POIPanel based on the current building object
     */
    public void refreshPanel() {
        // Clear all fields before repopulating them
        model = (DefaultListModel<String>)favouritePOIs.getModel();
        model.clear();
        model = (DefaultListModel<String>)userCreatedPOIs.getModel();
        model.clear();
        model = (DefaultListModel<String>)builtInPOIs.getModel();
        model.clear();
        
        if (currentBuilding == null) {
            System.err.println("Error: Building is null.");
            return;
        }

        Floor[] floorArr = currentBuilding.getFloorArr();
        Floor floor = floorArr[currFloor-1];
        // Check if floorIter is not null before accessing it
        if (floorArr != null) {
            Iterator<Layer> layerIter = floor.getLayerIter();

            while (layerIter.hasNext()) {
                Layer currLayer = layerIter.next();
                Iterator<POI> poiIter = currLayer.getPoiIter();

                while (poiIter.hasNext()) {
                    POI currPoi = poiIter.next();
                    if (!currPoi.getName().equals("null")) {
                        if (currPoi.isFavourite()) {
                            model = (DefaultListModel<String>)favouritePOIs.getModel();
                            model.addElement(currPoi.getName());
                        }

                        if (currPoi.getType().equals("User Created")) {
                            model = (DefaultListModel<String>)userCreatedPOIs.getModel();
                            model.addElement(currPoi.getName());
                        }
                        else {
                            model = (DefaultListModel<String>)builtInPOIs.getModel();
                            model.addElement(currPoi.getName());
                        }
                    }

                }
            }
        } 

    }

    /**
     * Initializes UI components.
     */
    private void initializeComponents() {
        builtInPOIs = new JList<>(new DefaultListModel<>());
        favouritePOIs = new JList<>(new DefaultListModel<>());
        userCreatedPOIs = new JList<>(new DefaultListModel<>());

        addToFavouritesButton = new JButton("Add to Favourites");
        editBuiltInButton = new JButton("Edit Built In POI");
        removeFromFavouritesButton = new JButton("Remove from Favourites");
        deleteButton = new JButton("Delete User POI");
        editButton = new JButton("Edit User POI");
    }

    /**
     * Adds action listeners to UI components.
     */
    private void addActionListeners() {
        addToFavouritesButton.addActionListener(e -> addToFavourites());
        removeFromFavouritesButton.addActionListener(e -> removeFromFavorites());
        editBuiltInButton.addActionListener(e -> editBuiltInPOI());
        deleteButton.addActionListener(e -> delete());
        editButton.addActionListener(e -> edit());
    }

    /**
     * Adds UI components to the POIPanel.
     */
    private void addComponents() {
        add(new JLabel("Built-In POIs"));
        add(new JScrollPane(builtInPOIs));
        add(addToFavouritesButton);
        add(editBuiltInButton);
        add(Box.createRigidArea(new Dimension(0, 10)));

        add(new JLabel("Favourite POIs"));
        add(new JScrollPane(favouritePOIs));
        add(removeFromFavouritesButton);
        add(Box.createRigidArea(new Dimension(0, 10)));

        add(new JLabel("User-Created POIs"));
        add(new JScrollPane(userCreatedPOIs));
        add(Box.createRigidArea(new Dimension(0, 10)));

        add(deleteButton);
        add(Box.createRigidArea(new Dimension(0, 5)));
        add(editButton);
    }

    /**
     * Gets the POI based on the passed "selectedPoi" which is the poi currently
     * selected in the panel
     *
     * @param selectedPoi the user selected POI in the panel
     * @return POI the specific POI object from the string selectedPoi
     */
    private POI getPOIFromPanel(String selectedPoi) {
        Iterator<Layer> layerIter = currentBuilding.getFloorArr()[currFloor-1].getLayerIter();
        while(layerIter.hasNext()) {
            Layer currLayer = layerIter.next();
            POI poi = currLayer.getPOIByName(selectedPoi);
            if(poi != null) {
                return poi;
            }
        }
        return null;
    }

    /**
     * This method is called when the "Edit Built-In POI" button is pressed
     */
    private void editBuiltInPOI() {
        int selectedIndex = builtInPOIs.getSelectedIndex();
        String selectedPoi = builtInPOIs.getModel().getElementAt(selectedIndex);
        POI toChange = getPOIFromPanel(selectedPoi);
        if(selectedIndex != -1 && App.getDevStatus() == true) { //if the user is in developer mode and the poi exists, you can edit it
            //String newName = JOptionPane.showInputDialog("Enter new name for the POI:");
            JPanel editPanel = editPanel();
            int result = JOptionPane.showConfirmDialog(null, editPanel, "Enter New Info", JOptionPane.OK_CANCEL_OPTION);
            if(result == JOptionPane.OK_OPTION) {
                
                Component[] components = editPanel.getComponents();

                for(Component component : components) {
                    if(component.getName() != null) {
                        if(component.getName().equals("nameField")) {
                            JTextField nameField = (JTextField) component;
                            String newName = nameField.getText();
                            if(!newName.equals("")) {
                                toChange.setName(newName);
                            }
                        }
                        if(component.getName().equals("descriptionArea")) {
                            JTextArea descriptionArea = (JTextArea) component;
                            try {
                                String newDescription = descriptionArea.getDocument().getText(0, descriptionArea.getDocument().getLength());
                                if(!newDescription.equals("")) {
                                    toChange.setDescription(newDescription);
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                        if(component.getName().equals("roomField")) {
                            JTextField roomField = (JTextField) component;
                            String newRoomNum = roomField.getText();
                            if(!newRoomNum.equals("")) {
                                toChange.setRoomNum(newRoomNum);
                            }
                        }
                    }
                }
                currentBuilding.saveBuilding();
                refreshPanel();
            }
        }
    }

    /**
     * Creates and returns a panel with fields to edit name, roomNum, description
     *
     * @return JPanel the panel with all the editable fields (name, room number, and description).
     */
    private JPanel editPanel() {
        JPanel editPanel = new JPanel();
        editPanel.setLayout(new GridLayout(3,2));
        JLabel nameLabel = new JLabel("Name:");
        JTextField nameField = new JTextField("");
        JLabel roomLabel = new JLabel("Room Num:");
        JTextField roomField = new JTextField();
        JLabel descriptionLabel = new JLabel("Description:");
        JTextArea descriptionArea = new JTextArea(5, 20);

        nameField.setName("nameField");
        roomField.setName("roomField");
        descriptionArea.setName("descriptionArea");

        editPanel.add(nameLabel);
        editPanel.add(nameField);
        editPanel.add(roomLabel);
        editPanel.add(roomField);
        editPanel.add(descriptionLabel);
        editPanel.add(descriptionArea);

        return editPanel;
    }

    /**
     * Adds the selected built-in POI to the favorites list.
     */
    private void addToFavourites() {
        int selectedIndex = builtInPOIs.getSelectedIndex();
        if (selectedIndex != -1) {
            String selectedPoi = builtInPOIs.getModel().getElementAt(selectedIndex);
            DefaultListModel<String> model = (DefaultListModel<String>) favouritePOIs.getModel();

            boolean isAlreadyFavorite = false;
            for (int i = 0; i < model.getSize(); i++) {
                if (model.getElementAt(i).equals(selectedPoi)) {
                    isAlreadyFavorite = true;
                    break;
                }
            }

            if (!isAlreadyFavorite) {
                model.addElement(selectedPoi);
                Iterator<Layer> layerIter = currentBuilding.getFloorArr()[currFloor-1].getLayerIter();
                while(layerIter.hasNext()) {
                    Layer currLayer = layerIter.next();
                    POI poi = currLayer.getPOIByName(selectedPoi);
                    if(poi != null) {
                        poi.setFavourite(true);
                        currentBuilding.saveBuilding();
                    }
                }
            }
        }
    }

    /**
     * Removes the selected favorite POI from the favorites list.
     */
    private void removeFromFavorites() {
        int selectedIndex = favouritePOIs.getSelectedIndex();
        if (selectedIndex != -1) {
            
            //Remove the selected poi from the object and the metadata
            String selectedPoi = favouritePOIs.getModel().getElementAt(selectedIndex);
            Iterator<Layer> layerIter = currentBuilding.getFloorArr()[currFloor-1].getLayerIter();
            while(layerIter.hasNext()) {
                Layer currLayer = layerIter.next();
                POI poi = currLayer.getPOIByName(selectedPoi);
                if(poi != null) {
                    System.out.println("POI: " + poi.getName() +"removed from favourites");
                    poi.setFavourite(false);
                    currentBuilding.saveBuilding();
                }
            }
             
            //Remove the selected POI from the list
            DefaultListModel<String> model = (DefaultListModel<String>) favouritePOIs.getModel();
            model.remove(selectedIndex);
        }
    }

    /**
     * Deletes the selected user-created POI from the list.
     */
    private void delete() {
        int selectedIndex = userCreatedPOIs.getSelectedIndex();
        if (selectedIndex != -1) {
            String selectedPoi = userCreatedPOIs.getModel().getElementAt(selectedIndex);

            Iterator<Layer> layerIter = currentBuilding.getFloorArr()[currFloor-1].getLayerIter();
            while(layerIter.hasNext()) {
                Layer currLayer = layerIter.next();
                POI poi = currLayer.getPOIByName(selectedPoi);
                if(poi != null) {
                    currLayer.remPOI(poi);
                }
            }
        }
        currentBuilding.saveBuilding();
        refreshPanel();
    }

    /**
     * Edits the name of the selected user-created POI.
     */
    private void edit() {
        int selectedIndex = userCreatedPOIs.getSelectedIndex();
        String selectedPoi = userCreatedPOIs.getModel().getElementAt(selectedIndex);
        POI toChange = getPOIFromPanel(selectedPoi);
        if(selectedIndex != -1) { //if the user is in developer mode and the poi exists, you can edit it
            //String newName = JOptionPane.showInputDialog("Enter new name for the POI:");
            JPanel editPanel = editPanel();
            int result = JOptionPane.showConfirmDialog(null, editPanel, "Enter New Info", JOptionPane.OK_CANCEL_OPTION);
            if(result == JOptionPane.OK_OPTION) {
                
                Component[] components = editPanel.getComponents();

                for(Component component : components) {
                    if(component.getName() != null) {
                        if(component.getName().equals("nameField")) {
                            JTextField nameField = (JTextField) component;
                            String newName = nameField.getText();
                            if(!newName.equals("")) {
                                toChange.setName(newName);
                            }
                        }
                        if(component.getName().equals("descriptionArea")) {
                            JTextArea descriptionArea = (JTextArea) component;
                            try {
                                String newDescription = descriptionArea.getDocument().getText(0, descriptionArea.getDocument().getLength());
                                if(!newDescription.equals("")) {
                                    toChange.setDescription(newDescription);
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                        if(component.getName().equals("roomField")) {
                            JTextField roomField = (JTextField) component;
                            String newRoomNum = roomField.getText();
                            if(!newRoomNum.equals("")) {
                                toChange.setRoomNum(newRoomNum);
                            }
                        }
                    }
                }
                currentBuilding.saveBuilding();
                refreshPanel();
            }
        }
    }
    
    /**
     * Setter method that sets the current building.
     *
     * @param currentBuilding current building represented as a Building object.
     */
    public void setCurrBuilding(Building currentBuilding) {
        this.currentBuilding = currentBuilding;
    }

    /**
     * Setter method that sets the current floor.
     *
     * @param floor current floor number represented as an integer.
     */
    public void setCurrFloor(int floor) {
        this.currFloor = floor;
    }

    /**
     * Adds a user-created POI to the list.
     *
     * @param poi  The name of the POI.
     */
    public void addUserCreatedPOI(POI poi) {
        userCreatedPOIObjects.add(poi);
    }

    /**
     * Removes a user-created POI from the list.
     *
     * @param index The index of the POI in the list.
     */
    public void removeUserCreatedPOI(int index) {
        DefaultListModel<String> model = (DefaultListModel<String>) userCreatedPOIs.getModel();
        if (index >= 0 && index < model.getSize()) {
            model.remove(index);
            userCreatedPOIObjects.remove(index);
        }
    }

    /**
     * Getter method that returns the user created POI based on its index.
     *
     * @param index the index of the POI in the array of user-created POIs.
     * @return POI the POI object determined by its respective POI.
     */
    public POI getUserCreatedPOI(int index) {
        if (index >= 0 && index < userCreatedPOIObjects.size()) {
            return userCreatedPOIObjects.get(index);
        }
        return null;
    }
}
