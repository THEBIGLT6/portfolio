package BackendAPI;

import java.io.FileReader;
import java.io.IOException;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/**
 * This class has been deprecated
 * JSONReader class for reading building and floor data from a JSON file.
 * @author Samuel Kahessay
 * @version 1.0
 */
public class JSONReader {
    private final JSONObject jsonObject;

    /**
     * Constructs a JSONReader object with the specified JSON file.
     *
     * @param filePath The path to the JSON file.
     * @throws IOException  If there is an issue reading the JSON file.
     * @throws ParseException If there is an issue parsing the JSON file.
     */
    public JSONReader(String filePath) throws IOException, ParseException {
        JSONParser parser = new JSONParser();
        this.jsonObject = (JSONObject) parser.parse(new FileReader(filePath));
    }

    /**
     * Retrieves a JSONObject representing the building with the specified name.
     *
     * @param buildingName The name of the building to retrieve.
     * @return A JSONObject containing building data, or null if the building is not found.
     */
    public JSONObject getBuilding(String buildingName) {
        return (JSONObject) jsonObject.get(buildingName);
    }
}
