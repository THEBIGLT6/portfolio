/*
 * App is the class that runs the entire application. The startup screen, menubar, menubar
 * functionality, and layout will be controlled by this class. 
 *
 */
package App;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.util.Iterator;
import BackendAPI.*;
import org.json.simple.parser.ParseException;

/**
 * Main class for the application.
 * 
 * @author Dylan
 * @author Samuel
 * @author Armaan
 * @author Andrea
 * @author Liam
 * @version 1.0
 */

public class App {
	// Application title
	private static final String APP_TITLE = "WesternMaps";
	public static boolean devStatus = false;

	/**
	 * Getter for the developer mode status
	 * 
	 * @return returns true or false, depending on if the developer mode is on or
	 *         off
	 */
	public static boolean getDevStatus() {
		return devStatus;
	}

	/**
	 * Setter for the developer mode status
	 * 
	 * @param mode: set the developer mode to whatever mode is
	 */
	public static void setDevStatus(boolean mode) {
		devStatus = mode;
	}

	/**
	 * Main method.
	 * 
	 * @param args Command line arguments.
	 */
	public static void main(String[] args) {
		// Use SwingUtilities.invokeLater to ensure UI updates happen on the Event
		// Dispatch Thread
		SwingUtilities.invokeLater(() -> {
			// Create the main application frame and set its title
			JFrame frame = new JFrame(APP_TITLE);
			// Set the default close operation for the frame
			frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
			// Set the size of the frame
			frame.setSize(1024, 768);

			// Add a custom window listener to warn the user before closing the application
			frame.addWindowListener(new WindowAdapter() {
				@Override
				public void windowClosing(WindowEvent e) {
					int confirmed = JOptionPane.showConfirmDialog(frame,
							"Are you sure you want to exit the application?", "Exit Confirmation",
							JOptionPane.YES_NO_OPTION);

					if (confirmed == JOptionPane.YES_OPTION) {
						frame.dispose();
						System.exit(0);
					}
				}
			});

			Building defaultBuilding = new Building("MiddlesexCollege");
			int defaultFloor = 0;
			POIPanel poiPanel = new POIPanel(defaultBuilding, defaultFloor);
			MapView mapView = new MapView(defaultBuilding, defaultFloor, poiPanel);
			// Create instances of the custom components

			// By default MSC will be loade
			MapMenu mapMenu;
			try {
				mapMenu = new MapMenu();
			} catch (IOException | ParseException e) {
				throw new RuntimeException(e);
			}
			WeatherWidget weatherWidget = new WeatherWidget();
			MapMenuBar mapMenuBar = new MapMenuBar(mapView, mapMenu);
			frame.setJMenuBar(mapMenuBar.mb);

			// Create the main panel with a BorderLayout
			JPanel mainPanel = new JPanel(new BorderLayout());

			// Add the POIPanel to the left side of the main panel
			mainPanel.add(mapMenu.getPanel(), BorderLayout.WEST);

			// Add the MapView to the center of the main panel
			mainPanel.add(mapMenu.getScrollPane(), BorderLayout.CENTER);

			// Create the right panel with a BorderLayout
			JPanel rightPanel = new JPanel(new BorderLayout());

			// Add the MapMenu to the top of the right panel
			rightPanel.add(mapMenu, BorderLayout.NORTH);

			// Add the WeatherWidget to the bottom of the right panel
			rightPanel.add(weatherWidget, BorderLayout.SOUTH);

			// Add the right panel to the east side of the main panel
			mainPanel.add(rightPanel, BorderLayout.EAST);

			// Add the main panel to the frame
			frame.add(mainPanel);

			// Make the frame visible
			frame.setVisible(true);
		});
	}
}
