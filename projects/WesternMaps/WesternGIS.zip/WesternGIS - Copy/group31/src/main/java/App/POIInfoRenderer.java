package App;

import BackendAPI.POIInfo;

import javax.swing.*;
import java.awt.*;

/**
 * POIInfoRenderer is a custom renderer for displaying POIInfo objects in a JList.
 * @author Samuel Kahessay
 * @version 1.0
 */
public class POIInfoRenderer extends DefaultListCellRenderer {

    /**
     * Returns a component configured to display the specified POIInfo object in a JList.
     *
     * @param list         The JList that displays the object.
     * @param value        The POIInfo object to display.
     * @param index        The index of the object in the list.
     * @param isSelected   True if the specified cell is selected.
     * @param cellHasFocus True if the specified cell has focus.
     * @return A component configured to display the specified POIInfo object.
     */
    @Override
    public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
        super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
        if (value instanceof POIInfo) {
            POIInfo poiInfo = (POIInfo) value;
            String text = poiInfo.getPOI().getName() + " (" + poiInfo.getBuilding().getName() + ", Floor " + poiInfo.getFloor().getFloorNum() + ")";
            setText(text);
        }
        return this;
    }
}
