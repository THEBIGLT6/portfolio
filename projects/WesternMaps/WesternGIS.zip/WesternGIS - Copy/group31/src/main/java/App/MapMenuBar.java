package App;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import BackendAPI.Building;
import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import BackendAPI.*;

import java.awt.event.*;

/**
 * MapMenuBar class for displaying the menu bar along with the buttons
 * @author Dylan
 * @author Samuel
 * @author Andrea
 */
public class MapMenuBar {
    JMenuBar mb;
    JButton search, edit, about, help, save;
    public static final String thePassword = "WesternMaps";
    public static final String exitPassword = "hunter2";
    private static MapView mapView;

    private static MapMenu mapMenu;

    MapMenuBar(MapView mapView, MapMenu mapMenu) {
        this.mapView = mapView;
        this.mapMenu = mapMenu;
        mb = new JMenuBar();
        createButtons();
        addActionListeners();
        addButtonsToMenuBar();
    }
    
    /**
     * This method creates the JButtons for the Menu Bar
     */
    private void createButtons() {
        search = new JButton("Search");
        edit = new JButton("Edit");
        about = new JButton("About");
        help = new JButton("Help");
        save = new JButton("Save");
    }
    
    /**
     * This method gives each button a method to run when clicked
     */
    private void addActionListeners() {
        search.addActionListener(e -> launchSearch());
        edit.addActionListener(e -> launchEdit());
        about.addActionListener(e -> launchAbout());
        help.addActionListener(e -> launchHelp());
        save.addActionListener(e -> launchSave());
    }
    
    /**
     * This method displays the buttons to the menu bar
     */
    private void addButtonsToMenuBar() {
        mb.add(search);
        mb.add(edit);
        mb.add(about);
        mb.add(help);
        mb.add(save);
    }
    
    /**
     * This method creates a window and returns it
     * @param title: the desired title of the window
     * @param width: the desired width of the window
     * @param height: the desired height of the window
     * @return the completed JFrame window
     */
    private static JFrame createWindow(String title, int width, int height) {
        JFrame window = new JFrame(title);
        window.setSize(width, height);
        window.setLayout(null);
        window.setVisible(true);
        window.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        return window;
    }
    
    /**
     * creates a button with desired features and returns it
     * @param text: the desired text to be displayed in the button
     * @param x: the x value where the button will be located
     * @param y: the y value where the button will be located
     * @param width: the width of the button
     * @param height: the height of the button
     * @param action: the action the button will do when clicked
     * @return the completed button object
     */
    private static JButton createButton(String text, int x, int y, int width, int height, ActionListener action) {
        JButton button = new JButton(text);
        button.setBounds(x, y, width, height);
        button.addActionListener(action);
        return button;
    }
    
    /**
     * creates a JLabel and returns it
     * @param text: the desired text to be display
     * @param x: the desired x coordinate for the label to be located
     * @param y: the desired y coordinate for the label to be located
     * @param width: the desired width of the label
     * @param height: the desired height of the label
     * @return the completed JLabel object
     */
    private static JLabel createLabel(String text, int x, int y, int width, int height) {
        JLabel label = new JLabel(text);
        label.setBounds(x, y, width, height);
        return label;
    }
    
    /**
     * This method is called when the search button is pressed
     */
    public static void launchSearch() {
    //creates window
    JFrame window = createWindow("Search", 400, 300);
    window.setLayout(new BorderLayout());
    
    //creates arraylist of buildings availible
    List<Building> buildings = new ArrayList<>();
    buildings.add(new Building("MiddlesexCollege"));
    buildings.add(new Building("AlumniHall"));
    buildings.add(new Building("PhysicsAndAstronomy"));

    JTextField searchBar = new JTextField("");

    JList<POIInfo> poiList = new JList<>();
    JScrollPane scrollPane = new JScrollPane(poiList);
    
    //action listeners for the search bar
    searchBar.getDocument().addDocumentListener(new DocumentListener() {
        private void updateList() { //updates the list of found POIs
            String searchText = searchBar.getText().trim().toLowerCase();
            List<POIInfo> filteredPOIs = filterPOIs(buildings, searchText);
            DefaultListModel<POIInfo> model = new DefaultListModel<>();
            for (POIInfo poiInfo : filteredPOIs) {
                model.addElement(poiInfo);
            }
            poiList.setModel(model);
            poiList.setCellRenderer(new POIInfoRenderer());
        }

        @Override
        public void insertUpdate(DocumentEvent e) {
            updateList();
        }

        @Override
        public void removeUpdate(DocumentEvent e) {
            updateList();
        }

        @Override
        public void changedUpdate(DocumentEvent e) {
            updateList();
        }
    });
    //when a poi is clicked, it will change the map and move to the POI
    poiList.addMouseListener(new MouseAdapter() {
        @Override
        public void mouseClicked(MouseEvent e) {
            if (e.getClickCount() == 1) {
                POIInfo selectedPOI = poiList.getSelectedValue();

                if (selectedPOI != null) {
                    // Update the map
                    mapMenu.setSelectedBuildingAndFloor(selectedPOI.getBuilding().getName(),
                            "Floor " + selectedPOI.getFloor().getFloorNum());
                }
            }
        }
    });
    window.add(searchBar, BorderLayout.NORTH);
    window.add(scrollPane, BorderLayout.CENTER);
}
    
    /**
     * popup window for the edit button
     */
    public static void launchEdit() {
        JFrame window = createWindow("Developer Mode", 400, 250);
        JLabel userLabel = createLabel("User:", 60, 50, 40, 30);
        JLabel passLabel = createLabel("Pass:", 60, 90, 40, 30);

        JTextField username = new JTextField();
        username.setBounds(100, 50, 210, 30);

        JPasswordField password = new JPasswordField();
        password.setBounds(100, 90, 210, 30);

        JButton cancelButton = createButton("Cancel", 100, 120, 100, 30, e -> window.dispose());
        JButton searchButton = createButton("Submit", 210, 120, 100, 30, e -> {
            String userPassword = new String(password.getPassword());
            if (App.getDevStatus() == false && username.getText().equals("Developer") && userPassword.equals(thePassword)) {
                //if the developer mode is false, and the usernames and passwords match up, the user enters developer mode
                System.out.println("Entered Developer Mode");
                App.setDevStatus(true);
                popupTemplate("Entered Developer Mode");
                window.dispose();
            } else if(App.getDevStatus() == true && username.getText().equals("Developer") && userPassword.equals(exitPassword)) {
                //if the developer mode is true and the usernames and passwords match up, the user exits developer mode
                System.out.println("Exited Developer Mode"); 
                App.setDevStatus(false);
                popupTemplate("Exited Developer Mode");
                window.dispose();
            } else {//if neither of the previous occur, the credientials were wrong
                System.out.println("Wrong Credentials");
                popupTemplate("Wrong Credentials");
            }
            
        });
        //adds the button to the window
        window.add(searchButton);
        window.add(cancelButton);
        window.add(username);
        window.add(password);
        window.add(userLabel);
        window.add(passLabel);
    }
    /**
     * popup window for the about button
     */
    public static void launchAbout() {
        JFrame window = createWindow("About the Software", 400, 300);
        JLabel informationRow1 = createLabel("Western Maps", 30, 10, 210, 30);
        JLabel informationRow2 = createLabel("Version 1.0.0", 30, 30, 210, 30);
        JLabel informationRow3 = createLabel("3.4.2023", 30, 50, 210, 30);
        JLabel informationRow4 = createLabel("Contact Information:", 30, 90, 210, 30);
        JLabel informationRow5 = createLabel("Andrea Bavaro - adianoba@uwo.ca", 30, 110, 210, 30);
        JLabel informationRow6 = createLabel("Samuel Kahessay - skahessa@uwo.ca", 30, 130, 230, 30);
        JLabel informationRow7 = createLabel("Armaan Mahajan - amahaj5@uwo.ca", 30, 150, 210, 30);
        JLabel informationRow8 = createLabel("Dylan Patrascu - dpatras@uwo.ca", 30, 170, 210, 30);
        JLabel informationRow9 = createLabel("Liam Truss - ltruss@uwo.ca", 30, 190, 210, 30);
        
        JButton backButton = createButton("Back", 280, 230, 100, 30, e -> window.dispose());

        window.add(informationRow1);
        window.add(informationRow2);
        window.add(informationRow3);
        window.add(informationRow4);
        window.add(informationRow5);
        window.add(informationRow6);
        window.add(informationRow7);
        window.add(informationRow8);
        window.add(informationRow9);
        window.add(backButton);
    }
    /**
     * popup window for the help button
     */
    public static void launchHelp() {
       Desktop desktop = Desktop.getDesktop();
       try {
        //launches a local html file with information about the program
        File aboutFile = new File("src/main/resources/About.html");
        desktop.browse(aboutFile.toURI());
    } catch (IOException e) {
        e.printStackTrace();
       }
    }
    /**
     * launches the save changes popup
     */
    public static void launchSave() {
        JFrame window = createWindow("Save", 400, 200);
        JLabel textLabel = createLabel("Would You Like to Save?", 100, 50, 210, 30);

        JButton noButton = createButton("No", 100, 90, 100, 30, e -> window.dispose());
        JButton yesButton = createButton("Yes", 210, 90, 100, 30, e -> System.out.println("Save Data"));

        window.add(yesButton);
        window.add(noButton);
        window.add(textLabel);
    }
    
    /**
     * filters out pois based on user search
     * @param buildings: current building
     * @param searchText: text from user
     * @return a list of pois
     */
    private static List<POIInfo> filterPOIs(List<Building> buildings, String searchText) {
        List<POIInfo> filteredPOIs = new ArrayList<>();
        
        for (Building building : buildings) {
            Iterator<Floor> floorIterator = building.getFloorIter();
            while (floorIterator.hasNext()) {
                Floor floor = floorIterator.next();
                Iterator<Layer> layerIterator = floor.getLayerIter();
                while (layerIterator.hasNext()) {
                    Layer layer = layerIterator.next();
                    Iterator<POI> poiIterator = layer.getPoiIter();
                    while (poiIterator.hasNext()) {
                        POI poi = poiIterator.next();
                        if (poi.getName().toLowerCase().startsWith(searchText) && !poi.getName().equals("null")) {
                            filteredPOIs.add(new POIInfo(poi, building, floor));
                        }
                    }
                }
            }
        }
        return filteredPOIs;
    }
    /**
     * popup window template used to avoid repeating code
     * @param text: text to display in the popup
     */
    private static void popupTemplate(String text) {
        JFrame window = createWindow("Popup", 400, 200);
        JLabel textLabel = createLabel(text, 100, 50, 210, 30);
        JButton okayButton = createButton("Okay", 150, 90, 100, 30, e -> window.dispose());
        
        window.add(textLabel);
        window.add(okayButton);
    }
}

