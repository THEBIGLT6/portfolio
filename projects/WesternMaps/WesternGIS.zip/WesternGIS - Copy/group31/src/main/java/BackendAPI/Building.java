package BackendAPI;
import java.util.*;

import org.json.simple.JSONObject;
import org.json.simple.parser.*;
import java.io.FileWriter;
import java.io.FileReader;

/**
 * Represents a class that is to resemble a building, holding all floors and content
 * @author Liam Truss
 * @author Armaan Mahajan
 * @version 1.0
 */

public class Building {
    
    //instance variables
    private String name;
    private Integer NUM_FLOORS;
    private Boolean isShown;
    private LinkedList<Floor> floors;
    private JSONObject buildingJSON;
    
    /**
     * 
     * The constructor for this class initializes all instance variables 
     *
     * @param buildingName 
     */
    public Building(String buildingName){
        
        try {
            JSONObject metadataJSON = (JSONObject) new JSONParser().parse(new FileReader("src/main/resources/finalMetadata.json"));
            this.buildingJSON = (JSONObject) metadataJSON.get(buildingName);
        } catch (Exception e) {
            e.printStackTrace();
        }

        if (buildingJSON != null) {
            this.name = (String) buildingJSON.get("name");
            this.NUM_FLOORS = (int)(long)buildingJSON.get("numFloors");
            floors = constructFloors(buildingName);
            isShown = false;
        }
        else {
            System.out.println("Error: buildingJSON is null");
        }

    }//end building
    
    /**
     * Constructs and returns the linkedlist of Floors for the building
     *
     * @param building 
     * @return a Linkedlist storing all Floor objects for this building
     */
    private LinkedList<Floor> constructFloors(String building) {
        LinkedList<Floor> floors = new LinkedList<Floor>();
        try {
            JSONObject metadataJSON = (JSONObject) new JSONParser().parse(new FileReader("src/main/resources/finalMetadata.json"));
            JSONObject buildingJSON = (JSONObject) metadataJSON.get(building);
            JSONObject floorJSON = (JSONObject) buildingJSON.get("Floors");

            for(Object key : floorJSON.keySet()) {
                // cannot cast "name" nad "numFloors" to JSONObjects
                JSONObject floor = (JSONObject) floorJSON.get(key);
                floors.add(new Floor(floor));
            }
            return floors;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    
    public Iterator<Floor> getFloorIter() {
        if (floors != null) {
            return floors.iterator();
        }
        return null;
    }
    
    // Returns an ordered array of Floors for the building object
    public Floor[] getFloorArr() {
        if (NUM_FLOORS == null) {
            System.out.println("Error: NUMFLOORS is not initialized");
            return null;
        }
        Iterator<Floor> iter = this.getFloorIter();
        Floor[] floorArr = new Floor[NUM_FLOORS];
        while(iter.hasNext()) {
            Floor currFloor = iter.next();
            floorArr[currFloor.getFloorNum()-1] = currFloor;
        }
        return floorArr;
    }
    
    /**
     * Reassembles the entire JSON for each building from the bottom up and 
     * writes to the metadata file
     */
    public void saveBuilding() {
        /* Parse JSON in initial state, iterate through keys and save other 
         * buildings in strings. Rebuild the current building bottom-up. 
         * Rebuild JSON and write it to finalMetadata.json 
         */

        HashMap<String,Object> writeToFileHash = new HashMap<String,Object>();

        try {
            JSONObject metadataJSON = (JSONObject) new JSONParser().parse(new FileReader("src/main/resources/finalMetadata.json"));
            for(Object key : metadataJSON.keySet()) {
                if((String) key != this.name) {
                    writeToFileHash.put((String) key, metadataJSON.get((String)key));
                }
            }
        }catch(Exception e) {
            e.printStackTrace();
        }
        
        JSONObject thisBuilding = buildBuildingJSON();
        writeToFileHash.put(this.name.replaceAll("\\s",""), thisBuilding);
        
        JSONObject writeToFile = new JSONObject(writeToFileHash);

        try {
            FileWriter file = new FileWriter("src/main/resources/finalMetadata.json");
            file.write(writeToFile.toJSONString());
            file.flush();
            file.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Builds a JSON Object representing this building
     *
     * @return returns the built JSONObject
     */
    public JSONObject buildBuildingJSON() {
        HashMap<String,Object> buildingJSON = new HashMap<String,Object>();
        buildingJSON.put("name", this.name);
        buildingJSON.put("numFloors", this.NUM_FLOORS);
        buildingJSON.put("Floors", getFloorListAsHashMap());

        JSONObject floorJSON = new JSONObject(buildingJSON);
        return floorJSON;
    }


    /**
     * Converts the Floor list into a hashmap as a helper function for 
     * storing the Building in JSON 
     *
     * @return returns a HashMap 
     */
    public HashMap<String,Object> getFloorListAsHashMap() {
        HashMap<String,Object> floorListAsMap = new HashMap<String,Object>();
        Iterator<Floor> floorIter = this.getFloorIter();
        while(floorIter.hasNext()) {
            Floor currFloor = floorIter.next();
            floorListAsMap.put("Floor" + Integer.toString(currFloor.getFloorNum()), currFloor.buildFloorJSON());
        }
        return floorListAsMap;
    }
    /**
     * Name getter
     *
     * @return the stored name 
     */
    public String getName(){
        
        return name;
        
    }//end getName
    
    /**
     * Num Floor getter
     *
     * @return variable number of floors 
     */
    public int getNumFloors(){
        return NUM_FLOORS;
    }//end getName
    
    /**
     * isShown getter
     *
     * @return boolean variable isShown
     */
    public Boolean getIsShown(){
        
        return isShown;
        
    }//end getName
    
    //this method returns the linked list of floors
    /**
     * Getter for linked list of floors
     *
     * @return LinkedList storing all Floor objects for this building
     */
    public LinkedList<Floor> getFloorList(){
        return floors;
    }//end getPOIList

    /**
     * Returns the Floor object based on the floor name
     *
     * @param floorName: the name of the floor that is being looked for 
     * @return 
     */
    public Floor getFloor(String floorName) {
        for (Floor floor : floors) {
            if (floor.getName().equals(floorName)) {
                return floor;
            }
        }
        return null;
    }

    /**
     * This method gets the floor object based on the floors number
     *
     * @param floorNumber: the floor number that is being requested 
     * @return the related floor object
     */
    public Floor getFloor(int floorNumber) {
        if (floorNumber > 0 && floorNumber <= NUM_FLOORS) {
            return floors.get(floorNumber - 1);
        }
        return null;
    }

    /**
     * Setter for visibility
     *
     * @param visible: boolean indicating whether the Building should be shown 
     */
    public void setVisibility(boolean visible) {
        this.isShown = visible;
    }

    /**
     * Getter for the JSON object for this building
     *
     * @return a JSONObject for this building
     */
    public JSONObject getJSON() {
        return this.buildingJSON;
    }
    
}// end Class building
