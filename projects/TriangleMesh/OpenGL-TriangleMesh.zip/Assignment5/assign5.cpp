// Include all headers
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/gtx/normal.hpp >
#include <glm/gtc/type_ptr.hpp>
#include <glm/gtx/string_cast.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <vector>
#include <functional>
#include <cmath>
#include <math.h>
#include "TriTable.hpp"
#define _CRT_SECURE_NO_WARNINGS

//define marcos
#define TOP_LEFT_F 128;
#define TOP_RIGHT_F  64;
#define BOTTOM_RIGHT_F  32;
#define BOTTOM_LEFT_F  16;
#define TOP_LEFT_B  8;
#define TOP_RIGHT_B  4;
#define BOTTOM_RIGHT_B  2;
#define BOTTOM_LEFT_B  1;
#define PI  3.14159265358979323846


//shader codes
std::string VertexShaderCode = "\
    	#version 330 core\n\
		layout(location = 0) in vec3 position;\n\
		layout(location = 1) in vec3 normal;\n\
		out vec3 FragPos;\n\
		out vec3 Normal;\n\
		out vec3 LightDir;\n\
		uniform mat4 MVP;\n\
		uniform mat4 V;\n\
		uniform vec3 LightDirUni;\n\
		void main() {\n\
			FragPos = vec3(MVP * vec4(position, 1.0));\n\
			Normal = mat3(transpose(inverse(V))) * normal;\n\
			LightDir = normalize(LightDirUni);\n\
			gl_Position = MVP * vec4(position, 1.0);\n\
		}\n";


std::string FragmentShaderCode = "\
		#version 330 core\n\
		in vec3 FragPos;\n\
		in vec3 Normal;\n\
		in vec3 LightDir;\n\
		out vec4 FragColour;\n\
		uniform vec3 modelColour;\n\
		const vec3 ambientColour = vec3(0.2, 0.2, 0.2);\n\
		const vec3 specularColour = vec3(1.0, 1.0, 1.0);\n\
		const float shininess = 64.0;\n\
		void main() {\n\
			vec3 ambient = ambientColour * modelColour;\n\
			// Diffuse\n\
			float diffuseStrength = max(dot(normalize(Normal), normalize(LightDir)), 0.0);\n\
			vec3 diffuse = diffuseStrength * modelColour;\n\
			// Specular\n\
			vec3 viewDir = normalize(-FragPos);\n\
			vec3 reflectDir = reflect(-LightDir, Normal);\n\
			float specularStrength = pow(max(dot(viewDir, reflectDir), 0.0), shininess);\n\
			vec3 specular = specularStrength * specularColour;\n\
			vec3 lighting = ambient + diffuse + specular;\n\
			FragColour = vec4(lighting, 1.0);\n\
		}\n";


typedef float (*scalar_field)(float, float,float);

//delcare instance variables
GLFWwindow* window;

double r = std::sqrt(75);
double theta = atan(5/5);
double phi =  acos(5/r);
double lastX = 0.0f;
double lastY = 0.0f;

glm::vec3 cameraPos = glm::vec3(r * sin(phi) * cos(theta), r * cos(phi), r * sin(theta) * sin(phi));
glm::vec3 cameraPoint =  glm::vec3(0.0f, 0.0f, 0.0f);
glm::vec3 cameraUp = glm::vec3(0.0f, 1.0f, 0.0f);


// mathematical functions
float f1(float x, float y, float z) {

	return y - sin(x) * cos(z);

}//end f1

float f2(float x, float y, float z) {

	return std::pow(x,2) - std::pow(y, 2)- std::pow(z, 2) - z;

}//end f2

//This is the marching cubes function that constructs all of our marching cubes that
//returns a list of floats encoding generated vertcies 
std::vector<float> marching_cubes(scalar_field f, float isovalue, float min, float max, float stepsize) {

	//declare variables
	std::vector<float> verts;
	int test = 0;
	float c1, c2, c3, c4, c5, c6, c7, c8;
	int* ver;

	//loop for x,y,z marching cubes from min to max
	for (float z = min; z < max; z+= stepsize) {
		for (float y = min; y < max; y += stepsize) {
			for (float x = min; x < max; x += stepsize) {

				//run function on each corner
				c8 = (*f)(x, y + stepsize, z + stepsize);
				c7 = (*f)(x + stepsize, y + stepsize, z + stepsize);
				c6 = (*f)(x + stepsize, y + stepsize, z );
				c5 = (*f)(x, y + stepsize, z);
				c4 = (*f)(x, y , z + stepsize);
				c3 = (*f)(x + stepsize, y , z + stepsize);
				c2 = (*f)(x + stepsize, y , z);
				c1 = (*f)(x, y, z );
				test = 0;

				//check if inside square
				if (c8 < isovalue) {
					test |= TOP_LEFT_F;
				}
				if (c7 < isovalue) {
					test |= TOP_RIGHT_F;
				}
				if (c6 < isovalue) {
					test |= BOTTOM_RIGHT_F;
				}
				if (c5 < isovalue) {
					test |= BOTTOM_LEFT_F;
				}
				if (c4 < isovalue) {
					test |= TOP_LEFT_B;
				}
				if (c3 < isovalue) {
					test |= TOP_RIGHT_B;
				}
				if (c2 < isovalue) {
					test |= BOTTOM_RIGHT_B;
				}
				if (c1 < isovalue) {
					test |= BOTTOM_LEFT_B;
				}


				//store verticies in vector
				ver = marching_cubes_lut[test];

				if (ver[0] >= 0) {

					verts.emplace_back(x + stepsize * vertTable[ver[0]][0]);
					verts.emplace_back(y + stepsize * vertTable[ver[0]][1]);
					verts.emplace_back(z + stepsize * vertTable[ver[0]][2]);
						 
					verts.emplace_back(x + stepsize * vertTable[ver[1]][0]);
					verts.emplace_back(y + stepsize * vertTable[ver[1]][1]);
					verts.emplace_back(z + stepsize * vertTable[ver[1]][2]);
						
					verts.emplace_back(x + stepsize * vertTable[ver[2]][0]);
					verts.emplace_back(y + stepsize * vertTable[ver[2]][1]);
					verts.emplace_back(z + stepsize * vertTable[ver[2]][2]);

				}

				if (ver[3] >= 0) {

					verts.emplace_back(x + stepsize * vertTable[ver[3]][0]);
					verts.emplace_back(y + stepsize * vertTable[ver[3]][1]);
					verts.emplace_back(z + stepsize * vertTable[ver[3]][2]);
						 
					verts.emplace_back(x + stepsize * vertTable[ver[4]][0]);
					verts.emplace_back(y + stepsize * vertTable[ver[4]][1]);
					verts.emplace_back(z + stepsize * vertTable[ver[4]][2]);
						 
					verts.emplace_back(x + stepsize * vertTable[ver[5]][0]);
					verts.emplace_back(y + stepsize * vertTable[ver[5]][1]);
					verts.emplace_back(z + stepsize * vertTable[ver[5]][2]);
				}

				if (ver[6] >= 0) {

					verts.emplace_back(x + stepsize * vertTable[ver[6]][0]);
					verts.emplace_back(y + stepsize * vertTable[ver[6]][1]);
					verts.emplace_back(z + stepsize * vertTable[ver[6]][2]);
						 
					verts.emplace_back(x + stepsize * vertTable[ver[7]][0]);
					verts.emplace_back(y + stepsize * vertTable[ver[7]][1]);
					verts.emplace_back(z + stepsize * vertTable[ver[7]][2]);
						 
					verts.emplace_back(x + stepsize * vertTable[ver[8]][0]);
					verts.emplace_back(y + stepsize * vertTable[ver[8]][1]);
					verts.emplace_back(z + stepsize * vertTable[ver[8]][2]);

				}

				if (ver[9] >= 0) {

					verts.emplace_back(x + stepsize * vertTable[ver[9]][0]);
					verts.emplace_back(y + stepsize * vertTable[ver[9]][1]);
					verts.emplace_back(z + stepsize * vertTable[ver[9]][2]);
						 
					verts.emplace_back(x + stepsize * vertTable[ver[10]][0]);
					verts.emplace_back(y + stepsize * vertTable[ver[10]][1]);
					verts.emplace_back(z + stepsize * vertTable[ver[10]][2]);
						 
					verts.emplace_back(x + stepsize * vertTable[ver[11]][0]);
					verts.emplace_back(y + stepsize * vertTable[ver[11]][1]);
					verts.emplace_back(z + stepsize * vertTable[ver[11]][2]);

				}

				if (ver[12] >= 0) {

					verts.emplace_back(x + stepsize * vertTable[ver[12]][0]);
					verts.emplace_back(y + stepsize * vertTable[ver[12]][1]);
					verts.emplace_back(z + stepsize * vertTable[ver[12]][2]);
						
					verts.emplace_back(x + stepsize * vertTable[ver[13]][0]);
					verts.emplace_back(y + stepsize * vertTable[ver[13]][1]);
					verts.emplace_back(z + stepsize * vertTable[ver[13]][2]);
						 
					verts.emplace_back(x + stepsize * vertTable[ver[14]][0]);
					verts.emplace_back(y + stepsize * vertTable[ver[14]][1]);
					verts.emplace_back(z + stepsize * vertTable[ver[14]][2]);

				}

				

			}//end x for
		}//end y for
	}//end z for

	//return list
	return verts;

}//end marching_cubes


//This function takes in the list given by marching_cubes and converts each vector to normal
std::vector<float> compute_normals(std::vector<float> verts) {

	//declare variables
	std::vector<float> norms;
	glm::vec3 v1,v2,v3;
	glm::vec3 norm;

	//run a for loop the length of the input list
	for (int i = 0; i < verts.size(); i = i + 9) {

		v1 = glm::vec3(verts[i],verts[i + 1], verts[i + 2]);
		v2 = glm::vec3(verts[i + 3], verts[i + 4], verts[i + 5]);
		v3 = glm::vec3(verts[i + 6], verts[i + 7], verts[i + 8]);

		// calculate the normal
		norm = glm::triangleNormal(v3,v2,v1);


		//if the normal is negative calculate in the opposite order, bc then it must be clockwise
		if (norm.x < 0 || norm.y < 0 || norm.z < 0) {
			norm = glm::triangleNormal(v3, v2, v1);
		}

		//normalize the normal vector 
		norm = glm::normalize(norm);

		//push the verticies 
		for (int j = 0; j < 3; j++) {

			norms.push_back(norm.x);
			norms.push_back(norm.y);
			norms.push_back(norm.z);

		}


	}//end for i


	//return list
	return norms;

}//end compute_normals


//This function writes the information of the normals and marching cubes to a PLY file
void writePLY(std::vector<float> marching, std::vector<float> normals, std::string filepath) {

	//open file 
	std::ofstream myfile(filepath);

	// Check if the file was successfully opened
	if (myfile.is_open()) {
		
		//write header
		myfile << "ply" << std::endl;
		myfile << "format ascii 1.0" << std::endl;
		myfile << "element vertex " << marching.size() << std::endl;
		myfile << "property float x" << std::endl;
		myfile << "property float y" << std::endl;
		myfile << "property float z" << std::endl;
		myfile << "property float nx" << std::endl;
		myfile << "property float ny" << std::endl;
		myfile << "property float nz" << std::endl;
		myfile << "element face " << (marching.size()/3) << std::endl;
		myfile << "property list uchar uint vertex_indices" << std::endl;
		myfile << "end_header" << std::endl;

		//write verticies 
		for (int i = 0; i < marching.size(); i = i + 3) {

			myfile << marching.at(i) << " " << marching.at(i + 1) << " " << marching.at(i + 2) << " " <<  normals.at(i) << " " << normals.at(i + 1) << " " << normals.at(i + 2) << std::endl;

		}//end for

		//write faces 
		for (int i = 0; i < marching.size(); i = i + 3) {

			myfile << "3 " << i << " " << i + 1 << " " << i + 2 << std::endl; 


		}//end for


		//close file
		myfile.close();
	}
	else {
		std::cerr << "Error opening file for writing" << std::endl;
	}

}//end writePLY


//This function handles key presses
void keyCallBack(GLFWwindow* window, int key, int scancode, int action, int mods) {

	//If up is pressed move towards centre 
	if (key == GLFW_KEY_UP && GLFW_PRESS) {
		
		//stop at 0
		if (r - 0.1 > 0) {
			r = r - 0.1;
		}

		cameraPos = glm::vec3(r * sin(phi) * cos(theta), r * cos(phi), r * sin(theta) * sin(phi));
	}

	//If down is pressed move away from centre
	if (key == GLFW_KEY_DOWN &&  GLFW_PRESS) {

		r = r  + 0.1;

		cameraPos = glm::vec3(r * sin(phi) * cos(theta), r * cos(phi), r * sin(theta) * sin(phi));

	}
}//end keyCall

bool drag = false;

// This is the function used to know when then mouse button is clicked
void mouseCallback(GLFWwindow* window, int button, int action, int mods) {
	
	
	//recognize if button is pressed 
	if (button == GLFW_MOUSE_BUTTON_LEFT && action == GLFW_PRESS) {
		double xpos, ypos;
		
		//grab the position first so it moves relative to its current position
		//call the getPoint function
		glfwGetCursorPos(window, &xpos, &ypos);
		lastX = xpos;
		lastY = ypos;
		drag = true;
	}

	
	//end dragging
	else if (action == GLFW_RELEASE) {
		drag = false;
	}


}//end mouseCallback


//this is the function that analzyes the drag of the object and updates the coordinates
void getPoint(GLFWwindow* window, double xpos, double ypos) {

	
	// this will be run if the object is being dragged
	if (drag) {
		
		//calculate difference of movement
		double differenceX = xpos - lastX;
		double differenceY = ypos - lastY;

		//calculate angles relative to difference
		theta = theta + differenceX * 0.01;
		phi = phi + differenceY * 0.01;

		//if phi ends up being more than 180,  - 180
		if (phi > 180) { phi = phi - 180; }

		
		//make the last position equal to the current;
		lastX = xpos;
		lastY = ypos;

		//update camera position 
		cameraPos = glm::vec3(r * sin(phi) * cos(theta), r * cos(phi), r * sin(theta) * sin(phi));

	}

}//end getPoint


//this class is used to store all the data neccesary to draw the object
class DrawObj {

	// instance variables
	GLuint VBONorm;
	GLuint VBOVert;
	GLuint VAO;
	GLuint shader;
	GLuint matrixID;
	GLuint VID;
	GLuint LightDirID;
	GLuint modelColourID;
	int size;


public:


	DrawObj(std::vector<float> marching, std::vector<float> normals) {

		size = marching.size();

		// Create the shaders
		GLuint VertexShaderID = glCreateShader(GL_VERTEX_SHADER);
		GLuint FragmentShaderID = glCreateShader(GL_FRAGMENT_SHADER);

		//compile vertex shader
		char const* VertexSourcePointer = VertexShaderCode.c_str();
		glShaderSource(VertexShaderID, 1, &VertexSourcePointer, NULL);
		glCompileShader(VertexShaderID);

		// Compile Fragment Shader
		char const* FragmentSourcePointer = FragmentShaderCode.c_str();
		glShaderSource(FragmentShaderID, 1, &FragmentSourcePointer, NULL);
		glCompileShader(FragmentShaderID);


		//add and link shaders to program then detach and delete 
		shader = glCreateProgram();
		glAttachShader(shader, VertexShaderID);
		glAttachShader(shader, FragmentShaderID);
		glLinkProgram(shader);
		glDetachShader(shader, VertexShaderID);
		glDetachShader(shader, FragmentShaderID);
		glDeleteShader(VertexShaderID);
		glDeleteShader(FragmentShaderID);

		//get handles for our uniforms
		matrixID = glGetUniformLocation(shader, "MVP");
		VID = glGetUniformLocation(shader, "V");
		LightDirID = glGetUniformLocation(shader, "LightDirUni");
		modelColourID = glGetUniformLocation(shader, "modelColour");

		//create VAO
		glGenVertexArrays(1, &VAO);
		glBindVertexArray(VAO);

		// cbind VBO for verts
		glGenBuffers(1, &VBOVert);
		glBindBuffer(GL_ARRAY_BUFFER, VBOVert);
		glBufferData(GL_ARRAY_BUFFER, marching.size() * sizeof(float), marching.data(), GL_STATIC_DRAW);

		// specify attributes for verts
		glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
		glEnableVertexAttribArray(0);

		// bind VBO for normals
		glGenBuffers(1, &VBONorm);
		glBindBuffer(GL_ARRAY_BUFFER, VBONorm);
		glBufferData(GL_ARRAY_BUFFER, normals.size() * sizeof(float), normals.data(), GL_STATIC_DRAW);

		// specify attributes for normals
		glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
		glEnableVertexAttribArray(1);

		// Unbind VBO and VAO
		glBindBuffer(GL_ARRAY_BUFFER, 0);
		glBindVertexArray(0);

	}//constructor



	//this function draws the shape
	void draw(glm::mat4 MVP, glm::mat4 V, glm::vec3 LightDir, glm::vec3 modelColour) {

		matrixID = glGetUniformLocation(shader, "MVP");
		VID = glGetUniformLocation(shader, "V");
		LightDirID = glGetUniformLocation(shader, "LightDirUni");
		modelColourID = glGetUniformLocation(shader, "modelColour");

		//add shader and variables
		glUseProgram(shader);
		glUniformMatrix4fv(matrixID, 1, GL_FALSE, &MVP[0][0]);
		glUniformMatrix4fv(VID, 1, GL_FALSE, &V[0][0]);
		glUniform3fv(LightDirID, 1, glm::value_ptr(LightDir));
		glUniform3fv(modelColourID, 1, glm::value_ptr(modelColour));

		// Bind VAO
		glBindVertexArray(VAO);

		// Draw triangles
		glDrawArrays(GL_TRIANGLES, 0, size / 3);

		// Unbind VAO
		glBindVertexArray(0);

		glUseProgram(0);

	}//draw

};//end DrawObj

//This function draws heads to the axis arrows
void drawArrowHead(float x, float y, float z) {

	glBegin(GL_TRIANGLES);
	glVertex3f(x - 0.1, y - 0.1, z - 0.1);
	glVertex3f(x, y, z);
	glVertex3f(x - 0.1, y + 0.1, z - 0.1);
	glEnd();

}

/// MAIN ///

int main(int argc, char* argv[]) {

	// Initialise GLFW
	if (!glfwInit())
	{
		fprintf(stderr, "Failed to initialize GLFW\n");
		getchar();
		return -1;
	}

	//  THESE ARE THE VARIABLES TO EDIT THE FUNCTION
	float min = -5;
	float max = 5;
	float isovalue = -0.5;
	float stepsize = 0.05f;
	glm::vec3 light = glm::vec3(-5.0f,-5.0f,-5.0f);
	glm::vec3 colour = glm::vec3(0.0f, 0.4f, 0.7f);


	// Open a window and create its OpenGL context
	float screenW = 1400;
	float screenH = 1000;
	window = glfwCreateWindow(screenW, screenH, "Assignment 5", NULL, NULL);
	if (window == NULL) {
		fprintf(stderr, "Failed to open GLFW window. If you have an Intel GPU, they are not 3.3 compatible. Try the 2.1 version of the tutorials.\n");
		getchar();
		glfwTerminate();
		return -1;
	}
	glfwMakeContextCurrent(window);

	// Initialize GLEW
	glewExperimental = true;
	if (glewInit() != GLEW_OK) {
		fprintf(stderr, "Failed to initialize GLEW\n");
		getchar();
		glfwTerminate();
		return -1;
	}

	glViewport(0, 0, screenW, screenH);

	glEnable(GL_DEPTH_TEST);

	// Immediate mode 
	glClearColor(0.2f, 0.2f, 0.3f, 0.0f);

	
	//run marching cubes, compute normals and writePLY
	std::vector<float> marching = marching_cubes(f1, isovalue, min, max, stepsize);
	std::vector<float> normals = compute_normals(marching);
	writePLY(marching, normals, "marchingSqaures1.PLY");


	// create object
	DrawObj func = DrawObj(marching,normals);

	// render loop
	do {

		// Clear the screen
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		glfwPollEvents();

		// Create Projection matrix
		glMatrixMode(GL_PROJECTION);
		glPushMatrix();
		glm::mat4 projection = glm::perspective(glm::radians(45.0f), screenW / screenH, 0.01f, 60.0f);
		glLoadMatrixf(glm::value_ptr(projection));

		//grab key presses by setting callback function
		glfwSetKeyCallback(window, keyCallBack);
		glfwSetMouseButtonCallback(window, mouseCallback);
		glfwSetCursorPosCallback(window, getPoint);


		//update view matrix
		glMatrixMode(GL_MODELVIEW);
		glPushMatrix();
		glm::mat4 view = glm::lookAt(cameraPos, cameraPoint, cameraUp);
		glLoadMatrixf(glm::value_ptr(view));

		//make Mat matrix
		glm::mat4 M = glm::mat4(1.0f);

		//calculate MVP matrix
		glm::mat4 MVP = projection * view * M;

		//glColor3f(0.7, 0, 0);
		//glBegin(GL_TRIANGLES);
		//for (size_t i = 0; i < marching.size(); i += 3) {
			//glVertex3f(marching[i], marching[i + 1], marching[i + 2]);
		//}
		//glEnd();


		//draw box  with axes
		glLineWidth(3.0f);
		glBegin(GL_LINES);
		
		glColor3f(0.3, 0.3, 0.3);
		glVertex3f(min, max, min);
		glVertex3f(max, max, min);

		glVertex3f(min, max, min);
		glVertex3f(min, max, max);

		glVertex3f(max, max, min);
		glVertex3f(max, max, max);

		glVertex3f(max, max, max);
		glVertex3f(min, max, max);

		glVertex3f(max, max, min);
		glVertex3f(max, min, min);

		glVertex3f(max, max, max);
		glVertex3f(max, min, max);

		glVertex3f(min, max, max);
		glVertex3f(min, min, max);

		glVertex3f(max, min, min);
		glVertex3f(max, min, max);

		glVertex3f(max, min, max);
		glVertex3f(min, min, max);

		glColor3f(0.7, 0, 0);
		glVertex3f(min, min, min);
		glVertex3f(max, min, min);

		glColor3f(0, 0.7, 0);
		glVertex3f(min, min, min);
		glVertex3f(min, max, min);

		glColor3f(0, 0.0, 0.7);
		glVertex3f(min, min, min);
		glVertex3f(min, min, max);

		glEnd();

		//draw arrowheads
		glColor3f(0.7, 0, 0);
		drawArrowHead(max, min, min);
		glColor3f(0, 0.7, 0);
		drawArrowHead(min, max, min);
		glColor3f(0, 0.0, 0.7);
		drawArrowHead(min, min, max);

		// Rendering for marching cubes
		func.draw(MVP, view, light, colour);

		// Swap buffers
		glfwSwapBuffers(window);

	} while (glfwGetKey(window, GLFW_KEY_ESCAPE) != GLFW_PRESS && glfwWindowShouldClose(window) == 0);


	// Close OpenGL window and terminate GLFW
	glfwTerminate();

	return 0;

}//end main
