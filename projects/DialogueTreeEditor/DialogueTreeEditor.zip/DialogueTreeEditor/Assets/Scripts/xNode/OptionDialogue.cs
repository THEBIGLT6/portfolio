﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using XNode;

[CreateAssetMenu(fileName = "Dialogue", menuName = "ScriptableObjects/OptionDialogue")]
public class OptionDialogue : Dialogue 
{
    public string m_responseA;
    public string m_responseB;
    public string m_responseC;
    public string m_responseD;
}