﻿using UnityEngine;
using UnityEngine.UI;
using XNode;

public class OptionNode : Node 
{
	[SerializeField] private OptionDialogue m_dialogue;

	[Input] public Node m_prevNode;
	[Output] public Node m_optionA;
    [Output] public Node m_optionB;
    [Output] public Node m_optionC;
    [Output] public Node m_optionD;

    public string speaker()
    {
        return m_dialogue.m_speaker;
    }

    public string dialogueKey()
    {
        return m_dialogue.m_dialogueKey;
    }

    public string responseA()
    {
        return m_dialogue.m_responseA;
    }

    public string responseB()
    {
        return m_dialogue.m_responseB;
    }

    public string responseC()
    {
        return m_dialogue.m_responseC;
    }

    public string responseD()
    {
        return m_dialogue.m_responseD;
    }

    public Sprite image()
    {
        return m_dialogue.m_image;
    }
}