using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using TMPro;
using UnityEditor;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using XNode;

public class DialogueManager : MonoBehaviour
{
    // Method variables
    
    public DialogueGraph m_dialogueGraph;
    public TMP_Text m_speakerBox;
    public TMP_Text m_dialogueBox;
    public Image m_backgroundImage;
    public TMP_Text m_languageLabel, m_dialogueLabel;
    public TMP_Dropdown m_languageDropdown, m_dialogueDropdown;
    public Button m_optionA, m_optionB, m_optionC, m_optionD;

    private bool m_started;
    private bool m_leafNodeReached;

    private Language m_language;
    private List<Language> m_languages = new List<Language>();

    Node m_currentNode;
    AudioSource m_audioSource;
    AudioClip m_transitionFX;

    private void Start()
    {
        // Get Componets 
        m_audioSource = GetComponent<AudioSource>();

        m_started = false;
        m_leafNodeReached = false;

        // Set Up Start GUI
        m_speakerBox.text = "";
        m_dialogueBox.text = "Welcome to the dialogue simulator, select a language and dialogue to get started!";
        setButtonText(m_optionA, "Click to Start!");
        m_optionB.gameObject.SetActive(false);
        m_optionC.gameObject.SetActive(false);
        m_optionD.gameObject.SetActive(false);

        populateDropdowns();
    }

    // Public Methods
    public void runDialogue( Node node )
    {
        m_currentNode = node;

        // option
        if ( m_currentNode.GetType() == typeof(OptionNode) )
        {
            OptionNode optionNode = (OptionNode)m_currentNode;
            
            m_speakerBox.text = optionNode.speaker();
            m_dialogueBox.text = m_language.getValue( optionNode.dialogueKey() );
            m_backgroundImage.sprite = optionNode.image();

            if (optionNode.responseA() != "" )
            {
                setButtonText( m_optionA, m_language.getValue(optionNode.responseA()));
                m_optionA.gameObject.SetActive(true);
            }
            else m_optionA.gameObject.SetActive(false);
            

            if (optionNode.responseB() != "")
            {
                setButtonText(m_optionB, m_language.getValue(optionNode.responseB()));
                m_optionB.gameObject.SetActive(true);
            }
            else m_optionB.gameObject.SetActive(false);

            if (optionNode.responseC() != "")
            {
                setButtonText(m_optionC, m_language.getValue(optionNode.responseC()));
                m_optionC.gameObject.SetActive(true);
            }
            else m_optionC.gameObject.SetActive(false);

            if (optionNode.responseD() != "")
            {
                setButtonText(m_optionD, m_language.getValue(optionNode.responseD()));
                m_optionD.gameObject.SetActive(true);
            }
            else m_optionD.gameObject.SetActive(false);

        }

        // dialogue node
        else if( m_currentNode.GetType() == typeof(DialogueNode) )
        {
            DialogueNode dialogueNode = (DialogueNode)m_currentNode;
            
            m_speakerBox.text = dialogueNode.speaker();
            m_dialogueBox.text = m_language.getValue( dialogueNode.dialogueKey() );
            m_backgroundImage.sprite = dialogueNode.image();
            
            setButtonText( m_optionA, m_language.getValue( "Continue" ));

            // Hide options
            m_optionB.gameObject.SetActive(false);
            m_optionC.gameObject.SetActive(false);
            m_optionD.gameObject.SetActive(false);
        }

        // leaf node
        else
        {
            LeafNode leafNode = (LeafNode)m_currentNode;

            m_speakerBox.text = "THE END";
            m_dialogueBox.text = m_language.getValue( leafNode.dialogueKey() );
            m_backgroundImage.sprite = leafNode.image();

            m_optionA.gameObject.SetActive(true);
            m_optionB.gameObject.SetActive(true);
            m_optionC.gameObject.SetActive(true);
            m_optionD.gameObject.SetActive(false);

            setButtonText( m_optionA, m_language.getValue( "Restart" ) );
            setButtonText( m_optionB, m_language.getValue( "MainMenu") );
            setButtonText( m_optionC, m_language.getValue( "Quit" ) );

            m_leafNodeReached = true;
        }

    }

    public void optionATrigger()
    {

        // Clicked start button 
        if ( !m_started )
        {
            loadDialogue();
            runDialogue( m_dialogueGraph.nodes[0] );
            m_started = true;
        }
        else if( m_leafNodeReached )
        {
            restart();
        }
        else
        {
            if (m_currentNode.GetType() == typeof(OptionNode))
            {
                OptionNode optionNode = (OptionNode)m_currentNode;
                NodePort port = optionNode.GetOutputPort("m_optionA").Connection;

                if (port != null) runDialogue(port.node);
                else Debug.LogError("OptionA node is null.");
            }
            else
            {
                DialogueNode dialogueNode = (DialogueNode)m_currentNode;
                NodePort port = dialogueNode.GetOutputPort("m_nextNode").Connection;

                if (port != null) runDialogue(port.node);
                else Debug.LogError("Next dialogue node is null.");
            }

        }

        if( m_transitionFX != null )
            m_audioSource.PlayOneShot(m_transitionFX);

    }

    public void optionBTrigger()
    {
        if( !m_leafNodeReached )
        {
            OptionNode optionNode = (OptionNode)m_currentNode;
            NodePort port = optionNode.GetOutputPort( "m_optionB" ).Connection;
            
            if (port != null) runDialogue(port.node);
            else              Debug.LogError( "OptionB node is null." );
        }
        else
        {
            returnToMainMenu();
        }

        if (m_transitionFX != null)
            m_audioSource.PlayOneShot(m_transitionFX);

    }

    public void optionCTrigger()
    {

        if( !m_leafNodeReached )
        {
            OptionNode optionNode = (OptionNode)m_currentNode;
            NodePort port = optionNode.GetOutputPort("m_optionC").Connection;

            if (port != null)  runDialogue(port.node);
            else               Debug.LogError("OptionC node is null.");
        }
        else
        {
            quit();
        }

        if (m_transitionFX != null)
            m_audioSource.PlayOneShot(m_transitionFX);

    }

    public void optionDTrigger()
    {
        OptionNode optionNode = (OptionNode)m_currentNode;
        NodePort port = optionNode.GetOutputPort("m_optionD").Connection;
        
        if (port != null) runDialogue( port.node );
        else              Debug.LogError( "OptionD node is null." );

        if (m_transitionFX != null)
            m_audioSource.PlayOneShot(m_transitionFX);
    }

    // Private Methods
    private void setButtonText( Button butt, string text )
    {
        TextMeshProUGUI buttonText = butt.GetComponentInChildren<TextMeshProUGUI>();
        buttonText.text = text;
    }

    private void populateDropdowns()
    {
        m_languageDropdown.ClearOptions();
        m_dialogueDropdown.ClearOptions();

        List<string> optionsLanguages = new List<string>();
        string[] guids = AssetDatabase.FindAssets("t:Language", new[] { "Assets/Resources/Languages" });

        foreach (string guid in guids)
        {
            string assetPath = AssetDatabase.GUIDToAssetPath(guid);
            Language language = AssetDatabase.LoadAssetAtPath<Language>(assetPath);
            if (language != null)
                optionsLanguages.Add( language.name );
                m_languages.Add( language );
        }

        m_languageDropdown.AddOptions( optionsLanguages );

        string dialoguesPath = Path.Combine(Application.dataPath, "Resources/Dialogues");
        string[] directories = Directory.GetDirectories(dialoguesPath);
        List<string> optionsDialogues = new List<string>();

        foreach (string dir in directories)
        {
            string folderName = Path.GetFileName(dir);
            optionsDialogues.Add(folderName);
        }

        m_dialogueDropdown.AddOptions(optionsDialogues);
    }

    private void loadDialogue()
    {
        m_languageDropdown.gameObject.SetActive(false);
        m_languageLabel.gameObject.SetActive(false);
        m_dialogueDropdown.gameObject.SetActive(false);
        m_dialogueLabel.gameObject.SetActive(false);
        m_backgroundImage.color = Color.white;

        // Load Dialogue Graph
        string pathToDialogue = "Dialogues/" + m_dialogueDropdown.options[m_dialogueDropdown.value].text + "/" + m_dialogueDropdown.options[m_dialogueDropdown.value].text;
        m_dialogueGraph = Resources.Load<DialogueGraph>(pathToDialogue);
        m_language = m_languages[m_languageDropdown.value];

        if( m_dialogueGraph == null )
        {
            Debug.LogError( "Dialogue graph was not loaded succesfully" );
        }

        // Load Background Music
        string pathToMusic = "Dialogues/" + m_dialogueDropdown.options[m_dialogueDropdown.value].text + "/" + "Music";
        AudioClip clip = Resources.Load<AudioClip>(pathToMusic);

        if (clip != null)
        {
            m_audioSource.clip = clip;
            m_audioSource.Play();
        }
        else
        {
            Debug.LogWarning( "Failed to load background music at path: " + pathToMusic );
        }

        // Load Transition FX
        string pathToTransition = "Dialogues/" + m_dialogueDropdown.options[m_dialogueDropdown.value].text + "/" + "Transition";
        m_transitionFX = Resources.Load<AudioClip>(pathToTransition);

        if (m_transitionFX == null)
        {
            Debug.LogWarning("Failed to load transition fx sound at path: " + pathToMusic);
        }

    }

    private void restart()
    {
        m_leafNodeReached = false;
        runDialogue(m_dialogueGraph.nodes[0]);
    }

    private void returnToMainMenu()
    {
        SceneManager.LoadScene(0);
    }

    private void quit()
    {
        Application.Quit();
        UnityEditor.EditorApplication.isPlaying = false;
    }


} //end DialogueManager 
