﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using XNode;

public class LeafNode : Node 
{
    [Input] public Node m_prevNode;
    [SerializeField] private Dialogue m_dialogue;

    public string speaker()
    {
        return m_dialogue.m_speaker;
    }

    public string dialogueKey()
    {
        return m_dialogue.m_dialogueKey;
    }

    public Sprite image()
    {
        return m_dialogue.m_image;
    }

}