﻿using UnityEngine;
using UnityEngine.UI;
using XNode;

public class DialogueNode : Node 
{
	[SerializeField] private Dialogue m_dialogue; 

	[Input] public Node m_prevNode;
	[Output] public Node m_nextNode;

	public string speaker()
	{
		return m_dialogue.m_speaker;
	}

	public string dialogueKey()
	{
		return m_dialogue.m_dialogueKey;
	}

	public Sprite image()
	{
		return m_dialogue.m_image;
	}

} 