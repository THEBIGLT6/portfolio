using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SelectionArrow : MonoBehaviour
{
    [SerializeField] private RectTransform[] m_options;
    private RectTransform m_rect;
    private int m_currentPosiition;

    private void Awake()
    {
        m_rect = GetComponent<RectTransform>();
    }

    private void Update()
    {
        if(Input.GetKeyDown(KeyCode.W) || Input.GetKeyDown(KeyCode.UpArrow) )
        {
            changePosition(-1);
        }
        else if( Input.GetKeyDown(KeyCode.S) || Input.GetKeyDown(KeyCode.DownArrow) )
        {
            changePosition(1);
        }

        if (Input.GetKeyDown(KeyCode.Return) || Input.GetKeyDown(KeyCode.RightArrow))
        {
            interact();
        }


        if( !m_options[m_currentPosiition].gameObject.activeInHierarchy )
        {
            m_rect.position = new Vector3(m_rect.position.x, m_options[0].position.y, m_rect.position.z);
            m_currentPosiition = 0;
        }

    }

    private void changePosition(int change)
    {
        int temp = m_currentPosiition + change;
        if ( temp >= 0 && temp <= m_options.Length - 1 && m_options[temp].gameObject.activeInHierarchy )
        {
            m_currentPosiition = temp;

            if( m_currentPosiition < 0 )
                m_currentPosiition = m_options.Length - 1;
            else if( m_currentPosiition >= m_options.Length)
                m_currentPosiition = 0;

            m_rect.position = new Vector3( m_rect.position.x, m_options[m_currentPosiition].position.y, m_rect.position.z );
        }
    }

    private void interact()
    {
        m_options[m_currentPosiition].GetComponent<Button>().onClick.Invoke();
    }

}
