# Tools 3 - Dialogue Tree Editor
Liam Truss \
CompSci 4482 - Game Programming 

# Demo 
The featured demo is a dialouge between Anakin and Obi-Wan in the pivotal scene on Mustafar giving the user control over Obi-Wans speech. To play this demo simply load in the scene and hit play, you will be prompt to select a language and dialog option, use the enter key to select the option and the arrow keys to cycle through dialogue options.

# How to Use
To make your own dialogue scene repeat the following steps...
1. You will need to create 2 directories, "Assets/Resources/Languages" and "Assets/Resources/Dialogues", that will hold the respective information.
2. To create a language, in the languages directory right click and go to "Create" > "Scriptable Objects" > "Language". The Language can then be edited with the editor window found under "Window" > "Language Editor". Add and remove keys and then click on the language to edit the keys for each language. You can also create languages from here.
3. To create a dialogue, create a new directory in the "Dialogues" menu this will be the name of your dialogue. In this subdirectory create the following... \
    
    i. Create another subdirectory that will hold all DialogueObjects. The name for this does not need to be exact but it should be called something like "DialogueObjects". There are 2 types of Nodes, dialogue and option. To create them right click "Create" > "Scriptable Objects" > "OptionDialogue" / "Dialogue". Both of these have 3 fields that need to be filled out in the inspector "Speaker" ( this can just be the name of the speaker), "image" (The image that will be in the background when this node appears) and "Dialogue Key" (the key for the dialogue that must be present in the language keys). Option Dialogues also have 4 keys for each  potential response, at least 2 must be filled out.

    ii. Music.mp3 - this will be the background music played while the dialogue plays.

    iii. Transition.mp3 - the sound played when transitioning nodes.

    iv. A dialogue tree - create this by right clicking "Create" > "Dialogue Graph". Double click to open this, this will be the structure of our dialogue tree. Right click to create each node, there is dialogue, option and leaf. Dialogue and option are the same as before, leaf denotes an ending node ( which must be done at the end of a branch). The first node created will be the root node. Create nodes and add the dialogue or option scriptable objects under the "Dialogue" field to give the nodes function, You can draw links from each option to in an option node to a new dialogue to create different branches.

4. After creating languages and dialogues they should appear in the drop downs when running the demo scene and the dialogues will now be playable.
 
# Resources
Used XNode for building and handling the trees ... https://github.com/Siccity/xNode \
Music is 'Battle of the Heroes' by John Williams \
Transition sound is a lightsaber sound effect sound here ... https://pixabay.com/sound-effects/search/lightsaber/\
All images are a screenshot from Star Wars Episode III: Revenge of The Sith, except for a select few that are AI generated 
