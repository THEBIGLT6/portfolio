2D Platformer - Dragon Warrior Cave Adventure

CompSci 4482 - App Assignment 2
Liam Truss

I chose to do the 2D Platformer hack and slash style.

Objective:
    - The game is a 2d platformer, your goal is to make it from the spawn point to the chest located at the other end of the map while avoiding enemies. The player has a maximum of 3 life points, an enemy attack loses one life point and contact with a hazard like spikes loses 3. Enemy health varies by enemy.

Controls:
    - Use 'A' / 'D' or Left/Right arrow keys to move horizontally
    - Space bar to jump
    - 'E' to shoot a ranged fire ball
    - 'R' to strike with horn. (Contact area is farther than the horn so you don't need to get to close)
    - 'Esc' to open pause menu
    - When in pause menu use arrow keys and enter to select fields (with the exception of some buttons like 'Save score' after recording a new high score and 'reset leaderboard' that need to be clicked )

Assets Used:
    - Skybox background: https://assetstore.unity.com/packages/2d/textures-materials/sky/customizable-skybox-174576
    - Cave tileset: https://assetstore.unity.com/packages/2d/environments/2d-platfrom-tile-set-cave-61672
    - Sound Effects: https://assetstore.unity.com/packages/audio/sound-fx/rpg-essentials-sound-effects-free-227708
    - Background Music: https://assetstore.unity.com/packages/audio/ambient/fantasy/dark-fantasy-music-pack-2-mini-pack-124182
    - Dragon warrior character: https://assetstore.unity.com/packages/2d/characters/dragon-warrior-free-93896
    - Skeleton enemies: https://assetstore.unity.com/packages/2d/characters/2d-animated-skeletons-282022
    - Slime enemies: https://assetstore.unity.com/packages/2d/characters/slime-character-157405

Loosly followed this tutorial series along with John Lemon's tutorial:
- https://www.youtube.com/watch?v=TcranVQUQ5U&list=PLgOEwFbvGm5o8hayFB6skAfa8Z-mw4dPV